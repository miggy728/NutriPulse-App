# Keep Room entities
-keep class com.nutripulse.app.models.** { *; }
