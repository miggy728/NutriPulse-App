package com.nutripulse.app.cloud;

import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;

/** RELEASE builds: uses Play Integrity (requires the app to be registered in Google Play Console). */
public final class AppCheckSetup {
    private AppCheckSetup() {}

    public static void install() {
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance());
    }
}
