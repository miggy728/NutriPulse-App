package com.nutripulse.app.data;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Looks up packaged food by barcode in Open Food Facts (free, open database, no API key).
 * https://world.openfoodfacts.org — data is added by volunteers, so it can be incomplete.
 * Call from a background thread.
 */
public final class OpenFoodFacts {
    private static final String USER_AGENT = "NutriPulse/2.0 (Android; student wellness app)";
    private static final String FIELDS = "product_name,brands,serving_size,nutriscore_grade,nutriments";

    public static final class Result {
        public FoodItem food;          // null when not found
        public String brand = "";
        public String nutriScore = ""; // a..e, or empty
        public boolean perServing;     // true = values per serving, false = per 100 g/ml
    }

    private OpenFoodFacts() {}

    /** @throws IOException when there is no internet or the server can't be reached */
    public static Result lookup(String barcode) throws IOException {
        Result r = new Result();
        String code = barcode == null ? "" : barcode.replaceAll("[^0-9]", "");
        if (code.length() < 6) return r;
        URL url = new URL("https://world.openfoodfacts.org/api/v2/product/" + code + ".json?fields=" + FIELDS);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestProperty("User-Agent", USER_AGENT);
        con.setConnectTimeout(10_000);
        con.setReadTimeout(15_000);
        try {
            if (con.getResponseCode() == 404) return r;
            StringBuilder body = new StringBuilder();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = in.readLine()) != null) body.append(line);
            }
            return parse(body.toString());
        } catch (FileNotFoundException notFound) {
            return r;
        } finally {
            con.disconnect();
        }
    }

    static Result parse(String json) {
        Result r = new Result();
        try {
            JSONObject root = new JSONObject(json);
            if (root.optInt("status", 0) != 1) return r;
            JSONObject p = root.getJSONObject("product");
            JSONObject n = p.optJSONObject("nutriments");
            if (n == null) n = new JSONObject();
            String name = p.optString("product_name", "").trim();
            if (name.isEmpty()) return r;
            r.brand = p.optString("brands", "").split(",")[0].trim();
            r.nutriScore = p.optString("nutriscore_grade", "").toLowerCase(Locale.ROOT);

            // Prefer per-serving values when the label gives them, otherwise per 100 g/ml
            double kcal = n.optDouble("energy-kcal_serving", Double.NaN);
            r.perServing = !Double.isNaN(kcal);
            String suffix = r.perServing ? "_serving" : "_100g";
            if (!r.perServing) kcal = n.optDouble("energy-kcal_100g", Double.NaN);
            if (Double.isNaN(kcal)) {
                double kj = n.optDouble("energy" + suffix, Double.NaN);   // some products only list kJ
                kcal = Double.isNaN(kj) ? 0 : kj / 4.184;
            }
            float protein = (float) n.optDouble("proteins" + suffix, 0);
            float carbs = (float) n.optDouble("carbohydrates" + suffix, 0);
            float fat = (float) n.optDouble("fat" + suffix, 0);
            String serving = r.perServing ? p.optString("serving_size", "1 serving") : "100 g";
            if (serving.isEmpty()) serving = "1 serving";
            boolean healthy = r.nutriScore.equals("a") || r.nutriScore.equals("b")
                    || (r.nutriScore.isEmpty() && kcal < 250);
            String display = r.brand.isEmpty() || name.toLowerCase(Locale.ROOT).contains(r.brand.toLowerCase(Locale.ROOT))
                    ? name : name + " (" + r.brand + ")";
            if (display.length() > 40) display = display.substring(0, 40).trim();
            r.food = new FoodItem(display, "🏷️", "Snack", serving, (int) Math.round(kcal),
                    protein, carbs, fat, healthy, 0);
        } catch (Exception ignored) {
            r.food = null;
        }
        return r;
    }
}
