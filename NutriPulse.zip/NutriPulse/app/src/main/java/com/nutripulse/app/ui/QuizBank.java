package com.nutripulse.app.ui;

import java.util.Calendar;

/** Daily nutrition quiz: one question per day from a bank of 40, cycling through all before repeating. */
public final class QuizBank {
    private QuizBank() {}

    public static final class Question {
        public final String text; public final String[] options; public final int answer; public final String why;
        Question(String text, String[] options, int answer, String why) {
            this.text = text; this.options = options; this.answer = answer; this.why = why;
        }
    }

    private static Question q(String text, int answer, String why, String... options) {
        return new Question(text, options, answer, why);
    }

    private static final Question[] QUESTIONS = {
            q("Which nutrient is the body's main source of quick energy?", 1,
                    "Carbohydrates break down into glucose, the body's go-to fuel.", "Protein", "Carbohydrates", "Vitamin C", "Calcium"),
            q("Which food is highest in protein per serving?", 2,
                    "100 g of chicken breast has about 31 g of protein.", "Apple", "Steamed rice", "Chicken breast", "Carrot"),
            q("Fiber mainly helps with…", 0,
                    "Fiber keeps digestion regular and feeds good gut bacteria.", "Digestion", "Eyesight", "Hair growth", "Hearing"),
            q("Which drink is the best everyday choice for hydration?", 2,
                    "Water hydrates with zero added sugar.", "Soda", "Milk tea", "Water", "Energy drink"),
            q("Healthy fats are found in…", 0,
                    "Nuts, seeds and fatty fish like bangus or salmon contain heart-friendly fats.", "Nuts and fish", "Candy", "Soft drinks", "White bread"),
            q("Calcium is especially important for…", 0,
                    "Calcium keeps bones and teeth strong.", "Bones and teeth", "Hair color", "Taste", "Sleep only"),
            q("A balanced plate should be about half…", 2,
                    "Filling half your plate with fruits and veggies is a simple balance rule.", "Rice", "Meat", "Fruits and vegetables", "Desserts"),
            q("Which Filipino dish is packed with vegetables?", 1,
                    "Pinakbet mixes squash, eggplant, okra, ampalaya and string beans.", "Lechon", "Pinakbet", "Chicharon", "Leche flan"),
            q("Malunggay (moringa) leaves are a good source of…", 3,
                    "Malunggay is rich in vitamins A and C, calcium and iron.", "Caffeine", "Added sugar", "Trans fat", "Vitamins and iron"),
            q("Which is a healthier merienda?", 0,
                    "Boiled saba has natural sugar and fiber with no frying oil.", "Nilagang saging (saba)", "Banana cue", "Turon", "Chips"),
            q("Monggo (mung beans) give you plenty of…", 1,
                    "Mung beans are a cheap, filling source of plant protein and fiber.", "Caffeine", "Protein and fiber", "Alcohol", "Trans fat"),
            q("Which cooking method usually uses the least oil?", 2,
                    "Steaming, boiling and grilling need little or no oil.", "Deep-frying", "Pan-frying", "Steaming", "Battering"),
            q("Too much sodium (salt) mostly affects your…", 0,
                    "High sodium can raise blood pressure over time.", "Blood pressure", "Eye color", "Height", "Hair"),
            q("Which of these is a whole grain?", 3,
                    "Brown rice keeps its bran, so it has more fiber than white rice.", "White bread", "Pandesal", "Instant noodles", "Brown rice"),
            q("Vitamin C helps your…", 1,
                    "Vitamin C supports your immune system and helps heal wounds.", "Hair grow faster", "Immune system", "Bones grow taller", "Night vision only"),
            q("Which fruit is very high in vitamin C?", 2,
                    "Bayabas (guava) has even more vitamin C than oranges!", "Banana", "Coconut meat", "Guava (bayabas)", "Avocado"),
            q("How many hours of sleep do most teens and adults need?", 1,
                    "Most adults need 7–9 hours; teens need a bit more.", "4–5", "7–9", "11–12", "It doesn't matter"),
            q("A can of regular soda has about how many teaspoons of sugar?", 3,
                    "A 330 ml can has around 8–9 teaspoons of sugar.", "1", "2", "4", "8–9"),
            q("Iron helps carry ___ around the body.", 0,
                    "Iron is part of hemoglobin, which carries oxygen in the blood.", "Oxygen", "Sugar", "Water", "Salt"),
            q("Which food is a good source of iron?", 1,
                    "Leafy greens like kangkong and malunggay, plus lean meat and beans, give iron.", "Soda", "Kangkong", "White rice", "Ice cream"),
            q("Eating slowly helps because…", 2,
                    "Your brain needs about 20 minutes to notice that you're full.", "Food gets warmer", "It burns calories", "You notice when you're full", "It adds protein"),
            q("Which drink adds the most sugar to your day?", 2,
                    "Large milk tea with pearls can have well over 10 teaspoons of sugar.", "Water", "Black coffee", "Milk tea with pearls", "Green tea"),
            q("Which is the best post-workout snack?", 0,
                    "Protein plus carbs, like yogurt with fruit, helps muscles recover.", "Yogurt with fruit", "Candy", "Soda", "Nothing at all"),
            q("Which vegetable is famously bitter but very nutritious?", 3,
                    "Ampalaya is rich in vitamins and fiber.", "Carrot", "Corn", "Squash", "Ampalaya"),
            q("Skipping breakfast often makes people…", 1,
                    "Long gaps without food can lead to big hunger and overeating later.", "Grow taller", "Overeat later", "Sleep better", "Drink less water"),
            q("Which is a good plant-based protein?", 2,
                    "Tokwa (tofu) is made from soybeans and is rich in protein.", "Cassava", "Cucumber", "Tofu (tokwa)", "Lettuce"),
            q("Potassium, found in bananas, helps your…", 0,
                    "Potassium helps your muscles and heart work properly.", "Muscles and heart", "Hair color", "Eyesight", "Teeth only"),
            q("Which is a smart swap for white bread?", 1,
                    "Whole wheat bread has more fiber and keeps you full longer.", "Croissant", "Whole wheat bread", "Donut", "Ensaymada"),
            q("Which of these is NOT a macronutrient?", 3,
                    "Vitamins are micronutrients; protein, carbs and fat are macronutrients.", "Protein", "Carbohydrates", "Fat", "Vitamin A"),
            q("How much of your plate should be protein (like fish or tokwa)?", 1,
                    "About a quarter of the plate is a good guide for protein.", "None", "About a quarter", "Three quarters", "All of it"),
            q("Which helps you stay hydrated besides water?", 0,
                    "Watery fruits like pakwan (watermelon) and soup also count.", "Watermelon", "Salty chips", "Fried chicken", "Chocolate"),
            q("Fresh buko juice naturally contains…", 2,
                    "Coconut water has electrolytes like potassium.", "Caffeine", "Alcohol", "Electrolytes", "Gluten"),
            q("Processed meats like hotdog and longganisa are often high in…", 1,
                    "They're usually high in salt and saturated fat, so enjoy them now and then.", "Fiber", "Salt and fat", "Vitamin C", "Water"),
            q("Which breakfast keeps you full longest?", 3,
                    "Oats with egg combine fiber and protein for steady energy.", "Sweet pastry", "Soda", "Candy bar", "Oatmeal and an egg"),
            q("Why is it good to eat many colors of fruits and vegetables?", 0,
                    "Different colors mean different vitamins and antioxidants.", "You get different nutrients", "It's prettier only", "Colors add protein", "It has no benefit"),
            q("What is a healthy way to handle stress eating?", 2,
                    "Pausing to check if you're truly hungry, then choosing a planned snack, helps.", "Eat faster", "Skip all meals", "Pause and check if you're hungry", "Only drink soda"),
            q("Which fish is the Philippines' national fish?", 1,
                    "Bangus (milkfish) is a great source of protein and healthy fats.", "Tilapia", "Bangus", "Galunggong", "Tuna"),
            q("Walking 10,000 steps is roughly…", 2,
                    "10,000 steps is about 7–8 km for most people.", "1 km", "3 km", "7–8 km", "20 km"),
            q("Which is a good way to read food labels?", 0,
                    "Check serving size first, then sugar, sodium and fat per serving.", "Check the serving size first", "Only look at the color", "Ignore the numbers", "Only read the brand"),
            q("Drinking water before a meal can help you…", 3,
                    "A glass of water first can help you notice fullness sooner.", "Grow taller", "Skip sleep", "Get more sugar", "Notice when you're full"),
    };

    public static int size() { return QUESTIONS.length; }

    /** Same question all day; every question appears once before any repeats. */
    public static Question today() {
        Calendar c = Calendar.getInstance();
        int index = (c.get(Calendar.YEAR) * 366 + c.get(Calendar.DAY_OF_YEAR)) % QUESTIONS.length;
        return QUESTIONS[index];
    }
}
