package com.nutripulse.app.utils;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Runs database work off the main thread and posts results back to the UI. */
public final class AppExecutors {
    private static final ExecutorService IO = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private AppExecutors() {}

    public static void io(Runnable r) { IO.execute(r); }

    public static void main(Runnable r) { MAIN.post(r); }

    public static void mainDelayed(Runnable r, long delayMs) { MAIN.postDelayed(r, delayMs); }
}
