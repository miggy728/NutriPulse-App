package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "achievements",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "achKey"}, unique = true)})
public class Achievement {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String achKey = "";
    @NonNull public String title = "";
    @NonNull public String description = "";
    public String emoji;
    public boolean unlocked;
    public long unlockedAt;
}
