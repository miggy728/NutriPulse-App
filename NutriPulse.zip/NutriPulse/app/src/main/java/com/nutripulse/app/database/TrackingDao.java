package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.nutripulse.app.models.StepRecord;
import com.nutripulse.app.models.WaterRecord;
import com.nutripulse.app.models.WeightRecord;

import java.util.List;

/** Weight, water and step logs, always scoped to a single userId. */
@Dao
public interface TrackingDao {
    // Water
    @Insert
    long insertWater(WaterRecord record);

    @Query("SELECT COALESCE(SUM(cups),0) FROM water_records WHERE userId = :userId AND dateKey = :dateKey")
    int waterForDay(long userId, String dateKey);

    @Query("SELECT dateKey AS dateKey, SUM(cups) AS total FROM water_records WHERE userId = :userId AND dateKey >= :fromKey GROUP BY dateKey")
    List<DayTotal> dailyWater(long userId, String fromKey);

    // Steps
    @Insert
    long insertSteps(StepRecord record);

    @Query("SELECT COALESCE(SUM(steps),0) FROM step_records WHERE userId = :userId AND dateKey = :dateKey")
    int stepsForDay(long userId, String dateKey);

    @Query("SELECT dateKey AS dateKey, SUM(steps) AS total FROM step_records WHERE userId = :userId AND dateKey >= :fromKey GROUP BY dateKey")
    List<DayTotal> dailySteps(long userId, String fromKey);

    // Weight
    @Insert
    long insertWeight(WeightRecord record);

    @Query("SELECT * FROM weight_records WHERE userId = :userId ORDER BY timestamp DESC LIMIT 1")
    WeightRecord latestWeight(long userId);

    @Query("SELECT * FROM weight_records WHERE userId = :userId AND dateKey >= :fromKey ORDER BY timestamp ASC")
    List<WeightRecord> weightsSince(long userId, String fromKey);

    @Query("SELECT COUNT(*) FROM weight_records WHERE userId = :userId")
    int countWeights(long userId);

    /** Last weight entry of each day (used for the chart). */
    @Query("SELECT dateKey AS dateKey, weightKg AS total FROM weight_records w WHERE userId = :userId AND dateKey >= :fromKey " +
           "AND timestamp = (SELECT MAX(timestamp) FROM weight_records w2 WHERE w2.userId = w.userId AND w2.dateKey = w.dateKey)")
    List<DayTotal> dailyWeight(long userId, String fromKey);
}
