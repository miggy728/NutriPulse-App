package com.nutripulse.app.cloud;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;
import com.nutripulse.app.database.AppDatabase;
import com.nutripulse.app.database.BackupDao;
import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.FavoriteFood;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.MoodRecord;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.models.StepRecord;
import com.nutripulse.app.models.User;
import com.nutripulse.app.models.WaterRecord;
import com.nutripulse.app.models.WeightRecord;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.data.RowMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Backs up the logged-in user's data to Cloud Firestore and restores it on a new phone.
 *
 * Layout (only the owner can read/write it, see firestore.rules):
 *   users/{firebaseUid}                       profile + goals + list of chunks
 *   users/{firebaseUid}/backup/{table}_{n}    up to 250 rows each
 *
 * Passwords are never uploaded (Firebase Authentication handles them).
 */
public final class CloudBackup {
    public interface Callback { void onDone(boolean ok, String message); }

    private static final String TAG = "CloudBackup";
    private static final int CHUNK = 250;
    private static final String PREFS = "nutripulse_cloud";

    private CloudBackup() {}

    // ------------------------------------------------------------------ public API

    /** Backs up if the last backup is older than {@code minHours}. Silent; for app-pause triggers. */
    public static void backupIfDue(Context c, long localUserId, int minHours) {
        long last = lastBackup(c, localUserId);
        if (System.currentTimeMillis() - last < minHours * 3600_000L) return;
        backup(c, localUserId, (ok, msg) -> { });
    }

    public static void backup(Context context, long localUserId, Callback cb) {
        Context app = context.getApplicationContext();
        FirebaseUser fu = Cloud.user(app);
        if (fu == null) { cb.onDone(false, "Not signed in to the cloud."); return; }
        String uid = fu.getUid();
        AppExecutors.io(() -> {
            try {
                AppDatabase db = AppDatabase.get(app);
                User u = db.userDao().findById(localUserId);
                if (u == null) throw new IllegalStateException("No local user");
                BackupDao b = db.backupDao();
                Map<String, List<?>> tables = new HashMap<>();
                tables.put("meal_records", b.allMealRecord(localUserId));
                tables.put("meal_plans", b.allMealPlan(localUserId));
                tables.put("meal_notes", b.allMealNote(localUserId));
                tables.put("water_records", b.allWaterRecord(localUserId));
                tables.put("step_records", b.allStepRecord(localUserId));
                tables.put("weight_records", b.allWeightRecord(localUserId));
                tables.put("daily_goals", b.allDailyGoal(localUserId));
                tables.put("achievements", b.allAchievement(localUserId));
                tables.put("dietary_preferences", b.allDietaryPreference(localUserId));
                tables.put("custom_foods", b.allCustomFood(localUserId));
                tables.put("favorite_foods", b.allFavoriteFood(localUserId));
                tables.put("mood_records", b.allMoodRecord(localUserId));
                tables.put("pets", b.allPet(localUserId));

                FirebaseFirestore fs = Cloud.db();
                DocumentReference root = fs.collection("users").document(uid);
                DocumentSnapshot old = Tasks.await(root.get(), 30, TimeUnit.SECONDS);
                Map<String, Object> oldChunks = old.exists() && old.get("chunks") instanceof Map
                        ? castMap(old.get("chunks")) : new HashMap<>();

                Map<String, Object> chunks = new HashMap<>();
                List<WriteBatch> batches = new ArrayList<>();
                WriteBatch batch = fs.batch();
                int ops = 0;
                for (Map.Entry<String, List<?>> t : tables.entrySet()) {
                    List<?> rows = t.getValue();
                    int n = (rows.size() + CHUNK - 1) / CHUNK;
                    chunks.put(t.getKey(), n);
                    for (int i = 0; i < n; i++) {
                        List<Map<String, Object>> part = new ArrayList<>();
                        for (int r = i * CHUNK; r < Math.min(rows.size(), (i + 1) * CHUNK); r++) part.add(RowMapper.toMap(rows.get(r)));
                        Map<String, Object> doc = new HashMap<>();
                        doc.put("rows", part);
                        batch.set(root.collection("backup").document(t.getKey() + "_" + i), doc);
                        if (++ops >= 400) { batches.add(batch); batch = fs.batch(); ops = 0; }
                    }
                    // Remove leftover chunks from an older, bigger backup
                    Object oldN = oldChunks.get(t.getKey());
                    int was = oldN instanceof Number ? ((Number) oldN).intValue() : 0;
                    for (int i = n; i < was; i++) {
                        batch.delete(root.collection("backup").document(t.getKey() + "_" + i));
                        if (++ops >= 400) { batches.add(batch); batch = fs.batch(); ops = 0; }
                    }
                }
                Map<String, Object> profile = RowMapper.toMap(u);
                profile.remove("id");
                profile.remove("passwordHash");
                profile.remove("passwordSalt");
                Map<String, Object> rootDoc = new HashMap<>();
                rootDoc.put("profile", profile);
                rootDoc.put("chunks", chunks);
                rootDoc.put("updatedAt", System.currentTimeMillis());
                rootDoc.put("schema", AppDatabase.SCHEMA_VERSION);
                batch.set(root, rootDoc, SetOptions.merge());
                batches.add(batch);
                for (WriteBatch wb : batches) Tasks.await(wb.commit(), 60, TimeUnit.SECONDS);

                prefs(app).edit().putLong("last_" + localUserId, System.currentTimeMillis()).apply();
                AppExecutors.main(() -> cb.onDone(true, "Backed up ☁️"));
            } catch (Exception e) {
                Log.w(TAG, "backup failed", e);
                String reason = friendlyReason(e);
                AppExecutors.main(() -> cb.onDone(false, "Backup failed: " + reason));
            }
        });
    }

    /**
     * Restores a cloud backup into a freshly created local user. Must be called on a background
     * thread. Returns false if there is no backup (caller then sets up a brand-new profile).
     */
    public static boolean restoreBlocking(Context context, String firebaseUid, long localUserId) throws Exception {
        Context app = context.getApplicationContext();
        DocumentReference root = Cloud.db().collection("users").document(firebaseUid);
        DocumentSnapshot snap = Tasks.await(root.get(), 30, TimeUnit.SECONDS);
        if (!snap.exists()) return false;
        AppDatabase db = AppDatabase.get(app);
        BackupDao b = db.backupDao();

        // Profile and goals (never the id, email or password)
        User u = db.userDao().findById(localUserId);
        if (u != null && snap.get("profile") instanceof Map) {
            User saved = RowMapper.fromMap(castMap(snap.get("profile")), User.class);
            u.fullName = saved.fullName.isEmpty() ? u.fullName : saved.fullName;
            if (!saved.username.isEmpty() && db.userDao().countUsername(saved.username) == 0) u.username = saved.username;
            u.registrationDate = saved.registrationDate == 0 ? u.registrationDate : saved.registrationDate;
            u.calorieGoal = saved.calorieGoal;
            u.hydrationGoal = saved.hydrationGoal;
            u.weightGoal = saved.weightGoal;
            u.stepGoal = saved.stepGoal;
            u.heightCm = saved.heightCm;
            db.userDao().update(u);
        }
        Map<String, Object> chunks = snap.get("chunks") instanceof Map ? castMap(snap.get("chunks")) : new HashMap<>();
        b.putPet(rows(root, chunks, "pets", Pet.class, localUserId));
        b.putMealRecord(rows(root, chunks, "meal_records", MealRecord.class, localUserId));
        b.putMealPlan(rows(root, chunks, "meal_plans", MealPlan.class, localUserId));
        b.putMealNote(rows(root, chunks, "meal_notes", MealNote.class, localUserId));
        b.putWaterRecord(rows(root, chunks, "water_records", WaterRecord.class, localUserId));
        b.putStepRecord(rows(root, chunks, "step_records", StepRecord.class, localUserId));
        b.putWeightRecord(rows(root, chunks, "weight_records", WeightRecord.class, localUserId));
        b.putDailyGoal(rows(root, chunks, "daily_goals", DailyGoal.class, localUserId));
        b.putAchievement(rows(root, chunks, "achievements", Achievement.class, localUserId));
        b.putDietaryPreference(rows(root, chunks, "dietary_preferences", DietaryPreference.class, localUserId));
        b.putCustomFood(rows(root, chunks, "custom_foods", CustomFood.class, localUserId));
        b.putFavoriteFood(rows(root, chunks, "favorite_foods", FavoriteFood.class, localUserId));
        b.putMoodRecord(rows(root, chunks, "mood_records", MoodRecord.class, localUserId));
        prefs(app).edit().putLong("last_" + localUserId, System.currentTimeMillis()).apply();
        return true;
    }

    public static long lastBackup(Context c, long localUserId) {
        return prefs(c).getLong("last_" + localUserId, 0);
    }

    // ------------------------------------------------------------------ helpers

    private static <T> List<T> rows(DocumentReference root, Map<String, Object> chunks, String table,
                                    Class<T> type, long localUserId) throws Exception {
        List<T> out = new ArrayList<>();
        Object n = chunks.get(table);
        int count = n instanceof Number ? ((Number) n).intValue() : 0;
        for (int i = 0; i < count; i++) {
            DocumentSnapshot d = Tasks.await(root.collection("backup").document(table + "_" + i).get(), 30, TimeUnit.SECONDS);
            Object list = d.get("rows");
            if (!(list instanceof List)) continue;
            for (Object row : (List<?>) list) {
                if (!(row instanceof Map)) continue;
                T item = RowMapper.fromMap(castMap(row), type);
                // New phone = new local ids: let Room assign ids and point rows to this user
                RowMapper.setIfPresent(item, "id", 0L);
                RowMapper.setIfPresent(item, "userId", localUserId);
                out.add(item);
            }
        }
        return out;
    }

    /** Turns the real cause into a short message the user (and developer) can act on. */
    private static String friendlyReason(Exception e) {
        Throwable t = e;
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        String msg = String.valueOf(t.getMessage());
        if (msg.contains("PERMISSION_DENIED")) return "permission denied. Publish the Firestore rules (see FIREBASE_SETUP.md).";
        if (msg.contains("NOT_FOUND") || msg.contains("does not exist")) return "Firestore database not created yet.";
        if (msg.contains("UNAVAILABLE") || t instanceof java.util.concurrent.TimeoutException
                || t instanceof java.net.UnknownHostException) return "no connection to the cloud. Check your internet.";
        if (msg.contains("App Check") || msg.contains("app check")) return "App Check blocked the request (add your debug token).";
        return t.getClass().getSimpleName() + (t.getMessage() == null ? "" : ": " + t.getMessage());
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Object o) { return (Map<String, Object>) o; }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
