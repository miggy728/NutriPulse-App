package com.nutripulse.app.data;

import com.nutripulse.app.database.AppDatabase;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.models.User;
import com.nutripulse.app.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Sets up a brand-new account's wellness profile. Runs inside the registration transaction. */
public final class UserInitializer {
    private UserInitializer() {}

    public static void initialize(AppDatabase db, User user) {
        // Default virtual pet: Berry, Level 1, 0 EXP
        Pet pet = new Pet();
        pet.userId = user.id;
        pet.name = "Berry";
        pet.level = 1;
        pet.exp = 0;
        pet.createdAt = System.currentTimeMillis();
        db.petDao().insert(pet);

        DietaryPreference pref = new DietaryPreference();
        pref.userId = user.id;
        db.goalDao().savePreference(pref);

        db.goalDao().insertAchievements(Achievements.defaultsFor(user.id));
        db.goalDao().insertGoals(dailyGoalsFor(user, DateUtils.todayKey()));
    }

    /** Default daily wellness goals; titles reflect the user's own targets. */
    public static List<DailyGoal> dailyGoalsFor(User user, String dateKey) {
        List<DailyGoal> goals = new ArrayList<>();
        goals.add(goal(user.id, dateKey, DailyGoal.LOG_MEAL, "Log a Healthy Meal", 10));
        goals.add(goal(user.id, dateKey, DailyGoal.DRINK_WATER, waterTitle(user.hydrationGoal), 5));
        goals.add(goal(user.id, dateKey, DailyGoal.WALK_STEPS, stepsTitle(user.stepGoal), 5));
        goals.add(goal(user.id, dateKey, DailyGoal.DAILY_QUIZ, "Complete Daily Quiz", 5));
        return goals;
    }

    public static String waterTitle(int cups) { return "Drink Water (" + cups + " cups)"; }

    public static String stepsTitle(int steps) {
        return String.format(Locale.US, "Walk %,d Steps", steps);
    }

    private static DailyGoal goal(long userId, String dateKey, String key, String title, int exp) {
        DailyGoal g = new DailyGoal();
        g.userId = userId;
        g.dateKey = dateKey;
        g.goalKey = key;
        g.title = title;
        g.expReward = exp;
        return g;
    }
}
