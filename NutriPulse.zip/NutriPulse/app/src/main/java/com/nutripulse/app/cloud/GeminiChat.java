package com.nutripulse.app.cloud;

import android.content.Context;

import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.ai.FirebaseAI;
import com.google.firebase.ai.GenerativeModel;
import com.google.firebase.ai.java.GenerativeModelFutures;
import com.google.firebase.ai.type.Content;
import com.google.firebase.ai.type.GenerateContentResponse;
import com.google.firebase.ai.type.GenerativeBackend;

/**
 * Talks to Google Gemini through Firebase AI Logic. The Gemini API key stays on Firebase's side
 * (never in the app) and App Check blocks requests from apps that aren't ours.
 */
public final class GeminiChat {
    /**
     * Models tried in order. If one is busy ("high demand" / 503) or out of free quota (429),
     * Berry waits a moment and moves to the next. Change these if Google retires a model
     * (see Firebase AI Logic "supported models" page).
     */
    public static final String[] MODELS = { "gemini-3.8-flash", "gemini-3.5-flash-lite" };
    public static final String MODEL = MODELS[0];

    public interface Callback {
        void onReply(String text);
        void onError(String message);
    }

    private static final GenerativeModelFutures[] models = new GenerativeModelFutures[MODELS.length];
    private static final android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());

    private GeminiChat() {}

    public static boolean isAvailable(Context c) { return Cloud.isReady(c); }

    public static void ask(Context context, String prompt, Callback cb) {
        attempt(context.getApplicationContext(), prompt, cb, 0, 0, null);
    }

    /** idx = which model, retry = retries already done on this model. */
    private static void attempt(Context context, String prompt, Callback cb, int idx, int retry, String lastErr) {
        if (idx >= MODELS.length) { cb.onError(lastErr == null ? "AI unavailable" : lastErr); return; }
        try {
            if (models[idx] == null) {
                GenerativeModel gm = FirebaseAI.getInstance(GenerativeBackend.googleAI()).generativeModel(MODELS[idx]);
                models[idx] = GenerativeModelFutures.from(gm);
            }
            Content content = new Content.Builder().addText(prompt).build();
            ListenableFuture<GenerateContentResponse> response = models[idx].generateContent(content);
            Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
                @Override
                public void onSuccess(GenerateContentResponse result) {
                    String text = null;
                    try { text = result.getText(); } catch (Throwable ignored) { }
                    if (text == null || text.trim().isEmpty()) attempt(context, prompt, cb, idx + 1, 0, "Empty reply");
                    else cb.onReply(text.trim());
                }

                @Override
                public void onFailure(Throwable t) {
                    String err = MODELS[idx] + ": " + describe(t);
                    android.util.Log.w("NutriPulseAI", err);
                    if (!isTransient(err)) { cb.onError(err); return; }   // e.g. App Check / API off: no point retrying
                    if (retry == 0) main.postDelayed(() -> attempt(context, prompt, cb, idx, 1, err), 1500);
                    else attempt(context, prompt, cb, idx + 1, 0, err);
                }
            }, ContextCompat.getMainExecutor(context));
        } catch (Throwable t) {
            attempt(context, prompt, cb, idx + 1, 0, describe(t));
        }
    }

    /** Busy / overloaded / rate-limited / timeouts: worth retrying or trying the next model. */
    static boolean isTransient(String err) {
        String e = err.toLowerCase(java.util.Locale.ROOT);
        return e.contains("high demand") || e.contains("overloaded") || e.contains("503")
                || e.contains("unavailable") || e.contains("429") || e.contains("quota")
                || e.contains("resource_exhausted") || e.contains("rate limit") || e.contains("timeout")
                || e.contains("timed out") || e.contains("internal") || e.contains("500")
                || e.contains("not found") || e.contains("404");
    }

    /** Short, readable reason (exception type + message + root cause) for logs and debug builds. */
    static String describe(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable cur = t;
        for (int i = 0; cur != null && i < 3; i++, cur = cur.getCause()) {
            if (i > 0) sb.append(" ← ");
            sb.append(cur.getClass().getSimpleName());
            if (cur.getMessage() != null) sb.append(": ").append(cur.getMessage());
        }
        String out = sb.toString();
        return out.length() > 400 ? out.substring(0, 400) + "…" : out;
    }
}
