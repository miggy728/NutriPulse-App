package com.nutripulse.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.R;
import com.nutripulse.app.data.WellnessRepository;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.views.PetAnimator;
import com.nutripulse.app.data.PetLook;
import com.nutripulse.app.models.MoodRecord;
import com.nutripulse.app.reminders.ReminderScheduler;
import com.nutripulse.app.utils.StepSensor;
import com.google.android.material.button.MaterialButton;

import java.util.Locale;

/** Home Dashboard: Berry, today's stats and today's goals for the logged-in user. */
public class HomeActivity extends BaseAuthActivity {

    private TextView greeting, date, speech, level, expText, goalCount;
    private TextView energy, mood, gut, water;
    private ProgressBar expBar;
    private ImageView mascot, crown;
    private LinearLayout goalsBox;
    private PetAnimator petAnim;
    private TextView streakView, coinsView, hatView, faceView;
    private MaterialButton stepsChip;
    private StepSensor stepSensor;
    private int stepGoal = 7000;
    private static final int[] MOOD_IDS = {R.id.mood_1, R.id.mood_2, R.id.mood_3, R.id.mood_4, R.id.mood_5};
    private static final String[] TAP_LINES = {
            "Hehe, that tickles! 💗", "Wheee!", "Let's eat something healthy!",
            "I love you! 💕", "Boing boing!", "Did you drink water today? 💧"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_home);
        BottomNav.setup(this, BottomNav.HOME);

        greeting = findViewById(R.id.home_greeting);
        date = findViewById(R.id.home_date);
        speech = findViewById(R.id.home_speech);
        level = findViewById(R.id.home_level);
        expText = findViewById(R.id.home_exp_text);
        expBar = findViewById(R.id.home_exp_bar);
        mascot = findViewById(R.id.home_mascot);
        crown = findViewById(R.id.home_crown);
        streakView = findViewById(R.id.home_streak);
        coinsView = findViewById(R.id.home_coins);
        hatView = findViewById(R.id.home_hat);
        faceView = findViewById(R.id.home_face);
        stepsChip = findViewById(R.id.home_add_steps);
        stepSensor = new StepSensor(this);
        ReminderScheduler.reschedule(this);   // keeps reminders alive after app updates
        if (!OnboardingActivity.isDone(this, session.getUserId())) {
            startActivity(new Intent(this, OnboardingActivity.class));
        }
        goalsBox = findViewById(R.id.home_goals);
        goalCount = findViewById(R.id.home_goal_count);
        energy = findViewById(R.id.stat_energy);
        mood = findViewById(R.id.stat_mood);
        gut = findViewById(R.id.stat_gut);
        water = findViewById(R.id.stat_water);

        petAnim = new PetAnimator(findViewById(R.id.home_pet_area), findViewById(R.id.home_pet_body),
                mascot, findViewById(R.id.home_shadow));
        mascot.setOnClickListener(v -> {
            petAnim.onTap();
            if (!petAnim.isSleeping()) speech.setText(TAP_LINES[(int) (Math.random() * TAP_LINES.length)]);
        });
        mascot.setOnLongClickListener(v -> { startActivity(new Intent(this, PetActivity.class)); return true; });
        findViewById(R.id.home_level_card).setOnClickListener(v -> startActivity(new Intent(this, PetActivity.class)));
        findViewById(R.id.home_chat).setOnClickListener(v -> startActivity(new Intent(this, ChatActivity.class)));
        speech.setOnClickListener(v -> startActivity(new Intent(this, ChatActivity.class)));
        findViewById(R.id.home_bell).setOnClickListener(v -> startActivity(new Intent(this, InsightsActivity.class)));
        findViewById(R.id.tile_water).setOnClickListener(v -> addWater());
        findViewById(R.id.home_add_water).setOnClickListener(v -> addWater());
        findViewById(R.id.home_add_steps).setOnClickListener(v -> logSteps());
        streakView.setOnClickListener(v -> UiUtils.toast(this,
                "🔥 Log at least one food every day to grow your streak. Bonus EXP at 3, 7 and 30 days!"));
        coinsView.setOnClickListener(v -> startActivity(new Intent(this, ShopActivity.class)));
        for (int i = 0; i < MOOD_IDS.length; i++) {
            final int mood = i + 1;
            findViewById(MOOD_IDS[i]).setOnClickListener(v -> pickMood(mood, v));
        }
        findViewById(R.id.home_add_weight).setOnClickListener(v -> logWeight());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (noSession()) return;
        petAnim.start();
        stepSensor.start(steps -> showSensorSteps());
        syncSensorSteps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (petAnim != null) petAnim.stop();
        if (session != null && session.isLoggedIn()) {
            // Quiet cloud backup at most every 6 hours (does nothing without Firebase)
            com.nutripulse.app.cloud.CloudBackup.backupIfDue(this, session.getUserId(), 6);
        }
        if (stepSensor != null) {
            stepSensor.stop();
            int unsaved = stepSensor.canRun() ? stepSensor.unsavedSteps(session.getUserId()) : 0;
            if (unsaved > 0) {
                stepSensor.markSaved(session.getUserId());
                repo.addSteps(unsaved, r -> { });
            }
        }
    }

    /** Saves steps counted by the phone's sensor, then refreshes the screen. */
    private void syncSensorSteps() {
        int unsaved = stepSensor.canRun() ? stepSensor.unsavedSteps(session.getUserId()) : 0;
        if (unsaved <= 0) { load(); return; }
        stepSensor.markSaved(session.getUserId());
        repo.addSteps(unsaved, r -> { if (!isFinishing()) { celebrate(r); load(); } });
    }

    private void showSensorSteps() {
        if (stepSensor.canRun()) {
            stepsChip.setText(String.format(java.util.Locale.US, "%,d", stepSensor.todaySteps()));
        }
    }

    /** EXP pop-up and level-up confetti after any action. */
    private void celebrate(WellnessRepository.ActionResult r) {
        if (r == null || !r.ok) return;
        petAnim.expPop(r.expGained);
        if (!r.unlocked.isEmpty()) load();
        if (r.leveledUp) petAnim.levelUp(r.newLevel);
    }

    private void load() {
        repo.loadSnapshot(s -> {
            if (s == null) { redirectToLogin(); return; }   // account missing: force re-login
            int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
            int greet = h < 12 ? R.string.greet_morning : h < 18 ? R.string.greet_afternoon : R.string.greet_evening;
            greeting.setText(getString(greet) + ", " + s.user.getFirstName() + "!");
            date.setText(DateUtils.friendlyToday());
            Pet pet = s.pet;
            level.setText("Lv." + pet.level);
            expBar.setProgress(pet.exp);
            expText.setText(pet.exp + " / " + Pet.EXP_PER_LEVEL + " EXP");
            PetLook.apply(pet, findViewById(R.id.home_room), hatView, faceView, crown);
            streakView.setText(String.valueOf(s.streak));
            streakView.setAlpha(s.streak > 0 && !s.loggedToday ? 0.55f : 1f);   // faded = log today to keep it
            coinsView.setText(String.valueOf(pet.coins));
            showMood(s.moodToday);
            stepGoal = s.user.stepGoal;
            stepsChip.setText(s.steps > 0 ? String.format(java.util.Locale.US, "%,d", s.steps) : getString(R.string.ui_log_steps));
            boolean sleepy = DateUtils.isSleepyTime();
            petAnim.setSleeping(sleepy);
            speech.setText(sleepy ? pet.name + " is sleepy… Zzz 💤" : s.stats.speech);

            energy.setText(s.stats.energy + "%");
            mood.setText(s.stats.mood);
            gut.setText(s.stats.gutHealth + "%");
            water.setText(String.format(Locale.US, "%d/%d", s.water, s.user.hydrationGoal));

            goalsBox.removeAllViews();
            int done = 0;
            for (DailyGoal g : s.goals) {
                if (g.completed) done++;
                goalsBox.addView(goalRow(g));
            }
            goalCount.setText(done + "/" + s.goals.size());
        });
    }

    private View goalRow(DailyGoal g) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_goal, goalsBox, false);
        ImageView check = row.findViewById(R.id.goal_check);
        TextView title = row.findViewById(R.id.goal_title);
        TextView exp = row.findViewById(R.id.goal_exp);
        title.setText(g.title);
        exp.setText("+" + g.expReward + " EXP");
        if (g.completed) {
            check.setBackgroundResource(R.drawable.bg_pill_pink);
            check.setColorFilter(ContextCompat.getColor(this, R.color.white));
        } else {
            check.setBackgroundResource(R.drawable.bg_circle_white);
            check.setColorFilter(ContextCompat.getColor(this, R.color.pink_light));
            row.setOnClickListener(v -> onGoalTapped(g));
        }
        return row;
    }

    private void onGoalTapped(DailyGoal g) {
        switch (g.goalKey) {
            case DailyGoal.LOG_MEAL: startActivity(new Intent(this, MealLoggerActivity.class)); break;
            case DailyGoal.DRINK_WATER: addWater(); break;
            case DailyGoal.WALK_STEPS: logSteps(); break;
            case DailyGoal.DAILY_QUIZ: showQuiz(); break;
            default: break;
        }
    }

    // ------------------------------------------------------------ mood check-in

    private void showMood(int mood) {
        for (int i = 0; i < MOOD_IDS.length; i++) {
            View b = findViewById(MOOD_IDS[i]);
            boolean sel = mood == i + 1;
            b.setBackgroundResource(sel ? R.drawable.bg_card_pink : R.drawable.bg_tile);
            b.setAlpha(mood == 0 || sel ? 1f : 0.45f);
        }
        TextView label = findViewById(R.id.mood_label);
        label.setText(mood == 0 ? "+3 EXP" : MoodRecord.LABEL[mood] + " · tap to change");
    }

    private void pickMood(int mood, View button) {
        UiUtils.bounce(button);
        showMood(mood);
        repo.saveMood(mood, r -> {
            celebrate(r);
            if (r != null && r.expGained > 0) Feedback.show(this, r, MoodRecord.EMOJI[mood] + " Mood saved");
            if (mood <= 2) {
                speech.setText("I'm sorry today feels hard 💗 I'm right here with you.");
                repo.recentLowMoodDays(low -> {
                    if (low != null && low >= 3) {
                        new NpDialogBuilder(this)
                                .setTitle("Berry is here for you 💗")
                                .setMessage("You've felt low for a few days now. It can really help to talk with "
                                        + "someone you trust, like a friend, family member or counselor.\n\n"
                                        + "If you ever feel unsafe, please reach out right away. In the Philippines "
                                        + "you can call the NCMH Crisis Hotline at 1553.")
                                .setPositiveButton("Thank you", null)
                                .show();
                    }
                });
            } else if (mood >= 4) {
                speech.setText("Yay! Happy you means happy me! 😄");
                petAnim.onTap();
            }
        });
    }

    private void addWater() {
        petAnim.playDrink();
        repo.addWater(1, r -> { Feedback.show(this, r, "💧 +1 cup of water"); celebrate(r); load(); });
    }

    private void logSteps() {
        Dialogs.number(this, "Log steps", "Steps walked", false, 1, 100000, v ->
                repo.addSteps((int) v, r -> { Feedback.show(this, r, "👟 Steps logged"); celebrate(r); load(); }));
    }

    private void logWeight() {
        Dialogs.number(this, "Log weight", "Weight in kg", true, 20, 400, v ->
                repo.addWeight(v, r -> { Feedback.show(this, r, "⚖️ Weight saved"); celebrate(r); load(); }));
    }

    private void showQuiz() {
        QuizBank.Question q = QuizBank.today();
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_quiz, null, false);
        ((TextView) v.findViewById(R.id.quiz_question)).setText(q.text);
        TextView streak = v.findViewById(R.id.quiz_streak);
        repo.getQuizStreak(st -> {
            if (st != null && st > 0) {
                streak.setText(st + "-day streak");
                streak.setVisibility(View.VISIBLE);
            }
        });
        LinearLayout options = v.findViewById(R.id.quiz_options);
        View result = v.findViewById(R.id.quiz_result);
        TextView resultTitle = v.findViewById(R.id.quiz_result_title);
        TextView resultWhy = v.findViewById(R.id.quiz_result_why);
        MaterialButton button = v.findViewById(R.id.quiz_button);

        androidx.appcompat.app.AlertDialog dialog = new NpDialogBuilder(this).setView(v).create();
        final WellnessRepository.ActionResult[] outcome = new WellnessRepository.ActionResult[1];
        dialog.setOnDismissListener(d -> {
            if (outcome[0] != null) { Feedback.show(this, outcome[0], null); celebrate(outcome[0]); }
        });
        button.setOnClickListener(x -> dialog.dismiss());

        View[] rows = new View[q.options.length];
        for (int i = 0; i < q.options.length; i++) {
            View row = LayoutInflater.from(this).inflate(R.layout.item_quiz_option, options, false);
            ((TextView) row.findViewById(R.id.opt_letter)).setText(String.valueOf((char) ('A' + i)));
            ((TextView) row.findViewById(R.id.opt_text)).setText(q.options[i]);
            final int which = i;
            row.setOnClickListener(x -> {
                for (View r : rows) r.setEnabled(false);
                boolean correct = which == q.answer;
                if (correct) com.nutripulse.app.utils.PetSounds.correct(this);
                else com.nutripulse.app.utils.PetSounds.wrong(this);
                markOption(rows[q.answer], true);
                if (!correct) markOption(rows[which], false);
                for (int k = 0; k < rows.length; k++) if (k != q.answer && k != which) rows[k].setAlpha(0.5f);
                UiUtils.bounce(rows[which]);

                resultTitle.setText(getString(correct ? R.string.ui_correct : R.string.ui_not_quite));
                resultTitle.setTextColor(ContextCompat.getColor(this, correct ? R.color.green_ok : R.color.red_error));
                resultTitle.setCompoundDrawablesRelativeWithIntrinsicBounds(
                        correct ? R.drawable.ics_sparkle : R.drawable.ics_lightbulb, 0, 0, 0);
                androidx.core.widget.TextViewCompat.setCompoundDrawableTintList(resultTitle,
                        android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this,
                                correct ? R.color.green_ok : R.color.orange)));
                resultWhy.setText(q.why + (correct ? "" : "\n\nTry again: tap the goal to retry."));
                result.setVisibility(View.VISIBLE);

                button.setText(R.string.ui_continue);
                button.setTextColor(ContextCompat.getColor(this, R.color.white));
                button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(this, R.color.pink_primary)));
                button.setStrokeWidth(0);

                repo.completeQuiz(correct, r -> { outcome[0] = r; load(); });
            });
            rows[i] = row;
            options.addView(row);
        }
        dialog.show();
    }

    private void markOption(View row, boolean correct) {
        row.setBackgroundResource(correct ? R.drawable.bg_option_correct : R.drawable.bg_option_wrong);
        TextView letter = row.findViewById(R.id.opt_letter);
        int c = ContextCompat.getColor(this, correct ? R.color.green_ok : R.color.red_error);
        letter.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
        letter.setTextColor(ContextCompat.getColor(this, R.color.white));
        ImageView mark = row.findViewById(R.id.opt_mark);
        mark.setImageResource(correct ? R.drawable.ic_check : R.drawable.ic_close);
        mark.setImageTintList(android.content.res.ColorStateList.valueOf(c));
        mark.setVisibility(View.VISIBLE);
    }
}
