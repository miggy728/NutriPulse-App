package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.nutripulse.app.models.Pet;

@Dao
public interface PetDao {
    @Insert
    long insert(Pet pet);

    @Update
    void update(Pet pet);

    @Query("SELECT * FROM pets WHERE userId = :userId LIMIT 1")
    Pet getForUser(long userId);
}
