package com.nutripulse.app.data;

/** A food from the built-in catalog. Values are per one serving. */
public class FoodItem {
    public final String name;
    public final String emoji;
    public final String category;     // Meal, Snack, Drink
    public final String serving;      // e.g. "100 g", "1 cup"
    public final int calories;
    public final float protein, carbs, fat;
    public final boolean healthy;
    public final int waterCups;       // drinks that count toward hydration
    /** > 0 when this item is one of the user's own custom foods. */
    public long customId;

    public FoodItem(String name, String emoji, String category, String serving, int calories,
                    float protein, float carbs, float fat, boolean healthy, int waterCups) {
        this.name = name; this.emoji = emoji; this.category = category; this.serving = serving;
        this.calories = calories; this.protein = protein; this.carbs = carbs; this.fat = fat;
        this.healthy = healthy; this.waterCups = waterCups;
    }

    public boolean isCustom() { return customId > 0; }

    public static FoodItem fromCustom(com.nutripulse.app.models.CustomFood c) {
        FoodItem f = new FoodItem(c.name, c.emoji == null || c.emoji.isEmpty() ? "🍽️" : c.emoji, c.category,
                c.serving, c.calories, c.protein, c.carbs, c.fat, c.healthy, 0);
        f.customId = c.id;
        return f;
    }

    /** Rebuilds a per-serving food from a logged meal (used for Recent foods). */
    public static FoodItem fromRecord(com.nutripulse.app.models.MealRecord m) {
        float s = m.servings <= 0 ? 1f : m.servings;
        return new FoodItem(m.foodName, m.emoji == null ? "🍽️" : m.emoji, m.category, "1 serving",
                Math.round(m.calories / s), m.protein / s, m.carbs / s, m.fat / s, m.healthy, 0);
    }
}
