package com.nutripulse.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Keeps track of who is logged in.
 *
 * Only the user's numeric id is stored (never credentials).
 * - "Remember me" ON: the session survives app restarts for up to 30 days.
 * - "Remember me" OFF: the session lasts until the app process is closed;
 *   the splash screen clears it on the next cold start.
 */
public class SessionManager {
    private static final String PREFS = "nutripulse_session";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_REMEMBER = "remember_me";
    private static final String KEY_LOGIN_TIME = "login_time";
    private static final String KEY_LAST_EMAIL = "last_email";
    private static final long REMEMBER_DURATION_MS = 30L * 24 * 60 * 60 * 1000;

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void createSession(long userId, boolean rememberMe, String email) {
        SharedPreferences.Editor e = prefs.edit()
                .putLong(KEY_USER_ID, userId)
                .putBoolean(KEY_REMEMBER, rememberMe)
                .putLong(KEY_LOGIN_TIME, System.currentTimeMillis());
        if (rememberMe) e.putString(KEY_LAST_EMAIL, email); else e.remove(KEY_LAST_EMAIL);
        e.apply();
    }

    public boolean isLoggedIn() { return getUserId() > 0; }

    public long getUserId() { return prefs.getLong(KEY_USER_ID, -1L); }

    public String getRememberedEmail() { return prefs.getString(KEY_LAST_EMAIL, ""); }

    /** Called on cold start (splash). Returns true if the saved session may be restored. */
    public boolean canRestoreSession() {
        if (!isLoggedIn()) return false;
        if (!prefs.getBoolean(KEY_REMEMBER, false)) return false;
        long loginTime = prefs.getLong(KEY_LOGIN_TIME, 0);
        return System.currentTimeMillis() - loginTime < REMEMBER_DURATION_MS;
    }

    /** Ends the session but keeps the remembered email for convenience. */
    public void logout() {
        prefs.edit().remove(KEY_USER_ID).remove(KEY_REMEMBER).remove(KEY_LOGIN_TIME).apply();
    }
}
