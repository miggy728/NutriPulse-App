package com.nutripulse.app.data;

import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.models.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Berry's offline "brain": a friendly, rule-based wellness chatbot.
 *
 * It understands English and common Taglish phrases, and answers using the logged-in
 * user's own data (calories, water, steps, goals, pet). No internet or API key is needed.
 * Everything here is pure Java with no database access, so it is easy to test.
 */
public class ChatBot {

    public static final String ACTION_LOG_WATER = "log_water";

    /** Snapshot of the user's data that Berry can talk about. Built by WellnessRepository. */
    public static class ChatContext {
        public User user;
        public Pet pet;
        public PetStats stats;
        public int calories, water, steps;
        public float protein, carbs, fat;
        public List<DailyGoal> goals = new ArrayList<>();
        public List<MealRecord> meals = new ArrayList<>();
        public List<MealNote> notes = new ArrayList<>();
        public int streak;
        public DietaryPreference preference;
    }

    public static class Reply {
        public final String text;
        public final List<String> suggestions = new ArrayList<>();
        public String action;
        /** Safety replies are always answered by offline Berry, even in AI mode. */
        public boolean safety;

        Reply(String text, String... suggestions) {
            this.text = text;
            this.suggestions.addAll(Arrays.asList(suggestions));
        }
    }

    private final Random rnd = new Random();

    private static final Map<String, String> FOOD_ALIASES = new HashMap<>();
    static {
        FOOD_ALIASES.put("kanin", "Steamed Rice");
        FOOD_ALIASES.put("rice", "Steamed Rice");
        FOOD_ALIASES.put("brown rice", "Brown Rice");
        FOOD_ALIASES.put("itlog", "Boiled Egg");
        FOOD_ALIASES.put("egg", "Boiled Egg");
        FOOD_ALIASES.put("manok", "Chicken Breast");
        FOOD_ALIASES.put("chicken", "Chicken Breast");
        FOOD_ALIASES.put("saging", "Banana");
        FOOD_ALIASES.put("banana", "Banana");
        FOOD_ALIASES.put("mansanas", "Apple");
        FOOD_ALIASES.put("apple", "Apple");
        FOOD_ALIASES.put("mangga", "Mango");
        FOOD_ALIASES.put("mango", "Mango");
        FOOD_ALIASES.put("gatas", "Low-fat Milk");
        FOOD_ALIASES.put("milk", "Low-fat Milk");
        FOOD_ALIASES.put("isda", "Salmon with Veggies");
        FOOD_ALIASES.put("salmon", "Salmon with Veggies");
        FOOD_ALIASES.put("oatmeal", "Oatmeal Bowl");
        FOOD_ALIASES.put("oats", "Oatmeal Bowl");
        FOOD_ALIASES.put("salad", "Grilled Chicken Salad");
        FOOD_ALIASES.put("adobo", "Pork Adobo");
        FOOD_ALIASES.put("sinigang", "Sinigang na Hipon");
        FOOD_ALIASES.put("tinola", "Tinola (Chicken Soup)");
        FOOD_ALIASES.put("pancit", "Pancit Canton");
        FOOD_ALIASES.put("tofu", "Tofu Stir-fry");
        FOOD_ALIASES.put("tokwa", "Tofu Stir-fry");
        FOOD_ALIASES.put("burger", "Cheeseburger");
        FOOD_ALIASES.put("yogurt", "Greek Yogurt");
        FOOD_ALIASES.put("nuts", "Mixed Nuts");
        FOOD_ALIASES.put("mani", "Mixed Nuts");
        FOOD_ALIASES.put("carrot", "Carrot Sticks");
        FOOD_ALIASES.put("chips", "Potato Chips");
        FOOD_ALIASES.put("chocolate", "Chocolate Bar");
        FOOD_ALIASES.put("buko", "Fresh Buko Juice");
        FOOD_ALIASES.put("coconut", "Fresh Buko Juice");
        FOOD_ALIASES.put("green tea", "Green Tea");
        FOOD_ALIASES.put("orange juice", "Orange Juice");
        FOOD_ALIASES.put("milk tea", "Milk Tea");
        FOOD_ALIASES.put("milktea", "Milk Tea");
        FOOD_ALIASES.put("soda", "Soda");
        FOOD_ALIASES.put("sisig", "Pork Sisig");
        FOOD_ALIASES.put("lugaw", "Lugaw");
        FOOD_ALIASES.put("arroz caldo", "Arroz Caldo");
        FOOD_ALIASES.put("champorado", "Champorado");
        FOOD_ALIASES.put("bangus", "Daing na Bangus");
        FOOD_ALIASES.put("inihaw", "Inihaw na Isda");
        FOOD_ALIASES.put("pinakbet", "Pinakbet");
        FOOD_ALIASES.put("monggo", "Ginisang Monggo");
        FOOD_ALIASES.put("munggo", "Ginisang Monggo");
        FOOD_ALIASES.put("chopsuey", "Chopsuey");
        FOOD_ALIASES.put("tortang talong", "Tortang Talong");
        FOOD_ALIASES.put("talong", "Tortang Talong");
        FOOD_ALIASES.put("lumpia", "Lumpiang Shanghai");
        FOOD_ALIASES.put("shanghai", "Lumpiang Shanghai");
        FOOD_ALIASES.put("kare kare", "Kare-Kare");
        FOOD_ALIASES.put("bulalo", "Bulalo");
        FOOD_ALIASES.put("fried chicken", "Fried Chicken");
        FOOD_ALIASES.put("inasal", "Chicken Inasal");
        FOOD_ALIASES.put("bihon", "Pancit Bihon");
        FOOD_ALIASES.put("ginataan", "Ginataang Gulay");
        FOOD_ALIASES.put("pandesal", "Pandesal");
        FOOD_ALIASES.put("ensaymada", "Ensaymada");
        FOOD_ALIASES.put("turon", "Turon");
        FOOD_ALIASES.put("banana cue", "Banana Cue");
        FOOD_ALIASES.put("saba", "Nilagang Saging (Saba)");
        FOOD_ALIASES.put("kamote", "Kamote (Boiled)");
        FOOD_ALIASES.put("puto", "Puto");
        FOOD_ALIASES.put("bibingka", "Bibingka");
        FOOD_ALIASES.put("halo halo", "Halo-Halo");
        FOOD_ALIASES.put("taho", "Taho");
        FOOD_ALIASES.put("fishball", "Fishball");
        FOOD_ALIASES.put("fishballs", "Fishball");
        FOOD_ALIASES.put("calamansi", "Calamansi Juice");
        FOOD_ALIASES.put("salabat", "Salabat (Ginger Tea)");
        FOOD_ALIASES.put("gulaman", "Sago't Gulaman");
        FOOD_ALIASES.put("coffee", "3-in-1 Coffee");
        FOOD_ALIASES.put("kape", "3-in-1 Coffee");
        FOOD_ALIASES.put("black coffee", "Black Coffee");
        FOOD_ALIASES.put("tapsilog", "Tapsilog");
        FOOD_ALIASES.put("longsilog", "Longsilog");
        FOOD_ALIASES.put("sinangag", "Sinangag (Garlic Rice)");
        FOOD_ALIASES.put("garlic rice", "Sinangag (Garlic Rice)");
        FOOD_ALIASES.put("softdrinks", "Soda");
        FOOD_ALIASES.put("coke", "Soda");
    }

    private static final String[] TIPS = {
            "Fill half your plate with vegetables and fruit. It keeps you full with fewer calories. 🥦",
            "Drink a glass of water before each meal. Sometimes thirst feels like hunger! 💧",
            "Choose brown rice sometimes. It has more fiber than white rice. 🍚",
            "Eat slowly! Your tummy needs about 20 minutes to tell your brain it's full. 🐢",
            "Protein at breakfast (like eggs or yogurt) helps keep your energy steady. 🥚",
            "Swap soda or milk tea for water, buko juice or unsweetened tea. 🧋➡️💧",
            "A short walk after meals helps digestion. Even 10 minutes counts! 🚶",
            "Sleep matters too. Tired bodies crave more sugary snacks. 😴",
            "Keep fruit where you can see it, so it's your first snack choice. 🍎",
    };

    private static final String[] JOKES = {
            "Why did the banana go to the doctor? It wasn't peeling well! 🍌",
            "What do you call a sad strawberry? A blueberry! 🫐",
            "Why did the tomato blush? It saw the salad dressing! 🍅",
            "I told my rice a joke… it didn't laugh. Tough crowd, it's always so grain-y! 🍚",
            "Why don't eggs tell jokes? They'd crack each other up! 🥚",
    };

    // ================================================================ public API

    public Reply greeting(ChatContext c) {
        String name = c.user != null ? c.user.getFirstName() : "friend";
        return new Reply("Hi " + name + "! I'm " + petName(c) + " 💗\n"
                + "Ask me about your calories, water, meals, or just chat with me!",
                "What should I eat?", "How many calories today?", "Give me a tip", "What can you do?");
    }

    public Reply reply(String raw, ChatContext c) {
        String m = " " + raw.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9ñ ]", " ")
                .replaceAll("\\s+", " ").trim() + " ";

        if (m.trim().isEmpty()) return new Reply("Hmm? Type something and I'll do my best! 💭", "What can you do?");

        // ---- Safety first
        if (has(m, "kill myself", "suicide", "end my life", "want to die", "self harm", "hurt myself",
                "magpakamatay", "gusto ko mamatay", "ayoko na mabuhay", "saktan ang sarili")) return crisis();
        if (has(m, "starve", "stop eating", "not eating", "purge", "throw up after", "make myself vomit",
                "binge", "hindi na ako kakain", "ayaw ko kumain", "di ako kumakain")) return eatingConcern();

        // ---- Actions
        if (has(m, "log water", "add water", "i drank", " drank ", "uminom ako", "nakainom", "add a cup",
                "log a cup", "log 1 cup")) {
            Reply r = new Reply("Logging 1 cup of water for you! 💧", "How much water today?", "Give me a tip");
            r.action = ACTION_LOG_WATER;
            return r;
        }

        // ---- Short greetings ("hi berry!", "kumusta") get a friendly status
        boolean greet = has(m, " hi ", " hello", " hey ", " kumusta", " musta", " good morning", " good evening",
                " good afternoon", " yo ", " hai ");
        if (greet && m.trim().split(" ").length <= 4) return status(c);

        // ---- Small talk
        if (has(m, " thank", " salamat", " thanks", " ty ")) {
            return new Reply(pick("You're welcome! 💗", "Anytime! That's what buddies are for 🍓",
                    "Walang anuman! 💕"), "Give me a tip", "What should I eat?");
        }
        if (has(m, " joke", " funny", " patawa", " biro")) {
            return new Reply(pick(JOKES) + " 😆", "Another joke!", "Give me a tip");
        }

        // ---- Food lookup (e.g. "how many calories in rice", "itlog?")
        FoodItem food = findFood(m);
        if (food != null && !has(m, " suggest", " recommend", " should i eat", " kakainin")) {
            return foodInfo(food);
        }

        // ---- Personal data
        if (has(m, " streak", " fire ", " sunod sunod")) {
            String t = c.streak == 0
                    ? "No streak yet! Log a meal today to start your 🔥 streak."
                    : "You're on a 🔥 " + c.streak + "-day streak! " + (c.meals.isEmpty()
                    ? "Log something today so you don't lose it!" : "Keep it going tomorrow! 💪");
            return new Reply(t + "\n\nBonus EXP at 3, 7 and 30 days 🎁", "What should I eat?", "How am I doing?");
        }
        if (has(m, " coin", " shop", " buy", " outfit", " hat ", " bili")) {
            int coins = c.pet != null ? c.pet.coins : 0;
            return new Reply("You have 🪙 " + coins + " coins!\nYou earn 1 coin for every EXP. "
                    + "Spend them in My Pet › Berry Shop on hats, glasses and room themes 🎀",
                    "How do I earn EXP?", "What should I eat?");
        }
        if (has(m, " meal plan", " my plan", " my notes", " meal notes", " plano ko", " notes ko", " listahan")) {
            return notesReply(c);
        }
        if (has(m, " what did i eat", " what i ate", " ano kinain", " kinain ko", " my meals", " food log", " diary")) {
            return mealList(c);
        }
        if (has(m, " calorie", " kcal", " calories", " kain ko", " nakain", " ate today", " eaten")) {
            return calories(c);
        }
        if (has(m, " suggest", " recommend", " what should i eat", " what to eat", " kakainin", " kainin",
                " gutom", " hungry", " breakfast", " lunch", " dinner", " merienda", " snack", " meal idea", " ulam")) {
            return suggestMeal(c, m);
        }
        if (has(m, " water", " tubig", " hydrat", " drink", " inom", " thirsty", " uhaw")) {
            return water(c);
        }
        if (has(m, " step", " walk", " lakad", " exercise", " ehersisyo", " workout", " active")) {
            return steps(c);
        }
        if (has(m, " level", " exp ", " xp ", " evolve", " evolution", " berry", " pet ", " alaga")) {
            return pet(c);
        }
        if (has(m, " goal", " task", " to do", " todo", " gagawin")) {
            return goals(c);
        }
        if (has(m, " protein", " carbs", " carb ", " fat ", " fats", " macro")) {
            return macros(c, m);
        }

        // ---- Feelings
        if (has(m, " sad", " stressed", " stress", " tired", " pagod", " malungkot", " lonely", " anxious",
                " bored", " nakakainip")) {
            return mood(m);
        }

        // ---- General knowledge
        if (has(m, " lose weight", " weight loss", " pumayat", " diet", " gain weight", " tumaba", " bmi")) {
            return weightAdvice();
        }
        if (has(m, " fiber", " vitamin", " mineral", " sugar", " asukal", " salt", " sodium", " asin")) {
            return nutrient(m);
        }
        if (has(m, " tip", " advice", " healthy", " payo", " healthier")) {
            return new Reply("💡 " + pick(TIPS), "Another tip", "What should I eat?");
        }
        if (has(m, " help", " what can you do", " commands", " paano", " how to use")) {
            return help();
        }
        if (greet) return status(c);
        if (has(m, " love you", " cute", " ganda", " best")) {
            return new Reply(pick("Aww, you're making me blush! 🍓💗", "You're the best too! 🥰",
                    "*happy berry wiggle* 💕"), "Give me a tip", "How am I doing?");
        }
        if (has(m, " how am i", " how m i", " progress", " status", " report", " summary")) {
            return status(c);
        }
        return fallback();
    }

    // ================================================================ intents

    private Reply status(ChatContext c) {
        String name = c.user != null ? c.user.getFirstName() : "friend";
        StringBuilder sb = new StringBuilder("Hi " + name + "! Here's your day so far:\n");
        sb.append("🍽️ ").append(fmt(c.calories)).append(" / ").append(fmt(goalCal(c))).append(" kcal\n");
        sb.append("💧 ").append(c.water).append(" / ").append(goalWater(c)).append(" cups\n");
        sb.append("👟 ").append(fmt(c.steps)).append(" / ").append(fmt(goalSteps(c))).append(" steps\n");
        int done = 0;
        for (DailyGoal g : c.goals) if (g.completed) done++;
        sb.append("✅ ").append(done).append(" / ").append(c.goals.size()).append(" goals done");
        if (c.streak > 0) sb.append("\n🔥 ").append(c.streak).append("-day streak");
        if (c.stats != null) sb.append("\n\nI'm feeling ").append(c.stats.mood.toLowerCase(Locale.ROOT)).append(" 💗");
        return new Reply(sb.toString(), "What should I eat?", "Log 1 cup of water", "Give me a tip");
    }

    private Reply calories(ChatContext c) {
        int goal = goalCal(c);
        int left = goal - c.calories;
        StringBuilder sb = new StringBuilder();
        sb.append("You've had ").append(fmt(c.calories)).append(" kcal today out of your ")
                .append(fmt(goal)).append(" kcal goal.\n");
        if (c.meals.isEmpty()) {
            sb.append("\nNo food logged yet! Tap the ➕ button to log your first meal 🍳");
        } else if (left > 0) {
            sb.append("You have about ").append(fmt(left)).append(" kcal left. ");
            sb.append(String.format(Locale.US, "\n\nMacros: 🥩 %.0fg protein · 🌾 %.0fg carbs · 🧈 %.0fg fat",
                    c.protein, c.carbs, c.fat));
        } else {
            sb.append("You've reached your goal for today. Light, hydrating choices from here are best 💧");
        }
        return new Reply(sb.toString(), "What should I eat?", "What did I eat today?", "Give me a tip");
    }

    private Reply notesReply(ChatContext c) {
        if (c.notes.isEmpty()) {
            return new Reply("Your meal notes for today are empty 📝\nGo to Diary › My Meal Notes to list your plan!",
                    "What should I eat?", "How many calories today?");
        }
        StringBuilder sb = new StringBuilder("Here's your meal plan for today 📝\n");
        int done = 0;
        for (MealNote n : c.notes) {
            sb.append(n.done ? "\n✅ " : "\n⬜ ").append(n.text);
            if (n.done) done++;
        }
        sb.append(done == c.notes.size() ? "\n\nAll done! Great job sticking to your plan! 🌟"
                : "\n\n" + (c.notes.size() - done) + " item(s) left. You've got this! 💪");
        return new Reply(sb.toString(), "How many calories today?", "Give me a tip");
    }

    private Reply mealList(ChatContext c) {
        if (c.meals.isEmpty()) {
            return new Reply("You haven't logged any food today yet 🍽️ Tap ➕ to add your first meal!",
                    "What should I eat?");
        }
        StringBuilder sb = new StringBuilder("Here's what you've logged today:\n");
        for (MealRecord r : c.meals) {
            sb.append("\n").append(r.emoji == null ? "🍽️" : r.emoji).append(" ").append(r.foodName)
                    .append(" · ").append(r.calories).append(" kcal");
        }
        sb.append("\n\nTotal: ").append(fmt(c.calories)).append(" kcal");
        return new Reply(sb.toString(), "How many calories today?", "What should I eat?");
    }

    private Reply suggestMeal(ChatContext c, String m) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String slot;
        if (has(m, " breakfast", " almusal")) slot = "breakfast";
        else if (has(m, " lunch", " tanghalian")) slot = "lunch";
        else if (has(m, " dinner", " hapunan")) slot = "dinner";
        else if (has(m, " snack", " merienda")) slot = "snack";
        else slot = hour < 10 ? "breakfast" : hour < 14 ? "lunch" : hour < 17 ? "snack" : "dinner";

        int left = goalCal(c) - c.calories;
        String category = "snack".equals(slot) ? "Snack" : "Meal";
        List<FoodItem> options = new ArrayList<>();
        for (FoodItem f : FoodCatalog.byCategory(category, null)) {
            if (!f.healthy || !fitsDiet(f, c.preference)) continue;
            if (left > 0 && f.calories > Math.max(left, 150)) continue;
            options.add(f);
        }
        if (left <= 0) {
            return new Reply("You've already reached your calorie goal today 🎯\n"
                    + "If you're still hungry, try something light like carrot sticks 🥕, an apple 🍎, "
                    + "or a warm cup of green tea 🍵.", "Log 1 cup of water", "Give me a tip");
        }
        if (options.isEmpty()) {
            return new Reply("Hmm, I couldn't find a match in my food list for your preferences. "
                    + "Try updating Dietary Preferences in Settings 🥗", "Give me a tip");
        }
        Collections.shuffle(options, rnd);
        StringBuilder sb = new StringBuilder("Here are some healthy " + slot + " ideas for you:\n");
        for (int i = 0; i < Math.min(3, options.size()); i++) {
            FoodItem f = options.get(i);
            sb.append("\n").append(f.emoji).append(" ").append(f.name).append(" (")
                    .append(f.calories).append(" kcal)");
        }
        sb.append("\n\nYou have about ").append(fmt(left)).append(" kcal left today. Tap ➕ to log it! ");
        if (c.preference != null && !"No preference".equals(c.preference.dietType)) {
            sb.append("\n(I kept your ").append(c.preference.dietType.toLowerCase(Locale.ROOT)).append(" preference in mind 💚)");
        }
        return new Reply(sb.toString(), "Suggest another", "How many calories today?");
    }

    private Reply foodInfo(FoodItem f) {
        String verdict = f.healthy ? "A great choice! 💚" : "Okay as a treat, just enjoy it in moderation 🧡";
        return new Reply(String.format(Locale.US,
                "%s %s (%s)\n🔥 %d kcal\n🥩 Protein: %.1fg\n🌾 Carbs: %.1fg\n🧈 Fat: %.1fg\n\n%s",
                f.emoji, f.name, f.serving, f.calories, f.protein, f.carbs, f.fat, verdict),
                "What should I eat?", "How many calories today?");
    }

    private Reply water(ChatContext c) {
        int goal = goalWater(c);
        int left = goal - c.water;
        String body = left > 0
                ? "You've had " + c.water + " of " + goal + " cups today. Just " + left + " more to go! 💧"
                : "You reached your water goal today (" + c.water + " cups)! Hydration hero! 🏆💧";
        return new Reply(body + "\n\nTip: keep a water bottle near you so you remember to sip.",
                "Log 1 cup of water", "Give me a tip");
    }

    private Reply steps(ChatContext c) {
        int goal = goalSteps(c);
        String body = c.steps >= goal
                ? "Amazing! You walked " + fmt(c.steps) + " steps and hit your goal! 👟✨"
                : "You've logged " + fmt(c.steps) + " of " + fmt(goal) + " steps today.\n"
                + "Try a short walk after your next meal. It helps digestion too! 🚶";
        return new Reply(body + "\n\nLog steps from the Home screen with \"Log Steps\".",
                "Give me a tip", "How am I doing?");
    }

    private Reply pet(ChatContext c) {
        if (c.pet == null) return new Reply("I'm right here! 🍓", "How am I doing?");
        int next = c.pet.nextEvolutionLevel();
        StringBuilder sb = new StringBuilder("I'm " + c.pet.name + ", a " + c.pet.getStageName() + "!\n");
        sb.append("⭐ Level ").append(c.pet.level).append(" · ").append(c.pet.exp).append(" / 100 EXP\n");
        sb.append(next > 0 ? "👑 I evolve at Level " + next + "!\n" : "👑 I'm fully evolved, thanks to you!\n");
        sb.append("\nEarn EXP by logging healthy meals, drinking water, finishing daily goals and playing with me 💗");
        return new Reply(sb.toString(), "What are my goals today?", "What should I eat?");
    }

    private Reply goals(ChatContext c) {
        if (c.goals.isEmpty()) return new Reply("Your goals for today are getting ready. Check the Home screen! 🎯");
        StringBuilder sb = new StringBuilder("Today's goals:\n");
        int done = 0;
        for (DailyGoal g : c.goals) {
            sb.append(g.completed ? "\n✅ " : "\n⬜ ").append(g.title).append("  (+").append(g.expReward).append(" EXP)");
            if (g.completed) done++;
        }
        sb.append(done == c.goals.size() ? "\n\nAll done! You're a superstar! 🌟" : "\n\nYou can do it! 💪");
        return new Reply(sb.toString(), "What should I eat?", "Log 1 cup of water");
    }

    private Reply macros(ChatContext c, String m) {
        String info;
        if (has(m, " protein")) info = "🥩 Protein builds and repairs muscles. Good sources: chicken, fish, eggs, tofu, beans and yogurt.";
        else if (has(m, " carb")) info = "🌾 Carbohydrates are your main energy source. Pick whole grains, fruit and veggies more often than sweets.";
        else if (has(m, " fat")) info = "🧈 Healthy fats help your body absorb vitamins. Get them from nuts, fish and avocado; limit fried food.";
        else info = "Macros are protein, carbs and fat, the three nutrients that give you energy.";
        return new Reply(info + String.format(Locale.US,
                "\n\nToday you've had: %.0fg protein · %.0fg carbs · %.0fg fat.", c.protein, c.carbs, c.fat),
                "Give me a tip", "What should I eat?");
    }

    private Reply nutrient(String m) {
        String info;
        if (has(m, " fiber")) info = "🥦 Fiber helps digestion and keeps you full. Find it in veggies, fruit, oats, brown rice and beans.";
        else if (has(m, " sugar", " asukal")) info = "🍬 Too much added sugar can drain your energy. Watch out for soda, milk tea and sweets.";
        else if (has(m, " salt", " sodium", " asin")) info = "🧂 Too much salt isn't good for your heart. Instant noodles, chips and processed meats are often very salty.";
        else info = "🍊 Vitamins and minerals keep your body working well. Eating many colors of fruits and veggies covers a lot of them!";
        return new Reply(info, "Give me a tip", "What should I eat?");
    }

    private Reply mood(String m) {
        String body;
        if (has(m, " tired", " pagod")) {
            body = "Aww, rest is important too 😴 A glass of water, a balanced snack and some good sleep can really help.";
        } else if (has(m, " bored", " nakakainip")) {
            body = "Bored? Let's play! Visit me in My Pet and tap Play 🎮, or try a quick 10-minute walk 🚶";
        } else {
            body = "I'm sorry you're feeling this way 💗 It's okay to have hard days. Try a few slow breaths, "
                    + "some water, and maybe talk to someone you trust. If these feelings stay for a while, "
                    + "a counselor or doctor can really help.";
        }
        return new Reply(body, "Tell me a joke", "Give me a tip");
    }

    private Reply weightAdvice() {
        return new Reply("Healthy changes are slow and steady 🐢\n"
                + "• Eat regular, balanced meals (don't skip!)\n"
                + "• Fill half your plate with veggies\n"
                + "• Drink water instead of sweet drinks\n"
                + "• Move every day and sleep well\n\n"
                + "You can set a target weight in Settings › Health Goals. For a personal plan, "
                + "a doctor or registered dietitian is the best guide 💚",
                "What should I eat?", "Give me a tip");
    }

    private Reply crisis() {
        return safe("I'm really glad you told me 💗 You matter, and you don't have to go through this alone.\n\n"
                + "Please reach out to someone right now:\n"
                + "📞 NCMH Crisis Hotline (Philippines): 1553\n"
                + "📱 0917-899-8727\n"
                + "🚨 If you're in immediate danger, call 911.\n\n"
                + "Talking to a trusted family member, friend or teacher can help too. I'm just a little berry, "
                + "but real people can support you better than I can.");
    }

    private Reply eatingConcern() {
        return safe("Thank you for sharing that with me 💗 Your body needs regular, nourishing meals "
                + "to feel good, and skipping food or making yourself sick can really hurt you.\n\n"
                + "Please talk to someone you trust, like a family member, a school counselor or a doctor. "
                + "They can help you feel better with food. You deserve care and support 🍓");
    }

    private static Reply safe(String text) {
        Reply r = new Reply(text);
        r.safety = true;
        return r;
    }

    /** True if this reply should be used even when AI mode is on (safety messages and app actions). */
    public static boolean mustUseOffline(Reply r) {
        return r.safety || r.action != null;
    }

    private Reply help() {
        return new Reply("Here's what I can do! 🍓\n"
                + "• \"How many calories today?\"\n"
                + "• \"What should I eat for lunch?\" / \"Ano kakainin ko?\"\n"
                + "• \"How many calories in rice?\" / \"Itlog?\"\n"
                + "• \"Log 1 cup of water\" / \"Uminom ako\"\n"
                + "• \"What are my goals today?\"\n"
                + "• \"What's my meal plan?\"\n"
                + "• \"What level are you?\"\n"
                + "• \"Give me a tip\" or \"Tell me a joke\"",
                "How am I doing?", "What should I eat?", "Tell me a joke");
    }

    private Reply fallback() {
        return new Reply(pick("Hmm, I'm still a little berry and I'm learning! 🌱",
                "Oops, I didn't quite get that 🍓", "Sorry, my leaves didn't catch that! 🌿")
                + "\nTry asking about calories, meals, water, steps, or say \"help\".",
                "What can you do?", "What should I eat?", "Give me a tip");
    }

    // ================================================================ helpers

    private FoodItem findFood(String m) {
        // Longest alias first so "brown rice" beats "rice" and "milk tea" beats "milk"
        List<String> keys = new ArrayList<>(FOOD_ALIASES.keySet());
        keys.sort((a, b) -> b.length() - a.length());
        for (String k : keys) {
            if (m.contains(" " + k + " ") || m.contains(" " + k + "s ")) return FoodCatalog.find(FOOD_ALIASES.get(k));
        }
        return null;
    }

    private static boolean fitsDiet(FoodItem f, DietaryPreference p) {
        if (p == null) return true;
        String n = f.name.toLowerCase(Locale.ROOT);
        String diet = p.dietType == null ? "" : p.dietType.toLowerCase(Locale.ROOT);
        boolean meat = n.contains("chicken") || n.contains("pork") || n.contains("burger") || n.contains("tinola")
                || n.contains("adobo");
        boolean seafood = n.contains("salmon") || n.contains("hipon") || n.contains("fish");
        boolean animal = n.contains("egg") || n.contains("yogurt") || n.contains("milk");
        if (diet.contains("vegan") && (meat || seafood || animal)) return false;
        if (diet.contains("vegetarian") && (meat || seafood)) return false;
        if (diet.contains("pescatarian") && meat) return false;
        if (diet.contains("halal") && n.contains("pork")) return false;
        if (p.avoidFoods != null) {
            for (String avoid : p.avoidFoods.toLowerCase(Locale.ROOT).split("[,;]")) {
                String a = avoid.trim();
                if (a.length() >= 3 && n.contains(a)) return false;
            }
        }
        return true;
    }

    private static boolean has(String m, String... keys) {
        for (String k : keys) if (m.contains(k)) return true;
        return false;
    }

    private String pick(String... options) { return options[rnd.nextInt(options.length)]; }

    private static String petName(ChatContext c) { return c.pet != null ? c.pet.name : "Berry"; }
    private static int goalCal(ChatContext c) { return c.user != null ? c.user.calorieGoal : 2000; }
    private static int goalWater(ChatContext c) { return c.user != null ? c.user.hydrationGoal : 8; }
    private static int goalSteps(ChatContext c) { return c.user != null ? c.user.stepGoal : 7000; }
    private static String fmt(int v) { return String.format(Locale.US, "%,d", v); }
}
