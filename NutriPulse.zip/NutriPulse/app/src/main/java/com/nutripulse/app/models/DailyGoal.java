package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "daily_goals",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey", "goalKey"}, unique = true)})
public class DailyGoal {
    public static final String LOG_MEAL = "log_meal";
    public static final String DRINK_WATER = "drink_water";
    public static final String WALK_STEPS = "walk_steps";
    public static final String DAILY_QUIZ = "daily_quiz";

    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String dateKey = "";
    @NonNull public String goalKey = "";
    @NonNull public String title = "";
    public int expReward;
    public boolean completed;
}
