package com.nutripulse.app.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.nutripulse.app.database.AppDatabase;
import com.nutripulse.app.database.DayTotal;
import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.FavoriteFood;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.MoodRecord;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.models.StepRecord;
import com.nutripulse.app.models.User;
import com.nutripulse.app.models.WaterRecord;
import com.nutripulse.app.models.WeightRecord;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.SessionManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * All wellness data access goes through here.
 *
 * The user id is ALWAYS taken from the active session, never from screen input,
 * and every DAO call is filtered by it. That is what keeps each account's meals,
 * goals, pet and achievements private to that account.
 */
public class WellnessRepository {

    public interface Result<T> { void onResult(T value); }

    /** Everything the Home dashboard needs in one load. */
    public static class Snapshot {
        public User user;
        public Pet pet;
        public PetStats stats;
        public List<DailyGoal> goals = new ArrayList<>();
        public int calories, water, steps, mealsToday;
        public int streak;
        public boolean loggedToday;
        public int moodToday;     // 0 = not checked in yet
    }

    /** Outcome of any action that can award EXP or unlock achievements. */
    public static class ActionResult {
        public boolean ok = true;
        public String error;
        public int expGained;
        public int coinsGained;
        public boolean leveledUp;
        public int newLevel;
        public List<String> completedGoals = new ArrayList<>();
        public List<String> unlocked = new ArrayList<>();
    }

    public static class DayNutrition {
        public int calories, goal;
        public float protein, carbs, fat;
        public List<MealRecord> meals = new ArrayList<>();
    }

    public static class ChartData {
        public List<String> labels = new ArrayList<>();
        public List<Float> values = new ArrayList<>();   // Float.NaN = no data
        public String unit = "";
        public float goal;
    }

    public static class ProgressSummary {
        public Float weightChange;       // null = not enough data
        public Float latestWeight;
        public int goalProgressPercent;  // -1 = no weight goal set
        public int totalCalories30d;
    }

    private static final String TAG = "WellnessRepository";
    private static final int CARE_DAILY_LIMIT = 3;

    private final AppDatabase db;
    private final long userId;
    private final SharedPreferences carePrefs;

    public WellnessRepository(Context context) {
        db = AppDatabase.get(context);
        userId = new SessionManager(context).getUserId();
        carePrefs = context.getApplicationContext()
                .getSharedPreferences("nutripulse_care", Context.MODE_PRIVATE);
    }

    public long userId() { return userId; }

    private <T> void run(Callable<T> work, Result<T> cb) {
        AppExecutors.io(() -> {
            T value = null;
            if (userId > 0) {
                try {
                    value = work.call();
                } catch (Exception e) {
                    Log.e(TAG, "database error", e);
                }
            }
            final T out = value;
            AppExecutors.main(() -> cb.onResult(out));
        });
    }

    // =============================================================== USER / PROFILE

    public void getUser(Result<User> cb) {
        run(() -> db.userDao().findById(userId), cb);
    }

    public void updateProfile(String fullName, String photoUri, Result<User> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            if (u == null) return null;
            if (fullName != null && !fullName.trim().isEmpty()) u.fullName = fullName.trim();
            if (photoUri != null) u.profilePictureUri = photoUri;
            db.userDao().update(u);
            return u;
        }, cb);
    }

    public void updateGoals(int calories, int cups, float weightGoal, int steps, Result<User> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            if (u == null) return null;
            u.calorieGoal = calories;
            u.hydrationGoal = cups;
            u.weightGoal = weightGoal;
            u.stepGoal = steps;
            db.userDao().update(u);
            String today = DateUtils.todayKey();
            db.goalDao().renameGoal(userId, today, DailyGoal.DRINK_WATER, UserInitializer.waterTitle(cups));
            db.goalDao().renameGoal(userId, today, DailyGoal.WALK_STEPS, UserInitializer.stepsTitle(steps));
            return u;
        }, cb);
    }

    public void getPreference(Result<DietaryPreference> cb) {
        run(() -> {
            DietaryPreference p = db.goalDao().preference(userId);
            if (p == null) { p = new DietaryPreference(); p.userId = userId; }
            return p;
        }, cb);
    }

    public void savePreference(String dietType, String avoid, Result<Boolean> cb) {
        run(() -> {
            DietaryPreference p = new DietaryPreference();
            p.userId = userId;               // always the session user
            p.dietType = dietType;
            p.avoidFoods = avoid;
            db.goalDao().savePreference(p);
            return true;
        }, cb);
    }

    // =============================================================== HOME

    public void loadSnapshot(Result<Snapshot> cb) {
        run(() -> {
            Snapshot s = new Snapshot();
            s.user = db.userDao().findById(userId);
            if (s.user == null) return null;
            String today = DateUtils.todayKey();
            ensureGoals(s.user, today);
            s.pet = ensurePet();
            s.goals = db.goalDao().goalsForDay(userId, today);
            s.calories = db.mealDao().caloriesForDay(userId, today);
            s.water = db.trackingDao().waterForDay(userId, today);
            s.steps = db.trackingDao().stepsForDay(userId, today);
            List<MealRecord> meals = db.mealDao().getMealsForDay(userId, today);
            s.mealsToday = meals.size();
            int healthy = db.mealDao().countHealthyMealsForDay(userId, today);
            s.stats = PetStats.calculate(s.calories, s.user.calorieGoal, s.water,
                    s.user.hydrationGoal, healthy, s.mealsToday);
            s.streak = currentStreak();
            s.loggedToday = s.mealsToday > 0;
            MoodRecord mood = db.moodDao().forDay(userId, today);
            s.moodToday = mood == null ? 0 : mood.mood;
            return s;
        }, cb);
    }

    /** Everything Berry the chatbot can talk about, for the logged-in user only. */
    public void loadChatContext(Result<ChatBot.ChatContext> cb) {
        run(() -> {
            ChatBot.ChatContext c = new ChatBot.ChatContext();
            c.user = db.userDao().findById(userId);
            if (c.user == null) return null;
            String today = DateUtils.todayKey();
            ensureGoals(c.user, today);
            c.pet = ensurePet();
            c.goals = db.goalDao().goalsForDay(userId, today);
            c.meals = db.mealDao().getMealsForDay(userId, today);
            for (MealRecord m : c.meals) {
                c.calories += m.calories;
                c.protein += m.protein;
                c.carbs += m.carbs;
                c.fat += m.fat;
            }
            c.water = db.trackingDao().waterForDay(userId, today);
            c.steps = db.trackingDao().stepsForDay(userId, today);
            int healthy = db.mealDao().countHealthyMealsForDay(userId, today);
            c.stats = PetStats.calculate(c.calories, c.user.calorieGoal, c.water,
                    c.user.hydrationGoal, healthy, c.meals.size());
            c.preference = db.goalDao().preference(userId);
            c.notes = db.mealDao().notesForDay(userId, today);
            c.streak = currentStreak();
            return c;
        }, cb);
    }

    private void ensureGoals(User user, String dateKey) {
        if (db.goalDao().goalsForDay(userId, dateKey).isEmpty()) {
            db.goalDao().insertGoals(UserInitializer.dailyGoalsFor(user, dateKey));
        }
    }

    private Pet ensurePet() {
        Pet pet = db.petDao().getForUser(userId);
        if (pet == null) {
            pet = new Pet();
            pet.userId = userId;
            pet.createdAt = System.currentTimeMillis();
            pet.id = db.petDao().insert(pet);
        }
        return pet;
    }

    // =============================================================== LOGGING

    public void logMeal(FoodItem food, String category, float servings, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            String today = DateUtils.todayKey();
            MealRecord m = new MealRecord();
            m.userId = userId;
            m.foodName = food.name;
            m.emoji = food.emoji;
            m.category = category;
            m.servings = servings;
            m.calories = Math.round(food.calories * servings);
            m.protein = food.protein * servings;
            m.carbs = food.carbs * servings;
            m.fat = food.fat * servings;
            m.healthy = food.healthy;
            m.dateKey = today;
            m.timestamp = System.currentTimeMillis();
            db.mealDao().insertMeal(m);

            if (food.waterCups > 0) {
                insertWater(Math.round(food.waterCups * servings));
            }

            Pet pet = ensurePet();
            // EXP only for the first 6 foods a day, so logging/deleting can't be used to farm EXP
            if (db.foodDao().mealsForDayCount(userId, today) <= 6) addExp(pet, food.healthy ? 5 : 2, r);
            if (food.healthy && !"Drink".equals(category)) completeGoal(pet, DailyGoal.LOG_MEAL, r);
            checkWaterGoal(pet, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    public void addWater(int cups, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            insertWater(cups);
            Pet pet = ensurePet();
            addExp(pet, 1, r);
            checkWaterGoal(pet, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    private void insertWater(int cups) {
        WaterRecord w = new WaterRecord();
        w.userId = userId;
        w.cups = cups;
        w.dateKey = DateUtils.todayKey();
        w.timestamp = System.currentTimeMillis();
        db.trackingDao().insertWater(w);
    }

    public void addSteps(int steps, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            StepRecord s = new StepRecord();
            s.userId = userId;
            s.steps = steps;
            s.dateKey = DateUtils.todayKey();
            s.timestamp = System.currentTimeMillis();
            db.trackingDao().insertSteps(s);
            User u = db.userDao().findById(userId);
            Pet pet = ensurePet();
            if (u != null && db.trackingDao().stepsForDay(userId, s.dateKey) >= u.stepGoal) {
                completeGoal(pet, DailyGoal.WALK_STEPS, r);
            }
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    public void addWeight(float kg, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            WeightRecord w = new WeightRecord();
            w.userId = userId;
            w.weightKg = kg;
            w.dateKey = DateUtils.todayKey();
            w.timestamp = System.currentTimeMillis();
            db.trackingDao().insertWeight(w);
            Pet pet = ensurePet();
            addExp(pet, 2, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    public void completeQuiz(boolean correct, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            Pet pet = ensurePet();
            if (correct) completeGoal(pet, DailyGoal.DAILY_QUIZ, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    // =============================================================== PET

    public void getPet(Result<Pet> cb) {
        run(this::ensurePet, cb);
    }

    public void renamePet(String name, Result<Pet> cb) {
        run(() -> {
            Pet pet = ensurePet();
            pet.name = name.trim();
            db.petDao().update(pet);
            return pet;
        }, cb);
    }

    /** Care activities: "feed" (+10), "water" (+5), "play" (+5). Max 3 of each per day. */
    public void careAction(String action, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            String key = "care_" + userId + "_" + action + "_" + DateUtils.todayKey();
            int used = carePrefs.getInt(key, 0);
            if (used >= CARE_DAILY_LIMIT) {
                r.ok = false;
                r.error = "Berry has had enough of that today. Try again tomorrow!";
                return r;
            }
            carePrefs.edit().putInt(key, used + 1).apply();
            int exp = "feed".equals(action) ? 10 : 5;
            Pet pet = ensurePet();
            addExp(pet, exp, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    /** Mini-game reward: 1 EXP per 2 points (max 15), for the first 3 games each day. */
    public void rewardGame(int score, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            String key = "game_" + userId + "_" + DateUtils.todayKey();
            int played = carePrefs.getInt(key, 0);
            carePrefs.edit().putInt(key, played + 1).apply();
            if (played >= 3) {
                r.ok = false;
                r.error = "You've earned today's game rewards. Play just for fun! 🎮";
                return r;
            }
            Pet pet = ensurePet();
            addExp(pet, Math.min(15, score / 2), r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    public int careRemaining(String action) {
        String key = "care_" + userId + "_" + action + "_" + DateUtils.todayKey();
        return Math.max(0, CARE_DAILY_LIMIT - carePrefs.getInt(key, 0));
    }

    // =============================================================== MEAL PLANNER

    public void getPlans(String dateKey, Result<List<MealPlan>> cb) {
        run(() -> {
            List<MealPlan> plans = db.mealDao().getPlansForDay(userId, dateKey);
            if (plans.isEmpty()) {
                db.mealDao().insertPlan(plan(dateKey, "Breakfast", "Oatmeal Bowl", "🥣", 350));
                db.mealDao().insertPlan(plan(dateKey, "Lunch", "Grilled Chicken Salad", "🥗", 450));
                db.mealDao().insertPlan(plan(dateKey, "Dinner", "Salmon with Veggies", "🐟", 520));
                plans = db.mealDao().getPlansForDay(userId, dateKey);
            }
            return plans;
        }, cb);
    }

    private MealPlan plan(String dateKey, String slot, String name, String emoji, int kcal) {
        MealPlan p = new MealPlan();
        p.userId = userId;
        p.dateKey = dateKey;
        p.slot = slot;
        p.name = name;
        p.emoji = emoji;
        p.calories = kcal;
        return p;
    }

    public void editPlan(long planId, String name, int calories, Result<Boolean> cb) {
        run(() -> {
            MealPlan p = db.mealDao().getPlan(userId, planId);   // ownership check
            if (p == null) return false;
            p.name = name.trim();
            p.calories = calories;
            FoodItem f = FoodCatalog.find(p.name);
            p.emoji = f != null ? f.emoji : "🍽️";
            db.mealDao().updatePlan(p);
            return true;
        }, cb);
    }

    /** Ticking a planned meal for TODAY also logs it to the diary. */
    public void setPlanCompleted(long planId, boolean completed, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            MealPlan p = db.mealDao().getPlan(userId, planId);
            if (p == null || p.completed == completed) return r;
            p.completed = completed;
            db.mealDao().updatePlan(p);
            if (completed && p.dateKey.equals(DateUtils.todayKey())) {
                FoodItem f = FoodCatalog.find(p.name);
                MealRecord m = new MealRecord();
                m.userId = userId;
                m.foodName = p.name;
                m.emoji = p.emoji;
                m.category = "Meal";
                m.calories = p.calories;
                if (f != null) { m.protein = f.protein; m.carbs = f.carbs; m.fat = f.fat; }
                m.healthy = f == null || f.healthy;
                m.dateKey = p.dateKey;
                m.timestamp = System.currentTimeMillis();
                db.mealDao().insertMeal(m);
                Pet pet = ensurePet();
                addExp(pet, 5, r);
                if (m.healthy) completeGoal(pet, DailyGoal.LOG_MEAL, r);
                checkAchievements(pet, r);
            }
            return r;
        }, cb);
    }

    // ---- Food library: built-in + custom, favorites, recent

    public static final String MODE_ALL = "all", MODE_FAVORITES = "favorites", MODE_RECENT = "recent", MODE_MINE = "mine";

    public static class FoodLibrary {
        public List<FoodItem> items = new ArrayList<>();
        public Set<String> favorites = new HashSet<>();   // lower-case names
    }

    public void getFoodLibrary(String category, String query, String mode, Result<FoodLibrary> cb) {
        run(() -> {
            FoodLibrary lib = new FoodLibrary();
            for (String n : db.foodDao().favoriteNames(userId)) lib.favorites.add(n.toLowerCase(Locale.ROOT));
            String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
            List<FoodItem> source = new ArrayList<>();
            switch (mode) {
                case MODE_FAVORITES:
                    for (String name : db.foodDao().favoriteNames(userId)) {
                        FoodItem f = resolve(name);
                        if (f != null) source.add(f);
                    }
                    break;
                case MODE_RECENT:
                    for (MealRecord m : db.foodDao().recentMeals(userId)) {
                        FoodItem f = resolve(m.foodName);
                        source.add(f != null ? f : FoodItem.fromRecord(m));
                    }
                    break;
                case MODE_MINE:
                    for (CustomFood c : db.foodDao().customFoods(userId)) source.add(FoodItem.fromCustom(c));
                    break;
                default:
                    for (CustomFood c : db.foodDao().customFoods(userId)) {
                        if (c.category.equals(category)) source.add(FoodItem.fromCustom(c));
                    }
                    source.addAll(FoodCatalog.byCategory(category, null));
            }
            for (FoodItem f : source) {
                if (q.isEmpty() || f.name.toLowerCase(Locale.ROOT).contains(q)) lib.items.add(f);
            }
            return lib;
        }, cb);
    }

    /** Finds a food by name: the user's custom foods first, then the built-in catalog. */
    private FoodItem resolve(String name) {
        for (CustomFood c : db.foodDao().customFoods(userId)) {
            if (c.name.equalsIgnoreCase(name)) return FoodItem.fromCustom(c);
        }
        FoodItem f = FoodCatalog.find(name);
        if (f != null) return f;
        MealRecord last = db.foodDao().lastMealNamed(userId, name);
        return last != null ? FoodItem.fromRecord(last) : null;
    }

    /** Returns null on success, or an error message. */
    public void addCustomFood(CustomFood food, Result<String> cb) {
        run(() -> {
            food.name = food.name.trim();
            if (db.foodDao().countCustomNamed(userId, food.name) > 0) return "You already have a food named \"" + food.name + "\"";
            food.userId = userId;
            food.createdAt = System.currentTimeMillis();
            db.foodDao().insertCustom(food);
            return "";
        }, cb);
    }

    public void deleteCustomFood(long id, Result<Boolean> cb) {
        run(() -> { db.foodDao().deleteCustom(userId, id); return true; }, cb);
    }

    /** Toggles a favorite; returns true if it is now a favorite. */
    public void toggleFavorite(String foodName, Result<Boolean> cb) {
        run(() -> {
            String key = foodName.trim();
            for (String n : db.foodDao().favoriteNames(userId)) {
                if (n.equalsIgnoreCase(key)) {
                    db.foodDao().deleteFavorite(userId, n);
                    return false;
                }
            }
            FavoriteFood fav = new FavoriteFood();
            fav.userId = userId;
            fav.foodName = key;
            fav.createdAt = System.currentTimeMillis();
            db.foodDao().insertFavorite(fav);
            return true;
        }, cb);
    }

    /** Change the number of servings of a logged meal; nutrition is rescaled. */
    public void editMealServings(long mealId, float newServings, Result<Boolean> cb) {
        run(() -> {
            MealRecord m = db.foodDao().meal(userId, mealId);    // ownership check
            if (m == null || newServings <= 0) return false;
            float old = m.servings <= 0 ? 1f : m.servings;
            float k = newServings / old;
            db.foodDao().updateMealAmounts(userId, mealId, newServings, Math.round(m.calories * k),
                    m.protein * k, m.carbs * k, m.fat * k);
            return true;
        }, cb);
    }

    public void deleteMeal(long mealId, Result<Boolean> cb) {
        run(() -> { db.foodDao().deleteMeal(userId, mealId); return true; }, cb);
    }

    // ---- Copy plans and notes between days

    /** Copies the meal plan and notes of {@code fromKey} onto each day in {@code toKeys}. */
    public void copyDay(String fromKey, List<String> toKeys, Result<Integer> cb) {
        run(() -> {
            List<MealPlan> plans = db.mealDao().getPlansForDay(userId, fromKey);
            List<MealNote> notes = db.mealDao().notesForDay(userId, fromKey);
            int copied = 0;
            for (String to : toKeys) {
                if (to.equals(fromKey)) continue;
                for (MealPlan p : plans) {
                    List<MealPlan> existing = db.mealDao().getPlansForDay(userId, to);
                    MealPlan target = null;
                    for (MealPlan e : existing) if (e.slot.equals(p.slot)) target = e;
                    if (target == null) {
                        MealPlan n = plan(to, p.slot, p.name, p.emoji, p.calories);
                        db.mealDao().insertPlan(n);
                    } else {
                        target.name = p.name;
                        target.emoji = p.emoji;
                        target.calories = p.calories;
                        target.completed = false;
                        db.mealDao().updatePlan(target);
                    }
                }
                long now = System.currentTimeMillis();
                for (int i = 0; i < notes.size(); i++) {
                    MealNote n = new MealNote();
                    n.userId = userId;
                    n.dateKey = to;
                    n.text = notes.get(i).text;
                    n.createdAt = now + i;
                    db.mealDao().insertNote(n);
                }
                copied++;
            }
            return copied;
        }, cb);
    }

    // ---- Meal notes ("My Meal Notes" list in the Diary)

    public void getNotes(String dateKey, Result<List<MealNote>> cb) {
        run(() -> db.mealDao().notesForDay(userId, dateKey), cb);
    }

    /** Adds one or more lines (text pasted with several lines becomes several items). */
    public void addNotes(String dateKey, List<String> lines, Result<Boolean> cb) {
        run(() -> {
            long now = System.currentTimeMillis();
            for (int i = 0; i < lines.size(); i++) {
                String t = lines.get(i).trim();
                if (t.isEmpty()) continue;
                MealNote n = new MealNote();
                n.userId = userId;               // always the session user
                n.dateKey = dateKey;
                n.text = t.length() > 120 ? t.substring(0, 120) : t;
                n.createdAt = now + i;           // keeps the pasted order
                db.mealDao().insertNote(n);
            }
            return true;
        }, cb);
    }

    public void setNoteDone(long noteId, boolean done, Result<Boolean> cb) {
        run(() -> { db.mealDao().setNoteDone(userId, noteId, done); return true; }, cb);
    }

    public void editNote(long noteId, String text, Result<Boolean> cb) {
        run(() -> { db.mealDao().setNoteText(userId, noteId, text.trim()); return true; }, cb);
    }

    public void deleteNote(long noteId, Result<Boolean> cb) {
        run(() -> { db.mealDao().deleteNote(userId, noteId); return true; }, cb);
    }

    public void clearDoneNotes(String dateKey, Result<Boolean> cb) {
        run(() -> { db.mealDao().clearDoneNotes(userId, dateKey); return true; }, cb);
    }

    public void getDayNutrition(String dateKey, Result<DayNutrition> cb) {
        run(() -> {
            DayNutrition n = new DayNutrition();
            User u = db.userDao().findById(userId);
            n.goal = u != null ? u.calorieGoal : 2000;
            n.meals = db.mealDao().getMealsForDay(userId, dateKey);
            for (MealRecord m : n.meals) {
                n.calories += m.calories;
                n.protein += m.protein;
                n.carbs += m.carbs;
                n.fat += m.fat;
            }
            return n;
        }, cb);
    }

    // =============================================================== PROGRESS

    /**
     * @param metric "weight", "calories", "steps" or "water"
     * @param range  "7D", "30D", "3M", "6M" or "1Y"
     */
    public void getChart(String metric, String range, Result<ChartData> cb) {
        run(() -> {
            int buckets, bucketDays;
            String labelPattern;
            switch (range) {
                case "30D": buckets = 30; bucketDays = 1; labelPattern = "d"; break;
                case "3M": buckets = 13; bucketDays = 7; labelPattern = "d MMM"; break;
                case "6M": buckets = 26; bucketDays = 7; labelPattern = "d MMM"; break;
                case "1Y": buckets = 12; bucketDays = 30; labelPattern = "MMM"; break;
                default: buckets = 7; bucketDays = 1; labelPattern = "EEE"; break;
            }
            int totalDays = buckets * bucketDays;
            String fromKey = DateUtils.daysAgoKey(totalDays - 1);

            User u = db.userDao().findById(userId);
            ChartData data = new ChartData();
            List<DayTotal> rows;
            boolean averageMode = true;
            switch (metric) {
                case "calories":
                    rows = db.mealDao().dailyCalories(userId, fromKey);
                    data.unit = "kcal";
                    data.goal = u != null ? u.calorieGoal : 0;
                    break;
                case "steps":
                    rows = db.trackingDao().dailySteps(userId, fromKey);
                    data.unit = "steps";
                    data.goal = u != null ? u.stepGoal : 0;
                    break;
                case "mood":
                    rows = db.moodDao().dailyMood(userId, fromKey);
                    data.unit = "/5";
                    data.goal = 0;
                    break;
                case "water":
                    rows = db.trackingDao().dailyWater(userId, fromKey);
                    data.unit = "cups";
                    data.goal = u != null ? u.hydrationGoal : 0;
                    break;
                default:
                    rows = db.trackingDao().dailyWeight(userId, fromKey);
                    data.unit = "kg";
                    data.goal = u != null ? u.weightGoal : 0;
                    averageMode = false;
            }
            Map<String, Float> byDay = new HashMap<>();
            for (DayTotal t : rows) byDay.put(t.dateKey, t.total);

            Calendar cursor = Calendar.getInstance();
            cursor.add(Calendar.DAY_OF_YEAR, -(totalDays - 1));
            for (int b = 0; b < buckets; b++) {
                data.labels.add(DateUtils.format(labelPattern, cursor));
                float sum = 0; int count = 0; Float last = null;
                for (int d = 0; d < bucketDays; d++) {
                    Float v = byDay.get(DateUtils.keyOf(cursor));
                    if (v != null) { sum += v; count++; last = v; }
                    cursor.add(Calendar.DAY_OF_YEAR, 1);
                }
                if (!averageMode) {
                    data.values.add(last == null ? Float.NaN : last);
                } else if (bucketDays == 1) {
                    data.values.add(count == 0 ? 0f : sum);
                } else {
                    data.values.add(count == 0 ? 0f : sum / count);   // average per logged day
                }
            }
            return data;
        }, cb);
    }

    public void getProgressSummary(Result<ProgressSummary> cb) {
        run(() -> {
            ProgressSummary s = new ProgressSummary();
            User u = db.userDao().findById(userId);
            List<WeightRecord> month = db.trackingDao().weightsSince(userId, DateUtils.daysAgoKey(29));
            WeightRecord latest = db.trackingDao().latestWeight(userId);
            if (latest != null) s.latestWeight = latest.weightKg;
            if (month.size() >= 2) {
                s.weightChange = month.get(month.size() - 1).weightKg - month.get(0).weightKg;
            }
            s.goalProgressPercent = -1;
            if (u != null && u.weightGoal > 0 && latest != null) {
                List<WeightRecord> all = db.trackingDao().weightsSince(userId, "0000-00-00");
                float start = all.isEmpty() ? latest.weightKg : all.get(0).weightKg;
                float totalNeeded = start - u.weightGoal;
                if (Math.abs(totalNeeded) < 0.05f) {
                    s.goalProgressPercent = 100;
                } else {
                    float done = start - latest.weightKg;
                    s.goalProgressPercent = Math.max(0, Math.min(100, Math.round(done / totalNeeded * 100)));
                }
            }
            s.totalCalories30d = db.mealDao().caloriesSince(userId, DateUtils.daysAgoKey(29));
            return s;
        }, cb);
    }

    // =============================================================== ACHIEVEMENTS

    public void getAchievements(Result<List<Achievement>> cb) {
        run(() -> {
            // IGNORE on conflict: adds any new achievements without touching unlocked ones
            db.goalDao().insertAchievements(Achievements.defaultsFor(userId));
            return db.goalDao().achievements(userId);
        }, cb);
    }

    // =============================================================== internal rules

    private void addExp(Pet pet, int amount, ActionResult r) {
        if (amount <= 0) return;
        pet.exp += amount;
        pet.coins += amount;          // 1 coin for every EXP point
        r.expGained += amount;
        r.coinsGained += amount;
        while (pet.exp >= Pet.EXP_PER_LEVEL) {
            pet.exp -= Pet.EXP_PER_LEVEL;
            pet.level++;
            r.leveledUp = true;
        }
        r.newLevel = pet.level;
        db.petDao().update(pet);
    }

    private void completeGoal(Pet pet, String goalKey, ActionResult r) {
        String today = DateUtils.todayKey();
        DailyGoal g = db.goalDao().goal(userId, today, goalKey);
        if (g == null) {
            User u = db.userDao().findById(userId);
            if (u == null) return;
            ensureGoals(u, today);
            g = db.goalDao().goal(userId, today, goalKey);
        }
        if (g != null && !g.completed) {
            g.completed = true;
            db.goalDao().updateGoal(g);
            r.completedGoals.add(g.title);
            addExp(pet, g.expReward, r);
        }
    }

    private void checkWaterGoal(Pet pet, ActionResult r) {
        User u = db.userDao().findById(userId);
        if (u != null && db.trackingDao().waterForDay(userId, DateUtils.todayKey()) >= u.hydrationGoal) {
            completeGoal(pet, DailyGoal.DRINK_WATER, r);
        }
    }

    private void checkAchievements(Pet pet, ActionResult r) {
        User u = db.userDao().findById(userId);
        if (u == null) return;
        String today = DateUtils.todayKey();
        boolean allGoalsDone = true;
        List<DailyGoal> goals = db.goalDao().goalsForDay(userId, today);
        for (DailyGoal g : goals) if (!g.completed) { allGoalsDone = false; break; }

        unlockIf(Achievements.FIRST_MEAL, db.mealDao().countMeals(userId) >= 1, r);
        unlockIf(Achievements.HEALTHY_EATER, db.mealDao().countHealthyMeals(userId) >= 5, r);
        unlockIf(Achievements.HYDRATION_HERO,
                db.trackingDao().waterForDay(userId, today) >= u.hydrationGoal, r);
        unlockIf(Achievements.ACTIVE_DAY, !goals.isEmpty() && allGoalsDone, r);
        unlockIf(Achievements.STEP_STAR, db.trackingDao().stepsForDay(userId, today) >= u.stepGoal, r);
        unlockIf(Achievements.WEIGH_IN, db.trackingDao().countWeights(userId) >= 3, r);
        int streak = currentStreak();
        if (unlockIf(Achievements.STREAK_3, streak >= 3, r)) addExp(pet, 15, r);
        if (unlockIf(Achievements.STREAK_7, streak >= 7, r)) addExp(pet, 30, r);
        if (unlockIf(Achievements.STREAK_30, streak >= 30, r)) addExp(pet, 100, r);
        unlockIf(Achievements.SHOPPER, pet.ownedItems != 0, r);
        unlockIf(Achievements.LEVEL_UP, pet.level >= 2, r);
        unlockIf(Achievements.BLOOM, pet.level >= 5, r);
    }

    /** Returns true only when the achievement is unlocked right now. */
    private boolean unlockIf(String key, boolean condition, ActionResult r) {
        if (!condition) return false;
        Achievement a = db.goalDao().achievement(userId, key);
        if (a == null) {
            db.goalDao().insertAchievements(Achievements.defaultsFor(userId));
            a = db.goalDao().achievement(userId, key);
        }
        if (a != null && !a.unlocked) {
            a.unlocked = true;
            a.unlockedAt = System.currentTimeMillis();
            db.goalDao().updateAchievement(a);
            r.unlocked.add(a.title);
            return true;
        }
        return false;
    }

    // =============================================================== WEEKLY CHALLENGES

    public void getChallenges(Result<List<Challenges.Status>> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            if (u == null) return null;
            String from = DateUtils.keyOf(Challenges.weekStart());
            List<Challenges.Status> out = new ArrayList<>();
            for (Challenges.Def def : Challenges.thisWeek(from)) {
                Challenges.Status s = new Challenges.Status();
                s.def = def;
                s.progress = Math.min(def.target, challengeProgress(def.id, from, u));
                s.claimed = carePrefs.getBoolean(claimKey(from, def.id), false);
                out.add(s);
            }
            return out;
        }, cb);
    }

    private int challengeProgress(String id, String from, User u) {
        switch (id) {
            case "water_days": {
                int n = 0;
                for (DayTotal t : db.trackingDao().dailyWater(userId, from)) if (t.total >= u.hydrationGoal) n++;
                return n;
            }
            case "log_days": {
                int n = 0;
                for (String d : db.mealDao().loggedDays(userId)) if (d.compareTo(from) >= 0) n++;
                return n;
            }
            case "healthy_meals":
                return db.mealDao().countHealthySince(userId, from);
            case "veggies": {
                int n = 0;
                for (String name : db.mealDao().namesSince(userId, from)) if (Challenges.isVeggie(name)) n++;
                return n;
            }
            case "fruit": {
                int n = 0;
                for (String name : db.mealDao().namesSince(userId, from)) if (Challenges.isFruit(name)) n++;
                return n;
            }
            case "steps_total": {
                int n = 0;
                for (DayTotal t : db.trackingDao().dailySteps(userId, from)) n += Math.round(t.total);
                return n;
            }
            case "mood_days":
                return db.moodDao().since(userId, from).size();
            case "quiz_days": {
                int n = 0;
                for (String d : db.goalDao().completedDays(userId, DailyGoal.DAILY_QUIZ)) if (d.compareTo(from) >= 0) n++;
                return n;
            }
            case "all_goals_days": {
                Map<String, int[]> perDay = new HashMap<>();    // dateKey -> {done, total}
                for (DailyGoal g : db.goalDao().goalsSince(userId, from)) {
                    int[] c = perDay.get(g.dateKey);
                    if (c == null) { c = new int[2]; perDay.put(g.dateKey, c); }
                    c[1]++;
                    if (g.completed) c[0]++;
                }
                int n = 0;
                for (int[] c : perDay.values()) if (c[1] > 0 && c[0] == c[1]) n++;
                return n;
            }
            default:
                return 0;
        }
    }

    /** Claims the reward for a finished challenge (once per week). */
    public void claimChallenge(String challengeId, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            User u = db.userDao().findById(userId);
            String from = DateUtils.keyOf(Challenges.weekStart());
            String key = claimKey(from, challengeId);
            Challenges.Def def = null;
            for (Challenges.Def d : Challenges.thisWeek(from)) if (d.id.equals(challengeId)) def = d;
            if (u == null || def == null || carePrefs.getBoolean(key, false)
                    || challengeProgress(def.id, from, u) < def.target) {
                r.ok = false;
                r.error = "This challenge isn't ready to claim yet.";
                return r;
            }
            carePrefs.edit().putBoolean(key, true).apply();
            Pet pet = ensurePet();
            addExp(pet, Challenges.REWARD_EXP, r);
            checkAchievements(pet, r);
            return r;
        }, cb);
    }

    private String claimKey(String weekKey, String id) { return "challenge_" + userId + "_" + weekKey + "_" + id; }

    // =============================================================== MOOD

    /** Saves today's mood (1-5). The first check-in of the day gives +3 EXP. */
    public void saveMood(int mood, Result<ActionResult> cb) {
        run(() -> {
            ActionResult r = new ActionResult();
            String today = DateUtils.todayKey();
            MoodRecord existing = db.moodDao().forDay(userId, today);
            MoodRecord m = new MoodRecord();
            if (existing != null) m.id = existing.id;
            m.userId = userId;
            m.dateKey = today;
            m.mood = Math.max(1, Math.min(5, mood));
            m.timestamp = System.currentTimeMillis();
            db.moodDao().save(m);
            if (existing == null) {
                Pet pet = ensurePet();
                addExp(pet, 3, r);
                checkAchievements(pet, r);
            }
            return r;
        }, cb);
    }

    /** How many of the last 3 days (including today) had a low mood (1-2). */
    public void recentLowMoodDays(Result<Integer> cb) {
        run(() -> {
            int low = 0;
            for (MoodRecord m : db.moodDao().since(userId, DateUtils.daysAgoKey(2))) if (m.mood <= 2) low++;
            return low;
        }, cb);
    }

    // =============================================================== BMI

    public void setHeight(float cm, Result<User> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            if (u == null) return null;
            u.heightCm = cm;
            db.userDao().update(u);
            return u;
        }, cb);
    }

    /** {heightCm, latestWeightKg or NaN} */
    public void getBmiInputs(Result<float[]> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            WeightRecord w = db.trackingDao().latestWeight(userId);
            return new float[]{u == null ? 0 : u.heightCm, w == null ? Float.NaN : w.weightKg};
        }, cb);
    }

    // =============================================================== REPORT

    /** Builds a report for the last {@code days} days, ending today. */
    public void buildReport(int days, Result<WeeklyReport> cb) {
        run(() -> {
            User u = db.userDao().findById(userId);
            if (u == null) return null;
            String fromKey = DateUtils.daysAgoKey(days - 1);
            WeeklyReport r = new WeeklyReport();
            r.userName = u.fullName;
            r.userEmail = u.email;
            r.calorieGoal = u.calorieGoal;
            r.waterGoal = u.hydrationGoal;
            r.stepGoal = u.stepGoal;
            r.heightCm = u.heightCm;
            r.streak = currentStreak();
            Pet pet = ensurePet();
            r.petLevel = pet.level;
            db.goalDao().insertAchievements(Achievements.defaultsFor(userId));
            for (Achievement a : db.goalDao().achievements(userId)) {
                r.achievementsTotal++;
                if (a.unlocked) r.achievementsUnlocked++;
            }
            Map<String, Float> water = toMap(db.trackingDao().dailyWater(userId, fromKey));
            Map<String, Float> steps = toMap(db.trackingDao().dailySteps(userId, fromKey));
            Map<String, Float> weight = toMap(db.trackingDao().dailyWeight(userId, fromKey));
            Map<String, Float> mood = toMap(db.moodDao().dailyMood(userId, fromKey));

            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_YEAR, -(days - 1));
            r.rangeLabel = DateUtils.format("MMM d", c) + " – " + DateUtils.format("MMM d, yyyy", Calendar.getInstance());
            for (int i = 0; i < days; i++) {
                String key = DateUtils.keyOf(c);
                WeeklyReport.DayRow d = new WeeklyReport.DayRow();
                d.dateKey = key;
                d.label = DateUtils.format("EEE d", c);
                List<MealRecord> meals = db.mealDao().getMealsForDay(userId, key);
                d.logged = !meals.isEmpty();
                for (MealRecord m : meals) {
                    d.calories += m.calories;
                    d.protein += m.protein;
                    d.carbs += m.carbs;
                    d.fat += m.fat;
                }
                d.water = Math.round(get(water, key, 0));
                d.steps = Math.round(get(steps, key, 0));
                d.weight = get(weight, key, Float.NaN);
                d.mood = Math.round(get(mood, key, 0));
                r.days.add(d);
                c.add(Calendar.DAY_OF_YEAR, 1);
            }
            return r.compute();
        }, cb);
    }

    private static Map<String, Float> toMap(List<DayTotal> rows) {
        Map<String, Float> m = new HashMap<>();
        for (DayTotal t : rows) m.put(t.dateKey, t.total);
        return m;
    }

    private static float get(Map<String, Float> m, String key, float fallback) {
        Float v = m.get(key);
        return v == null ? fallback : v;
    }

    // =============================================================== STREAKS

    /**
     * Consecutive days with at least one logged food. If today has nothing logged yet,
     * the streak still counts up to yesterday (it is only lost after a full missed day).
     */
    private int currentStreak() {
        List<String> days = db.mealDao().loggedDays(userId);
        if (days.isEmpty()) return 0;
        Calendar cursor = Calendar.getInstance();
        String today = DateUtils.keyOf(cursor);
        int i = 0;
        if (!days.get(0).equals(today)) {
            cursor.add(Calendar.DAY_OF_YEAR, -1);                      // allow "not yet today"
            if (!days.get(0).equals(DateUtils.keyOf(cursor))) return 0;
        }
        int streak = 0;
        while (i < days.size() && days.get(i).equals(DateUtils.keyOf(cursor))) {
            streak++;
            i++;
            cursor.add(Calendar.DAY_OF_YEAR, -1);
        }
        return streak;
    }

    public void getStreak(Result<Integer> cb) { run(this::currentStreak, cb); }

    /** Consecutive days the daily quiz was answered correctly. */
    public void getQuizStreak(Result<Integer> cb) {
        run(() -> streakOf(db.goalDao().completedDays(userId, DailyGoal.DAILY_QUIZ)), cb);
    }

    /** Generic streak counter for a newest-first list of yyyy-MM-dd keys. */
    private static int streakOf(List<String> days) {
        if (days.isEmpty()) return 0;
        Calendar cursor = Calendar.getInstance();
        if (!days.get(0).equals(DateUtils.keyOf(cursor))) {
            cursor.add(Calendar.DAY_OF_YEAR, -1);
            if (!days.get(0).equals(DateUtils.keyOf(cursor))) return 0;
        }
        int streak = 0, i = 0;
        while (i < days.size() && days.get(i).equals(DateUtils.keyOf(cursor))) {
            streak++; i++;
            cursor.add(Calendar.DAY_OF_YEAR, -1);
        }
        return streak;
    }

    // =============================================================== BERRY SHOP

    /** Returns "" on success, otherwise an error message. */
    public void buyItem(int itemId, Result<String> cb) {
        run(() -> {
            ShopItems.Item item = ShopItems.find(itemId);
            if (item == null) return "Item not found.";
            Pet pet = ensurePet();
            if (pet.owns(itemId)) return "";
            if (pet.coins < item.price) return "Not enough coins yet! Earn more by logging healthy meals 🍎";
            pet.coins -= item.price;
            pet.addOwned(itemId);
            equipOn(pet, item);
            db.petDao().update(pet);
            checkAchievements(pet, new ActionResult());
            return "";
        }, cb);
    }

    /** Equip an owned item, or pass itemId 0 to take off whatever is in that slot. */
    public void equip(String slot, int itemId, Result<Pet> cb) {
        run(() -> {
            Pet pet = ensurePet();
            ShopItems.Item item = ShopItems.find(itemId);
            if (itemId == 0) {
                if (ShopItems.HAT.equals(slot)) pet.hat = 0;
                else if (ShopItems.FACE.equals(slot)) pet.face = 0;
                else pet.room = 0;
            } else if (item != null && pet.owns(itemId)) {
                equipOn(pet, item);
            }
            db.petDao().update(pet);
            return pet;
        }, cb);
    }

    private static void equipOn(Pet pet, ShopItems.Item item) {
        if (ShopItems.HAT.equals(item.slot)) pet.hat = item.id;
        else if (ShopItems.FACE.equals(item.slot)) pet.face = item.id;
        else pet.room = item.id;
    }
}
