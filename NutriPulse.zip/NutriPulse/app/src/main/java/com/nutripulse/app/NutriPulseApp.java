package com.nutripulse.app;

import android.app.Application;
import android.content.Context;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;

/**
 * App-wide setup: applies the saved theme (light/dark/system).
 * The chosen language is stored and restored by AppCompat itself (see the manifest service).
 */
public class NutriPulseApp extends Application {
    private static final String PREFS = "nutripulse_app";
    public static final int THEME_LIGHT = 0, THEME_DARK = 1, THEME_SYSTEM = 2;

    @Override
    public void onCreate() {
        super.onCreate();
        applyTheme(getTheme(this));
        com.nutripulse.app.utils.PetSounds.init(this);   // preload Berry's sound effects
        // Protects Firebase AI Logic / Firestore from abuse (only when Firebase is set up)
        if (com.nutripulse.app.cloud.Cloud.isReady(this)) {
            try {
                com.nutripulse.app.cloud.AppCheckSetup.install();
            } catch (Throwable t) {
                android.util.Log.w("NutriPulseApp", "App Check not installed", t);
            }
        }
    }

    public static int getTheme(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getInt("theme", THEME_LIGHT);
    }

    public static void setTheme(Context c, int theme) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("theme", theme).apply();
        applyTheme(theme);
    }

    private static void applyTheme(int theme) {
        AppCompatDelegate.setDefaultNightMode(theme == THEME_DARK ? AppCompatDelegate.MODE_NIGHT_YES
                : theme == THEME_SYSTEM ? AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                : AppCompatDelegate.MODE_NIGHT_NO);
    }

    /** "en" or "tl" (Filipino). */
    public static String getLanguage() {
        LocaleListCompat l = AppCompatDelegate.getApplicationLocales();
        return !l.isEmpty() && l.get(0) != null && "tl".equals(l.get(0).getLanguage()) ? "tl" : "en";
    }

    public static void setLanguage(String tag) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag));
    }
}
