package com.nutripulse.app.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.nutripulse.app.R;

/** Wires up the shared bottom navigation bar (layout_bottom_nav.xml). */
public final class BottomNav {
    public static final int HOME = 0, DIARY = 1, PROGRESS = 2, PROFILE = 3, NONE = -1;

    private BottomNav() {}

    public static void setup(Activity a, int selected) {
        int[] items = {R.id.nav_home, R.id.nav_diary, R.id.nav_progress, R.id.nav_profile};
        int[] icons = {R.id.nav_home_icon, R.id.nav_diary_icon, R.id.nav_progress_icon, R.id.nav_profile_icon};
        int[] labels = {R.id.nav_home_label, R.id.nav_diary_label, R.id.nav_progress_label, R.id.nav_profile_label};
        Class<?>[] targets = {HomeActivity.class, MealPlannerActivity.class,
                ProgressActivity.class, SettingsActivity.class};

        int on = ContextCompat.getColor(a, R.color.pink_primary);
        int off = ContextCompat.getColor(a, R.color.text_muted);
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            boolean isSel = i == selected;
            ((ImageView) a.findViewById(icons[i])).setImageTintList(ColorStateList.valueOf(isSel ? on : off));
            ((TextView) a.findViewById(labels[i])).setTextColor(isSel ? on : off);
            a.findViewById(items[i]).setOnClickListener(v -> {
                if (index == selected) return;
                go(a, targets[index], selected);
            });
        }
        a.findViewById(R.id.nav_add).setOnClickListener(v ->
                a.startActivity(new Intent(a, MealLoggerActivity.class)));
    }

    private static void go(Activity a, Class<?> target, int selected) {
        Intent i = new Intent(a, target);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        a.startActivity(i);
        a.overridePendingTransition(0, 0);
        // Home stays at the root; every other tab replaces itself.
        if (selected != HOME) a.finish();
    }
}
