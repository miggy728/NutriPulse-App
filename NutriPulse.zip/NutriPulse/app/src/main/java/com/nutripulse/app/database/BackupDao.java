package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.WaterRecord;
import com.nutripulse.app.models.StepRecord;
import com.nutripulse.app.models.WeightRecord;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.FavoriteFood;
import com.nutripulse.app.models.MoodRecord;
import com.nutripulse.app.models.Pet;

import java.util.List;

/** Reads and writes whole tables for one user (used by cloud backup / restore). */
@Dao
public interface BackupDao {
    @Query("SELECT * FROM meal_records WHERE userId = :userId")
    List<MealRecord> allMealRecord(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putMealRecord(List<MealRecord> rows);

    @Query("SELECT * FROM meal_plans WHERE userId = :userId")
    List<MealPlan> allMealPlan(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putMealPlan(List<MealPlan> rows);

    @Query("SELECT * FROM meal_notes WHERE userId = :userId")
    List<MealNote> allMealNote(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putMealNote(List<MealNote> rows);

    @Query("SELECT * FROM water_records WHERE userId = :userId")
    List<WaterRecord> allWaterRecord(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putWaterRecord(List<WaterRecord> rows);

    @Query("SELECT * FROM step_records WHERE userId = :userId")
    List<StepRecord> allStepRecord(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putStepRecord(List<StepRecord> rows);

    @Query("SELECT * FROM weight_records WHERE userId = :userId")
    List<WeightRecord> allWeightRecord(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putWeightRecord(List<WeightRecord> rows);

    @Query("SELECT * FROM daily_goals WHERE userId = :userId")
    List<DailyGoal> allDailyGoal(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putDailyGoal(List<DailyGoal> rows);

    @Query("SELECT * FROM achievements WHERE userId = :userId")
    List<Achievement> allAchievement(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putAchievement(List<Achievement> rows);

    @Query("SELECT * FROM dietary_preferences WHERE userId = :userId")
    List<DietaryPreference> allDietaryPreference(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putDietaryPreference(List<DietaryPreference> rows);

    @Query("SELECT * FROM custom_foods WHERE userId = :userId")
    List<CustomFood> allCustomFood(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putCustomFood(List<CustomFood> rows);

    @Query("SELECT * FROM favorite_foods WHERE userId = :userId")
    List<FavoriteFood> allFavoriteFood(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putFavoriteFood(List<FavoriteFood> rows);

    @Query("SELECT * FROM mood_records WHERE userId = :userId")
    List<MoodRecord> allMoodRecord(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putMoodRecord(List<MoodRecord> rows);

    @Query("SELECT * FROM pets WHERE userId = :userId")
    List<Pet> allPet(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void putPet(List<Pet> rows);
}
