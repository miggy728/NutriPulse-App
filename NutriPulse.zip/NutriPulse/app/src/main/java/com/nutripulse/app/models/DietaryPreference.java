package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "dietary_preferences",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE))
public class DietaryPreference {
    @PrimaryKey
    public long userId;
    @NonNull public String dietType = "No preference";
    public String avoidFoods = "";
}
