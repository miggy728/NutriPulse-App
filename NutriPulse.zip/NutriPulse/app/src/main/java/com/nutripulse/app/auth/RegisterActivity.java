package com.nutripulse.app.auth;

import com.nutripulse.app.ui.NpDialogBuilder;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.models.User;
import com.nutripulse.app.ui.HomeActivity;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.utils.ValidationUtils;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout nameL, emailL, usernameL, passwordL, confirmL;
    private CheckBox terms;
    private MaterialButton createButton;
    private ProgressBar progress, strengthBar;
    private TextView strengthLabel, errorBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nameL = findViewById(R.id.register_name_layout);
        emailL = findViewById(R.id.register_email_layout);
        usernameL = findViewById(R.id.register_username_layout);
        passwordL = findViewById(R.id.register_password_layout);
        confirmL = findViewById(R.id.register_confirm_layout);
        terms = findViewById(R.id.register_terms);
        createButton = findViewById(R.id.register_button);
        progress = findViewById(R.id.register_progress);
        strengthBar = findViewById(R.id.register_strength_bar);
        strengthLabel = findViewById(R.id.register_strength_label);
        errorBox = findViewById(R.id.register_error);

        EditText pw = findViewById(R.id.register_password);
        pw.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateStrength(s.toString()); }
        });
        updateStrength("");

        createButton.setOnClickListener(v -> attemptRegister());
        findViewById(R.id.register_back).setOnClickListener(v -> finish());
        findViewById(R.id.register_login_link).setOnClickListener(v -> finish());
        findViewById(R.id.register_view_terms).setOnClickListener(v ->
                new NpDialogBuilder(this)
                        .setTitle(R.string.terms_title)
                        .setMessage(R.string.terms_body)
                        .setPositiveButton("I Agree", (d, w) -> terms.setChecked(true))
                        .setNegativeButton(R.string.cancel, null)
                        .show());
    }

    private void updateStrength(String password) {
        int score = ValidationUtils.passwordStrength(password);
        strengthBar.setProgress(score);
        String[] names = {"Too weak", "Weak", "Fair", "Good", "Strong"};
        int[] colors = {R.color.red_error, R.color.red_error, R.color.orange, R.color.green_ok, R.color.green_ok};
        strengthLabel.setText(names[score]);
        strengthLabel.setTextColor(ContextCompat.getColor(this, colors[score]));
    }

    private void attemptRegister() {
        UiUtils.clearErrors(nameL, emailL, usernameL, passwordL, confirmL);
        errorBox.setVisibility(View.GONE);

        String name = UiUtils.text(nameL).trim();
        String email = UiUtils.text(emailL).trim();
        String username = UiUtils.text(usernameL).trim();
        String password = UiUtils.text(passwordL);
        String confirm = UiUtils.text(confirmL);

        boolean ok = true;
        if (name.isEmpty()) { nameL.setError("Full name is required"); ok = false; }
        else if (!ValidationUtils.isValidFullName(name)) { nameL.setError("Enter your full name"); ok = false; }

        if (email.isEmpty()) { emailL.setError("Email is required"); ok = false; }
        else if (!ValidationUtils.isValidEmail(email)) { emailL.setError("Enter a valid email address"); ok = false; }

        if (username.isEmpty()) { usernameL.setError("Username is required"); ok = false; }
        else if (!ValidationUtils.isValidUsername(username)) {
            usernameL.setError("3–20 characters: letters, numbers, dots, underscores"); ok = false;
        }

        String pwProblem = ValidationUtils.passwordProblem(password);
        if (pwProblem != null) { passwordL.setError(pwProblem); ok = false; }

        if (confirm.isEmpty()) { confirmL.setError("Please confirm your password"); ok = false; }
        else if (!confirm.equals(password)) { confirmL.setError("Passwords do not match"); ok = false; }

        if (!terms.isChecked()) {
            showError("Please agree to the Terms and Conditions to continue.");
            ok = false;
        }
        if (!ok) return;

        UiUtils.hideKeyboard(this);
        setLoading(true);
        AuthManager.get(this).register(name, email, username, password, new AuthManager.Callback<User>() {
            @Override
            public void onSuccess(User user) {
                setLoading(false);
                new NpDialogBuilder(RegisterActivity.this)
                        .setTitle("Welcome to the family, " + user.getFirstName() + "! 🎉")
                        .setMessage("Your account is ready. Meet Berry, your Level 1 wellness buddy!")
                        .setCancelable(false)
                        .setPositiveButton("Let's go!", (d, w) -> {
                            Intent i = new Intent(RegisterActivity.this, HomeActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish();
                        })
                        .show();
            }

            @Override
            public void onError(String message) {
                setLoading(false);
                if ("EMAIL_TAKEN".equals(message)) {
                    emailL.setError("This email is already registered");
                } else if ("USERNAME_TAKEN".equals(message)) {
                    usernameL.setError("This username is already taken");
                } else {
                    showError(message);
                }
            }
        });
    }

    private void showError(String msg) {
        errorBox.setText(msg);
        errorBox.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean loading) {
        createButton.setEnabled(!loading);
        createButton.setText(loading ? "" : getString(R.string.create_account));
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
    }
}
