package com.nutripulse.app.reminders;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.content.ContextCompat;

import java.util.Calendar;

/** Schedules Berry's daily reminders (meals, water, streak) with AlarmManager. */
public final class ReminderScheduler {
    public static final String CHANNEL_ID = "berry_reminders";
    static final String PREFS = "nutripulse_reminders";
    public static final String MEALS = "meals", WATER = "water", STREAK = "streak";

    /** type, group, hour, minute, request code */
    static final Object[][] SLOTS = {
            {"breakfast", MEALS, 7, 30, 101},
            {"lunch", MEALS, 12, 0, 102},
            {"dinner", MEALS, 18, 30, 103},
            {"water", WATER, 10, 0, 201},
            {"water", WATER, 14, 0, 202},
            {"water", WATER, 16, 30, 203},
            {"streak", STREAK, 20, 0, 301},
    };

    private ReminderScheduler() {}

    public static boolean isOn(Context c, String group) {
        return prefs(c).getBoolean(group, false);
    }

    public static void setOn(Context c, String group, boolean on) {
        prefs(c).edit().putBoolean(group, on).apply();
        reschedule(c);
    }

    public static boolean hasPermission(Context c) {
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(c,
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Safe to call any time: cancels everything, then sets alarms for enabled groups. */
    public static void reschedule(Context context) {
        Context c = context.getApplicationContext();
        createChannel(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (Object[] slot : SLOTS) {
            PendingIntent pi = pending(c, (String) slot[0], (int) slot[4]);
            am.cancel(pi);
            if (!isOn(c, (String) slot[1])) continue;
            Calendar next = Calendar.getInstance();
            next.set(Calendar.HOUR_OF_DAY, (int) slot[2]);
            next.set(Calendar.MINUTE, (int) slot[3]);
            next.set(Calendar.SECOND, 0);
            if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
            // Inexact repeating alarms are battery friendly and need no special permission.
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY, pi);
        }
    }

    private static PendingIntent pending(Context c, String type, int code) {
        Intent i = new Intent(c, ReminderReceiver.class)
                .setAction("com.nutripulse.app.REMINDER_" + code)
                .putExtra(ReminderReceiver.EXTRA_TYPE, type);
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Berry's reminders",
                NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("Meal, water and streak reminders from Berry");
        nm.createNotificationChannel(ch);
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
