package com.nutripulse.app.ui;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.nutripulse.app.R;

/** A modern list of choices (icon badge + title + helper text) used instead of plain text lists. */
public final class OptionSheet {

    public static final class Option {
        final int icon, tint, bg;
        final String title, sub;
        final Runnable action;
        boolean selected;

        Option(int icon, int tint, int bg, String title, @Nullable String sub, Runnable action) {
            this.icon = icon; this.tint = tint; this.bg = bg;
            this.title = title; this.sub = sub; this.action = action;
        }

        /** Shows a check mark instead of the arrow (for "current choice" lists). */
        public Option selected(boolean s) { selected = s; return this; }
    }

    private OptionSheet() {}

    public static Option opt(int icon, int tint, int bg, String title, @Nullable String sub, Runnable action) {
        return new Option(icon, tint, bg, title, sub, action);
    }

    public static AlertDialog show(Activity a, String title, @Nullable String subtitle, int headerIcon,
                                   int headerTint, int headerBg, Option... options) {
        View v = LayoutInflater.from(a).inflate(R.layout.dialog_options, null, false);
        ((TextView) v.findViewById(R.id.os_title)).setText(title);
        TextView sub = v.findViewById(R.id.os_subtitle);
        if (subtitle != null) { sub.setText(subtitle); sub.setVisibility(View.VISIBLE); }
        if (headerIcon != 0) {
            View bg = v.findViewById(R.id.os_icon_bg);
            bg.setVisibility(View.VISIBLE);
            bg.setBackgroundTintList(color(a, headerBg));
            ImageView icon = v.findViewById(R.id.os_icon);
            icon.setImageResource(headerIcon);
            icon.setImageTintList(color(a, headerTint));
            View titles = (View) v.findViewById(R.id.os_title).getParent();
            ((LinearLayout.LayoutParams) titles.getLayoutParams()).setMarginStart(
                    com.nutripulse.app.utils.UiUtils.dp(a, 14));
        }
        AlertDialog dialog = new NpDialogBuilder(a).setView(v).create();
        LinearLayout rows = v.findViewById(R.id.os_rows);
        for (Option o : options) {
            View row = LayoutInflater.from(a).inflate(R.layout.item_option_row, rows, false);
            row.findViewById(R.id.or_icon_bg).setBackgroundTintList(color(a, o.bg));
            ImageView icon = row.findViewById(R.id.or_icon);
            icon.setImageResource(o.icon);
            icon.setImageTintList(color(a, o.tint));
            ((TextView) row.findViewById(R.id.or_title)).setText(o.title);
            if (o.sub != null) {
                TextView s = row.findViewById(R.id.or_sub);
                s.setText(o.sub);
                s.setVisibility(View.VISIBLE);
            }
            ImageView end = row.findViewById(R.id.or_end);
            end.setImageResource(o.selected ? R.drawable.ic_check : R.drawable.ic_chevron);
            end.setImageTintList(color(a, o.selected ? R.color.pink_primary : R.color.text_muted));
            if (o.selected) row.setBackgroundResource(R.drawable.bg_option_selected);
            row.setOnClickListener(x -> { dialog.dismiss(); o.action.run(); });
            rows.addView(row);
        }
        dialog.show();
        return dialog;
    }

    private static ColorStateList color(Activity a, int res) {
        return ColorStateList.valueOf(ContextCompat.getColor(a, res));
    }
}
