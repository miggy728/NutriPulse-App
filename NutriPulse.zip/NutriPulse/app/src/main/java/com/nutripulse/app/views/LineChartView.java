package com.nutripulse.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lightweight pink line chart (no external chart library needed). */
public class LineChartView extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bubble = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bubbleText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    private List<String> labels = new ArrayList<>();
    private List<Float> values = new ArrayList<>();
    private String unit = "";
    private float goal = 0;

    public LineChartView(Context c, @Nullable AttributeSet attrs) {
        super(c, attrs);
        d = getResources().getDisplayMetrics().density;
        int pink = Color.parseColor("#FF4F8B");
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(3 * d);
        line.setColor(pink);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        dot.setColor(pink);
        dotInner.setColor(Color.WHITE);
        grid.setColor(androidx.core.content.ContextCompat.getColor(c, com.nutripulse.app.R.color.divider));
        grid.setStrokeWidth(1 * d);
        goalPaint.setColor(Color.parseColor("#A57CF0"));
        goalPaint.setStrokeWidth(1.5f * d);
        goalPaint.setStyle(Paint.Style.STROKE);
        goalPaint.setPathEffect(new DashPathEffect(new float[]{8 * d, 6 * d}, 0));
        text.setColor(androidx.core.content.ContextCompat.getColor(c, com.nutripulse.app.R.color.text_muted));
        text.setTextSize(11 * d);
        bubble.setColor(pink);
        bubbleText.setColor(Color.WHITE);
        bubbleText.setTextSize(13 * d);
        bubbleText.setFakeBoldText(true);
        bubbleText.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(List<String> labels, List<Float> values, String unit, float goal) {
        this.labels = labels;
        this.values = values;
        this.unit = unit;
        this.goal = goal;
        invalidate();
    }

    private String fmt(float v) {
        if ("kg".equals(unit) || "/5".equals(unit)) return String.format(Locale.US, "%.1f", v);
        return String.format(Locale.US, "%,d", Math.round(v));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = 44 * d, right = getWidth() - 16 * d, top = 34 * d, bottom = getHeight() - 26 * d;
        int n = values.size();

        float min = Float.MAX_VALUE, max = -Float.MAX_VALUE;
        int lastIdx = -1;
        for (int i = 0; i < n; i++) {
            float v = values.get(i);
            if (Float.isNaN(v)) continue;
            min = Math.min(min, v); max = Math.max(max, v); lastIdx = i;
        }
        if (lastIdx < 0) {
            text.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("No data yet. Start logging!", getWidth() / 2f, getHeight() / 2f, text);
            return;
        }
        if (goal > 0) { min = Math.min(min, goal); max = Math.max(max, goal); }
        if ("kg".equals(unit)) { min -= 2; max += 2; }
        else if ("/5".equals(unit)) { min = 0; max = 5; }
        else { min = 0; max = max * 1.15f + 1; }
        if (max - min < 1) max = min + 1;

        // grid + y labels
        text.setTextAlign(Paint.Align.RIGHT);
        for (int g = 0; g <= 2; g++) {
            float y = bottom - (bottom - top) * g / 2f;
            canvas.drawLine(left, y, right, y, grid);
            canvas.drawText(fmt(min + (max - min) * g / 2f), left - 6 * d, y + 4 * d, text);
        }
        // goal line
        if (goal > 0) {
            float gy = bottom - (goal - min) / (max - min) * (bottom - top);
            Path gp = new Path(); gp.moveTo(left, gy); gp.lineTo(right, gy);
            canvas.drawPath(gp, goalPaint);
        }
        // x labels (at most ~7)
        text.setTextAlign(Paint.Align.CENTER);
        int step = Math.max(1, (int) Math.ceil(n / 7f));
        for (int i = 0; i < n; i += step) {
            canvas.drawText(labels.get(i), x(i, n, left, right), getHeight() - 6 * d, text);
        }

        // line path through available points
        Path p = new Path(), area = new Path();
        boolean started = false;
        float firstX = 0, lastX = 0;
        for (int i = 0; i < n; i++) {
            float v = values.get(i);
            if (Float.isNaN(v)) continue;
            float px = x(i, n, left, right), py = bottom - (v - min) / (max - min) * (bottom - top);
            if (!started) { p.moveTo(px, py); area.moveTo(px, bottom); area.lineTo(px, py); firstX = px; started = true; }
            else { p.lineTo(px, py); area.lineTo(px, py); }
            lastX = px;
        }
        area.lineTo(lastX, bottom); area.lineTo(firstX, bottom); area.close();
        fill.setShader(new LinearGradient(0, top, 0, bottom,
                Color.parseColor("#55FF4F8B"), Color.parseColor("#00FF4F8B"), Shader.TileMode.CLAMP));
        canvas.drawPath(area, fill);
        canvas.drawPath(p, line);

        boolean sparse = n <= 14;
        for (int i = 0; i < n; i++) {
            float v = values.get(i);
            if (Float.isNaN(v) || (!sparse && i != lastIdx)) continue;
            float px = x(i, n, left, right), py = bottom - (v - min) / (max - min) * (bottom - top);
            canvas.drawCircle(px, py, 5 * d, dot);
            canvas.drawCircle(px, py, 2.5f * d, dotInner);
        }
        // value bubble on the latest point
        float v = values.get(lastIdx);
        float px = x(lastIdx, n, left, right), py = bottom - (v - min) / (max - min) * (bottom - top);
        String label = fmt(v) + " " + unit;
        float w = bubbleText.measureText(label) + 20 * d;
        float bx = Math.min(Math.max(px - w / 2, left), right - w);
        RectF r = new RectF(bx, py - 34 * d, bx + w, py - 10 * d);
        canvas.drawRoundRect(r, 12 * d, 12 * d, bubble);
        canvas.drawText(label, r.centerX(), r.centerY() + 4.5f * d, bubbleText);
    }

    private float x(int i, int n, float left, float right) {
        return n <= 1 ? (left + right) / 2 : left + (right - left) * i / (n - 1);
    }
}
