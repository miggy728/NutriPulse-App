package com.nutripulse.app.data;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Where the user placed each accessory on Berry: offset (dp), size and rotation.
 * Saved per user and per item, so every hat or pair of glasses remembers its own spot.
 */
public final class LookPrefs {
    private static final String PREFS = "nutripulse_look";

    /** {offsetXdp, offsetYdp, scale, rotationDegrees} */
    public static final float[] DEFAULT = {0f, 0f, 1f, 0f};

    private LookPrefs() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String key(long userId, int itemId) { return "u" + userId + "_i" + itemId; }

    public static float[] get(Context c, long userId, int itemId) {
        String v = prefs(c).getString(key(userId, itemId), null);
        if (v == null) return DEFAULT.clone();
        try {
            String[] p = v.split(",");
            return new float[]{Float.parseFloat(p[0]), Float.parseFloat(p[1]),
                    Float.parseFloat(p[2]), Float.parseFloat(p[3])};
        } catch (Exception e) {
            return DEFAULT.clone();
        }
    }

    public static void save(Context c, long userId, int itemId, float xDp, float yDp, float scale, float rotation) {
        prefs(c).edit().putString(key(userId, itemId), xDp + "," + yDp + "," + scale + "," + rotation).apply();
    }

    public static void reset(Context c, long userId, int itemId) {
        prefs(c).edit().remove(key(userId, itemId)).apply();
    }
}
