package com.nutripulse.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.nutripulse.app.R;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * "Berry's Snack Catch" mini-game.
 * Drag Berry left and right to catch healthy food (+1) and dodge junk food (-1 heart).
 * 45 seconds or 3 hearts, whichever runs out first. Food falls faster as time goes on.
 */
public class SnackGameView extends View {

    public interface Listener {
        void onHud(int score, int lives, int secondsLeft);
        void onGameOver(int score);
    }

    private static final String[] GOOD = {"🍎", "🥦", "🥕", "🍌", "🥚", "💧", "🐟", "🥗", "🍇", "🍓", "🥭", "🍠"};
    private static final String[] BAD = {"🍩", "🍟", "🥤", "🍬", "🍫", "🍔", "🧁"};
    private static final int GAME_SECONDS = 45, START_LIVES = 3;

    private static class Food {
        float x, y, speed, size, spin;
        String emoji;
        boolean good;
    }

    private static class Pop {
        float x, y, life;
        String text;
        int color;
    }

    private final List<Food> foods = new ArrayList<>();
    private final List<Pop> pops = new ArrayList<>();
    private final Random rnd = new Random();
    private final Paint emojiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint popPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Drawable berry, berryHappy, berrySad;
    private final float d;

    private Listener listener;
    private boolean running;
    private long lastNanos;
    private float elapsed, spawnTimer, berryX = -1, faceTimer;
    private int score, lives, faceState;      // faceState: 0 normal, 1 happy, 2 sad

    public SnackGameView(Context c, @Nullable AttributeSet attrs) {
        super(c, attrs);
        d = getResources().getDisplayMetrics().density;
        berry = ContextCompat.getDrawable(c, R.drawable.mascot_berry);
        berryHappy = ContextCompat.getDrawable(c, R.drawable.mascot_berry_happy);
        berrySad = ContextCompat.getDrawable(c, R.drawable.mascot_berry_blink);
        emojiPaint.setTextAlign(Paint.Align.CENTER);
        emojiPaint.setColor(Color.BLACK);
        popPaint.setTextAlign(Paint.Align.CENTER);
        popPaint.setTypeface(Typeface.DEFAULT_BOLD);
        popPaint.setTextSize(20 * d);
    }

    public void setListener(Listener l) { listener = l; }

    public boolean isRunning() { return running; }

    public void start() {
        foods.clear();
        pops.clear();
        score = 0;
        lives = START_LIVES;
        elapsed = 0;
        spawnTimer = 0;
        faceState = 0;
        berryX = getWidth() / 2f;
        running = true;
        lastNanos = System.nanoTime();
        hud();
        postInvalidateOnAnimation();
    }

    public void stop() { running = false; }

    private float berrySize() { return Math.min(96 * d, getWidth() * 0.26f); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!running) return true;
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
            float half = berrySize() / 2;
            berryX = Math.max(half, Math.min(getWidth() - half, e.getX()));
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (berryX < 0) berryX = getWidth() / 2f;
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        if (running) update(dt);

        // Falling food
        for (Food f : foods) {
            emojiPaint.setTextSize(f.size);
            canvas.save();
            canvas.rotate(f.spin, f.x, f.y);
            canvas.drawText(f.emoji, f.x, f.y + f.size * 0.35f, emojiPaint);
            canvas.restore();
        }

        // Berry
        float size = berrySize();
        float top = getHeight() - size - 8 * d;
        Drawable face = faceState == 1 ? berryHappy : faceState == 2 ? berrySad : berry;
        float wobble = faceState == 2 ? (float) Math.sin(elapsed * 60) * 4 * d : 0;
        face.setBounds((int) (berryX - size / 2 + wobble), (int) top, (int) (berryX + size / 2 + wobble), (int) (top + size));
        face.draw(canvas);

        // "+1" / "-1" pop-ups
        Iterator<Pop> it = pops.iterator();
        while (it.hasNext()) {
            Pop p = it.next();
            popPaint.setColor(p.color);
            popPaint.setAlpha((int) (255 * Math.max(0, p.life)));
            canvas.drawText(p.text, p.x, p.y, popPaint);
            if (running) { p.y -= 60 * d * dt; p.life -= dt * 1.5f; }
            if (p.life <= 0) it.remove();
        }

        if (running) postInvalidateOnAnimation();
    }

    private void update(float dt) {
        elapsed += dt;
        float difficulty = 1f + elapsed / 20f;                 // speeds up over time
        spawnTimer -= dt;
        if (spawnTimer <= 0) {
            spawn(difficulty);
            spawnTimer = Math.max(0.35f, 0.9f - elapsed * 0.012f);
        }
        if (faceTimer > 0) { faceTimer -= dt; if (faceTimer <= 0) faceState = 0; }

        float size = berrySize();
        float berryCy = getHeight() - size * 0.45f - 8 * d;
        Iterator<Food> it = foods.iterator();
        while (it.hasNext()) {
            Food f = it.next();
            f.y += f.speed * dt;
            f.spin += 90 * dt;
            float dx = f.x - berryX, dy = f.y - berryCy;
            if (Math.hypot(dx, dy) < size * 0.45f + f.size * 0.3f) {
                it.remove();
                if (f.good) {
                    score++;
                    face(1);
                    pop("+1", f.x, f.y, Color.parseColor("#3DBE7C"));
                } else {
                    lives--;
                    face(2);
                    pop("💔", f.x, f.y, Color.parseColor("#E5484D"));
                }
                hud();
            } else if (f.y > getHeight() + f.size) {
                it.remove();
            }
        }
        if (lives <= 0 || elapsed >= GAME_SECONDS) {
            running = false;
            if (listener != null) listener.onGameOver(score);
        } else if ((int) elapsed != (int) (elapsed - dt)) {
            hud();                                             // once per second for the timer
        }
    }

    private void spawn(float difficulty) {
        Food f = new Food();
        f.good = rnd.nextFloat() < 0.7f;
        f.emoji = f.good ? GOOD[rnd.nextInt(GOOD.length)] : BAD[rnd.nextInt(BAD.length)];
        f.size = (30 + rnd.nextInt(10)) * d;
        f.x = f.size + rnd.nextFloat() * (getWidth() - 2 * f.size);
        f.y = -f.size;
        f.speed = (140 + rnd.nextInt(90)) * d * difficulty / 1.6f;
        foods.add(f);
    }

    private void face(int state) { faceState = state; faceTimer = 0.5f; }

    private void pop(String t, float x, float y, int color) {
        Pop p = new Pop();
        p.text = t; p.x = x; p.y = y; p.life = 1f; p.color = color;
        pops.add(p);
    }

    private void hud() {
        if (listener != null) listener.onHud(score, lives, Math.max(0, GAME_SECONDS - (int) elapsed));
    }
}
