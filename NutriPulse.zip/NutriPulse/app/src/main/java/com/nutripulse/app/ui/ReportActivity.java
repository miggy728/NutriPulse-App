package com.nutripulse.app.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.R;
import com.nutripulse.app.data.WeeklyReport;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.PdfExporter;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.views.BarChartView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Weekly / monthly wellness report with charts, highlights, and PDF export. */
public class ReportActivity extends BaseAuthActivity {

    private int days = 7;
    private WeeklyReport report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_report);
        findViewById(R.id.report_back).setOnClickListener(v -> finish());
        findViewById(R.id.report_week).setOnClickListener(v -> load(7));
        findViewById(R.id.report_month).setOnClickListener(v -> load(30));
        findViewById(R.id.report_pdf).setOnClickListener(v -> exportPdf(MODE_SAVE));
        findViewById(R.id.report_share).setOnClickListener(v -> exportPdf(MODE_SHARE));
        findViewById(R.id.report_email).setOnClickListener(v -> exportPdf(MODE_EMAIL));
        load(7);
    }

    private void load(int d) {
        days = d;
        findViewById(R.id.report_week).setSelected(d == 7);
        findViewById(R.id.report_month).setSelected(d == 30);
        repo.buildReport(d, r -> {
            if (r == null) { redirectToLogin(); return; }
            report = r;
            show(r);
        });
    }

    private void show(WeeklyReport r) {
        ((TextView) findViewById(R.id.report_name)).setText(r.userName);
        ((TextView) findViewById(R.id.report_range)).setText(r.rangeLabel);
        ((TextView) findViewById(R.id.report_badges)).setText("Berry Lv." + r.petLevel + "  ·  🔥 " + r.streak
                + "  ·  🏆 " + r.achievementsUnlocked + "/" + r.achievementsTotal);

        LinearLayout tiles = findViewById(R.id.report_tiles);
        tiles.removeAllViews();
        String[][] data = {
                {"🍽️", r.avgCalories + " kcal", "avg per logged day"},
                {"📒", r.daysLogged + "/" + r.days.size(), "days logged"},
                {"💧", r.waterGoalDays + " days", "water goal reached"},
                {"👟", String.format(Locale.US, "%,d", r.totalSteps), "total steps"},
                {WeeklyReport.moodEmoji(r.avgMood), Float.isNaN(r.avgMood) ? "–" : String.format(Locale.US, "%.1f/5", r.avgMood), "average mood"},
                {"⚖️", Float.isNaN(r.weightChange) ? "–" : String.format(Locale.US, "%+.1f kg", r.weightChange), "weight change"},
        };
        for (int row = 0; row < 2; row++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 3; col++) line.addView(tile(data[row * 3 + col]));
            tiles.addView(line);
        }

        List<String> labels = new ArrayList<>();
        List<Float> cal = new ArrayList<>(), water = new ArrayList<>();
        for (WeeklyReport.DayRow d : r.days) {
            String[] parts = d.label.split(" ");            // "Mon 17" -> "Mon" (7 days) or "17" (30 days)
            labels.add(days == 7 ? parts[0] : parts[parts.length - 1]);
            cal.add((float) d.calories);
            water.add((float) d.water);
        }
        ((BarChartView) findViewById(R.id.report_cal_chart)).setData(labels, cal, r.calorieGoal,
                ContextCompat.getColor(this, R.color.pink_primary));
        ((BarChartView) findViewById(R.id.report_water_chart)).setData(labels, water, r.waterGoal,
                ContextCompat.getColor(this, R.color.blue_water));

        ((TextView) findViewById(R.id.report_highlights)).setText(String.join("\n", r.highlights));
        StringBuilder tips = new StringBuilder();
        for (String t : r.tips) tips.append("• ").append(t).append("\n");
        ((TextView) findViewById(R.id.report_tips)).setText(tips.toString().trim());
        TextView mood = findViewById(R.id.report_mood);
        mood.setVisibility(r.moodInsight == null ? View.GONE : View.VISIBLE);
        mood.setText(r.moodInsight == null ? "" : "😊 Mood pattern\n" + r.moodInsight);

        LinearLayout table = findViewById(R.id.report_table);
        table.removeAllViews();
        table.addView(tableRow(new String[]{"Day", "kcal", "💧", "👟", "Mood"}, true));
        for (int i = r.days.size() - 1; i >= 0; i--) {           // newest first on screen
            WeeklyReport.DayRow d = r.days.get(i);
            table.addView(tableRow(new String[]{d.label,
                    d.logged ? String.valueOf(d.calories) : "–",
                    d.water > 0 ? String.valueOf(d.water) : "–",
                    d.steps > 0 ? String.format(Locale.US, "%,d", d.steps) : "–",
                    d.mood > 0 ? com.nutripulse.app.models.MoodRecord.EMOJI[d.mood] : "–"}, false));
        }
    }

    private View tile(String[] t) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundResource(R.drawable.bg_tile);
        int pad = UiUtils.dp(this, 10);
        box.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        int m = UiUtils.dp(this, 3);
        lp.setMargins(m, m, m, m);
        box.setLayoutParams(lp);
        TextView e = new TextView(this);
        e.setText(t[0]);
        e.setTextSize(20);
        e.setTextColor(0xFF000000);
        TextView v = new TextView(this);
        v.setText(t[1]);
        v.setTextSize(15);
        v.setTextColor(ContextCompat.getColor(this, R.color.pink_dark));
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView l = new TextView(this);
        l.setText(t[2]);
        l.setTextSize(10);
        l.setGravity(Gravity.CENTER);
        l.setTextColor(ContextCompat.getColor(this, R.color.text_muted));
        box.addView(e);
        box.addView(v);
        box.addView(l);
        return box;
    }

    private View tableRow(String[] cells, boolean header) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int pv = UiUtils.dp(this, 6);
        row.setPadding(UiUtils.dp(this, 4), pv, UiUtils.dp(this, 4), pv);
        if (header) row.setBackgroundResource(R.drawable.bg_card_pink);
        float[] weights = {1.6f, 1f, 0.7f, 1.2f, 0.8f};
        for (int i = 0; i < cells.length; i++) {
            TextView t = new TextView(this);
            t.setText(cells[i]);
            t.setTextSize(13);
            t.setTextColor(ContextCompat.getColor(this, header ? R.color.pink_dark : R.color.text_dark));
            if (header) t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setGravity(i == 0 ? Gravity.START : Gravity.CENTER);
            row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weights[i]));
        }
        return row;
    }

    // ------------------------------------------------------------ PDF

    private static final int MODE_SAVE = 0, MODE_SHARE = 1, MODE_EMAIL = 2;

    private void exportPdf(int mode) {
        final boolean share = mode != MODE_SAVE;
        if (report == null) return;
        final WeeklyReport r = report;
        final String name = "NutriPulse-Report-" + DateUtils.todayKey() + (days == 30 ? "-30days" : "-7days") + ".pdf";
        UiUtils.toast(this, "Creating your PDF…");
        AppExecutors.io(() -> {
            File pdf;
            Uri saved = null;
            String error = null;
            try {
                pdf = PdfExporter.create(this, r, name);
                if (!share) saved = PdfExporter.saveToDownloads(this, pdf);
            } catch (Exception e) {
                pdf = null;
                error = e.getMessage();
            }
            final File file = pdf;
            final Uri downloads = saved;
            final String err = error;
            AppExecutors.main(() -> {
                if (isFinishing()) return;
                if (file == null) {
                    UiUtils.toast(this, "Couldn't create the PDF: " + err);
                    return;
                }
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
                if (mode == MODE_EMAIL) {
                    emailTo(uri, r);
                } else if (share || downloads == null) {
                    shareOrOpen(uri, true);
                    if (!share) UiUtils.toast(this, "Saving to Downloads needs Android 10+. Use Share to save it instead.");
                } else {
                    new NpDialogBuilder(this)
                            .setTitle("PDF saved 📄")
                            .setMessage(name + "\n\nYou can find it in your phone's Downloads folder.")
                            .setPositiveButton("Open", (d, w) -> shareOrOpen(uri, false))
                            .setNeutralButton("Share", (d, w) -> shareOrOpen(uri, true))
                            .setNegativeButton("Done", null)
                            .show();
                }
            });
        });
    }

    /** Opens the user's email app with their own address, a subject, a message and the PDF attached. */
    private void emailTo(Uri pdf, WeeklyReport r) {
        String first = r.userName.trim().split(" ")[0];
        Intent i = new Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_EMAIL, new String[]{r.userEmail})
                .putExtra(Intent.EXTRA_SUBJECT, "My NutriPulse report (" + r.rangeLabel + ")")
                .putExtra(Intent.EXTRA_TEXT, "Hi " + first + "!\n\nHere's your NutriPulse wellness report for "
                        + r.rangeLabel + ".\n\nKeep it up! 💗\nBerry 🍓")
                .putExtra(Intent.EXTRA_STREAM, pdf)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // Only show email apps in the chooser
        i.setSelector(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")));
        try {
            startActivity(Intent.createChooser(i, "Send report to " + r.userEmail));
        } catch (Exception e) {
            UiUtils.toast(this, "No email app found. Use Share instead.");
        }
    }

    private void shareOrOpen(Uri uri, boolean share) {
        Intent i;
        if (share) {
            i = new Intent(Intent.ACTION_SEND)
                    .setType("application/pdf")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_SUBJECT, "My NutriPulse wellness report");
        } else {
            i = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf");
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(share ? Intent.createChooser(i, "Share report") : i);
        } catch (Exception e) {
            UiUtils.toast(this, "No app found to open PDFs. Try Share instead.");
        }
    }
}
