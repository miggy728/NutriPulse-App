package com.nutripulse.app.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;

import com.nutripulse.app.R;

import java.util.Random;

/**
 * Berry's little sound effects (boops, munches, bloops, level-up jingle…).
 * The sounds are tiny original OGG files in res/raw. They stay quiet when the phone is on
 * silent or vibrate, and the user can switch them off in Settings › App Settings › Pet sounds.
 */
public final class PetSounds {
    private static final String PREFS = "nutripulse_sound";
    private static final String KEY_ON = "pet_sounds_on";

    private static SoundPool pool;
    private static int boop, squeak, giggle, eat, drink, play, exp, levelUp, coin, sleepy, correct, wrong;
    private static final Random rnd = new Random();
    private static long lastTap;

    private PetSounds() {}

    /** Loads the sounds once (call from Application.onCreate so they're ready in time). */
    public static synchronized void init(Context c) {
        if (pool != null) return;
        Context app = c.getApplicationContext();
        pool = new SoundPool.Builder()
                .setMaxStreams(4)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .build();
        boop = pool.load(app, R.raw.pet_boop, 1);
        squeak = pool.load(app, R.raw.pet_squeak, 1);
        giggle = pool.load(app, R.raw.pet_giggle, 1);
        eat = pool.load(app, R.raw.pet_eat, 1);
        drink = pool.load(app, R.raw.pet_drink, 1);
        play = pool.load(app, R.raw.pet_play, 1);
        exp = pool.load(app, R.raw.pet_exp, 1);
        levelUp = pool.load(app, R.raw.pet_levelup, 1);
        coin = pool.load(app, R.raw.coin, 1);
        sleepy = pool.load(app, R.raw.pet_sleepy, 1);
        correct = pool.load(app, R.raw.quiz_correct, 1);
        wrong = pool.load(app, R.raw.quiz_wrong, 1);
    }

    public static boolean isOn(Context c) {
        return prefs(c).getBoolean(KEY_ON, true);
    }

    public static void setOn(Context c, boolean on) {
        prefs(c).edit().putBoolean(KEY_ON, on).apply();
    }

    // ------------------------------------------------------------------ effects

    /** Random cute boop / squeak / giggle, slightly different pitch each time. */
    public static void tap(Context c) {
        long now = System.currentTimeMillis();
        if (now - lastTap < 120) return;               // no machine-gun sounds on rapid taps
        lastTap = now;
        int[] options = {boop, squeak, giggle};
        play(c, options[rnd.nextInt(options.length)], 0.8f, 0.9f + rnd.nextFloat() * 0.25f);
    }

    public static void eat(Context c) { play(c, eat, 0.8f, 1f); }
    public static void drink(Context c) { play(c, drink, 0.8f, 1f); }
    public static void play(Context c) { play(c, play, 0.7f, 1f); }
    public static void exp(Context c) { play(c, exp, 0.55f, 1f); }
    public static void levelUp(Context c) { play(c, levelUp, 0.9f, 1f); }
    public static void coin(Context c) { play(c, coin, 0.7f, 1f); }
    public static void sleepy(Context c) { play(c, sleepy, 0.6f, 1f); }
    public static void correct(Context c) { play(c, correct, 0.7f, 1f); }
    public static void wrong(Context c) { play(c, wrong, 0.6f, 1f); }

    private static void play(Context c, int id, float volume, float rate) {
        if (c == null || !isOn(c)) return;
        if (pool == null) init(c);
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am != null && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) return;   // silent / vibrate
        if (id != 0) pool.play(id, volume, volume, 1, 0, Math.max(0.5f, Math.min(2f, rate)));
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
