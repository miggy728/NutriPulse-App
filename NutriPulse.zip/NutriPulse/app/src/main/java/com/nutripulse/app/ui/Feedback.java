package com.nutripulse.app.ui;

import android.app.Activity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.nutripulse.app.data.WellnessRepository.ActionResult;

/** Shows EXP, level-up and achievement feedback after an action. */
public final class Feedback {
    private Feedback() {}

    public static void show(Activity a, ActionResult r, String baseMessage) {
        if (r == null) return;
        if (!r.ok) {
            Snackbar.make(a.findViewById(android.R.id.content), r.error, Snackbar.LENGTH_LONG).show();
            return;
        }
        StringBuilder msg = new StringBuilder(baseMessage == null ? "" : baseMessage);
        if (r.expGained > 0) msg.append(msg.length() > 0 ? "  " : "").append("+").append(r.expGained).append(" EXP")
                .append("  +").append(r.coinsGained).append(" 🪙");
        if (!r.completedGoals.isEmpty()) msg.append("\nGoal done: ").append(String.join(", ", r.completedGoals));
        if (msg.length() > 0) {
            Snackbar.make(a.findViewById(android.R.id.content), msg.toString(), Snackbar.LENGTH_LONG).show();
        }
        if (r.leveledUp || !r.unlocked.isEmpty()) {
            StringBuilder body = new StringBuilder();
            if (r.leveledUp) body.append("Berry grew to Level ").append(r.newLevel).append("! 🎉\n");
            for (String t : r.unlocked) body.append("🏆 Achievement unlocked: ").append(t).append("\n");
            new NpDialogBuilder(a)
                    .setTitle("Yay! 💗")
                    .setMessage(body.toString().trim())
                    .setPositiveButton("Awesome!", null)
                    .show();
        }
    }
}
