package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** How the user felt on a day (1 = very low ... 5 = great). One per day. */
@Entity(tableName = "mood_records",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey"}, unique = true)})
public class MoodRecord {
    public static final String[] EMOJI = {"", "😢", "😕", "😐", "🙂", "😄"};
    public static final String[] LABEL = {"", "Very low", "Low", "Okay", "Good", "Great"};

    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String dateKey = "";
    public int mood;
    public String note;
    public long timestamp;
}
