package com.nutripulse.app.ui;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.data.FoodItem;
import com.nutripulse.app.data.OpenFoodFacts;
import com.nutripulse.app.utils.AppExecutors;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.nutripulse.app.data.WellnessRepository;
import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.UiUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Log meals, snacks and drinks to the logged-in user's diary.
 * Includes custom foods, favorites, recent foods, and editing/deleting what was logged today.
 */
public class MealLoggerActivity extends BaseAuthActivity {

    private static final List<String> CATEGORIES = Arrays.asList("Meal", "Snack", "Drink");

    private String category = "Meal";
    private String mode = WellnessRepository.MODE_ALL;
    private FoodItem selected;
    private int qty = 1;
    private Set<String> favorites = new HashSet<>();

    private TextView tabMeal, tabSnack, tabDrink, emptyText, todayTotal, listTitle;
    private TextView dEmoji, dName, dKcal, dTag, dProtein, dCarbs, dFat, dQty;
    private ImageButton dFav;
    private View detailCard;
    private LinearLayout todayList;
    private EditText search;
    private FoodAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_meal_logger);

        tabMeal = findViewById(R.id.logger_tab_meal);
        tabSnack = findViewById(R.id.logger_tab_snack);
        tabDrink = findViewById(R.id.logger_tab_drink);
        emptyText = findViewById(R.id.logger_empty);
        todayTotal = findViewById(R.id.logger_today);
        todayList = findViewById(R.id.logger_today_list);
        listTitle = findViewById(R.id.logger_list_title);
        search = findViewById(R.id.logger_search);
        detailCard = findViewById(R.id.logger_detail);
        dEmoji = findViewById(R.id.detail_emoji);
        dName = findViewById(R.id.detail_name);
        dKcal = findViewById(R.id.detail_kcal);
        dTag = findViewById(R.id.detail_tag);
        dProtein = findViewById(R.id.detail_protein);
        dCarbs = findViewById(R.id.detail_carbs);
        dFat = findViewById(R.id.detail_fat);
        dQty = findViewById(R.id.detail_qty);
        dFav = findViewById(R.id.detail_fav);

        RecyclerView list = findViewById(R.id.logger_list);
        list.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        adapter = new FoodAdapter();
        list.setAdapter(adapter);

        findViewById(R.id.logger_back).setOnClickListener(v -> finish());
        tabMeal.setOnClickListener(v -> setCategory("Meal"));
        tabSnack.setOnClickListener(v -> setCategory("Snack"));
        tabDrink.setOnClickListener(v -> setCategory("Drink"));

        findViewById(R.id.logger_action).setOnClickListener(v -> scanMenu());
        findViewById(R.id.logger_scan).setOnClickListener(v -> scanMenu());
        findViewById(R.id.logger_mine).setOnClickListener(v -> toggleMode(WellnessRepository.MODE_MINE));
        findViewById(R.id.logger_favorites).setOnClickListener(v -> toggleMode(WellnessRepository.MODE_FAVORITES));
        findViewById(R.id.logger_recent).setOnClickListener(v -> toggleMode(WellnessRepository.MODE_RECENT));
        findViewById(R.id.logger_new_food).setOnClickListener(v -> createCustomFood());

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refreshList(); }
        });
        findViewById(R.id.detail_minus).setOnClickListener(v -> { if (qty > 1) { qty--; showDetail(); } });
        findViewById(R.id.detail_plus).setOnClickListener(v -> { if (qty < 10) { qty++; showDetail(); } });
        findViewById(R.id.detail_add).setOnClickListener(v -> addToDiary());
        dFav.setOnClickListener(v -> toggleFavorite());

        setCategory("Meal");
        loadToday();
    }

    // ------------------------------------------------------------ list modes

    private void setCategory(String c) {
        category = c;
        mode = WellnessRepository.MODE_ALL;
        tabMeal.setSelected("Meal".equals(c));
        tabSnack.setSelected("Snack".equals(c));
        tabDrink.setSelected("Drink".equals(c));
        refreshList();
    }

    private void toggleMode(String m) {
        mode = mode.equals(m) ? WellnessRepository.MODE_ALL : m;
        refreshList();
    }

    private void highlightModeTiles() {
        int[] ids = {R.id.logger_mine, R.id.logger_favorites, R.id.logger_recent};
        String[] modes = {WellnessRepository.MODE_MINE, WellnessRepository.MODE_FAVORITES, WellnessRepository.MODE_RECENT};
        for (int i = 0; i < ids.length; i++) {
            findViewById(ids[i]).setBackgroundResource(
                    mode.equals(modes[i]) ? R.drawable.bg_card_pink : R.drawable.bg_tile);
        }
        boolean tabsActive = WellnessRepository.MODE_ALL.equals(mode);
        tabMeal.setAlpha(tabsActive ? 1f : 0.5f);
        tabSnack.setAlpha(tabsActive ? 1f : 0.5f);
        tabDrink.setAlpha(tabsActive ? 1f : 0.5f);
        switch (mode) {
            case WellnessRepository.MODE_MINE: listTitle.setText("My Foods"); break;
            case WellnessRepository.MODE_FAVORITES: listTitle.setText("Favorites"); break;
            case WellnessRepository.MODE_RECENT: listTitle.setText("Recent"); break;
            default: listTitle.setText("Popular " + category + "s"); break;
        }
    }

    private void refreshList() {
        highlightModeTiles();
        repo.getFoodLibrary(category, search.getText().toString(), mode, lib -> {
            if (lib == null) return;
            favorites = lib.favorites;
            adapter.setItems(lib.items);
            boolean empty = lib.items.isEmpty();
            emptyText.setVisibility(empty ? View.VISIBLE : View.GONE);
            if (empty) {
                switch (mode) {
                    case WellnessRepository.MODE_FAVORITES: emptyText.setText("No favorites yet. Tap ☆ on a food to save it."); break;
                    case WellnessRepository.MODE_RECENT: emptyText.setText("Foods you log will show up here."); break;
                    case WellnessRepository.MODE_MINE: emptyText.setText("No custom foods yet. Tap \"+ New food\"."); break;
                    default: emptyText.setText("No foods match your search."); break;
                }
            }
            detailCard.setVisibility(empty ? View.GONE : View.VISIBLE);
            if (!empty) {
                FoodItem keep = null;
                if (selected != null) for (FoodItem f : lib.items) if (f.name.equals(selected.name)) keep = f;
                select(keep != null ? keep : lib.items.get(0), keep != null);
            } else {
                selected = null;
            }
        });
    }

    private void select(FoodItem f, boolean keepQty) {
        selected = f;
        if (!keepQty) qty = 1;
        showDetail();
        adapter.notifyDataSetChanged();
    }

    private void showDetail() {
        if (selected == null) return;
        dEmoji.setText(selected.emoji);
        dName.setText(selected.name + (selected.isCustom() ? "  ✏️" : ""));
        dKcal.setText(String.format(Locale.US, "%d kcal per %s  •  Total %d kcal",
                selected.calories, selected.serving, selected.calories * qty));
        dTag.setText(selected.healthy ? "Healthy choice" : "Enjoy in moderation");
        dTag.setTextColor(ContextCompat.getColor(this, selected.healthy ? R.color.green_ok : R.color.orange));
        dProtein.setText(String.format(Locale.US, "%.1fg", selected.protein * qty));
        dCarbs.setText(String.format(Locale.US, "%.1fg", selected.carbs * qty));
        dFat.setText(String.format(Locale.US, "%.1fg", selected.fat * qty));
        dQty.setText(String.valueOf(qty));
        boolean fav = favorites.contains(selected.name.toLowerCase(Locale.ROOT));
        dFav.setImageTintList(ColorStateList.valueOf(
                ContextCompat.getColor(this, fav ? R.color.orange : R.color.divider)));
    }

    // ------------------------------------------------------------ actions

    private void toggleFavorite() {
        if (selected == null) return;
        final String name = selected.name;
        repo.toggleFavorite(name, isFav -> {
            if (isFav == null) return;
            String key = name.toLowerCase(Locale.ROOT);
            if (isFav) favorites.add(key); else favorites.remove(key);
            UiUtils.bounce(dFav);
            UiUtils.toast(this, isFav ? "⭐ Added to favorites" : "Removed from favorites");
            if (WellnessRepository.MODE_FAVORITES.equals(mode)) refreshList(); else showDetail();
        });
    }

    private void addToDiary() {
        if (selected == null) return;
        final FoodItem food = selected;
        // In Favorites/Recent/My Foods, log under the food's own category
        String logCategory = WellnessRepository.MODE_ALL.equals(mode) ? category : food.category;
        repo.logMeal(food, logCategory, qty, r -> {
            Feedback.show(this, r, food.emoji + " " + food.name + " added");
            loadToday();
        });
    }

    private void createCustomFood() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_custom_food, null);
        TextInputLayout nameL = v.findViewById(R.id.cf_name_layout), kcalL = v.findViewById(R.id.cf_kcal_layout);
        TextView emoji = v.findViewById(R.id.cf_emoji), name = v.findViewById(R.id.cf_name),
                serving = v.findViewById(R.id.cf_serving), kcal = v.findViewById(R.id.cf_kcal),
                protein = v.findViewById(R.id.cf_protein), carbs = v.findViewById(R.id.cf_carbs),
                fat = v.findViewById(R.id.cf_fat);
        CheckBox healthy = v.findViewById(R.id.cf_healthy);
        Spinner cat = v.findViewById(R.id.cf_category);
        cat.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CATEGORIES));
        cat.setSelection(Math.max(0, CATEGORIES.indexOf(category)));
        name.setText(search.getText().toString().trim());

        AlertDialog d = new NpDialogBuilder(this)
                .setTitle("New food")
                .setView(v)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            nameL.setError(null);
            kcalL.setError(null);
            String n = name.getText().toString().trim();
            if (n.length() < 2) { nameL.setError("Enter a food name"); return; }
            int cal;
            try { cal = Integer.parseInt(kcal.getText().toString().trim()); } catch (NumberFormatException e) { cal = -1; }
            if (cal < 0 || cal > 5000) { kcalL.setError("Enter 0–5000 kcal"); return; }
            CustomFood food = new CustomFood();
            food.name = n;
            String e = emoji.getText().toString().trim();
            food.emoji = e.isEmpty() ? "🍽️" : e;
            food.category = (String) cat.getSelectedItem();
            String sv = serving.getText().toString().trim();
            food.serving = sv.isEmpty() ? "1 serving" : sv;
            food.calories = cal;
            food.protein = parse(protein);
            food.carbs = parse(carbs);
            food.fat = parse(fat);
            food.healthy = healthy.isChecked();
            repo.addCustomFood(food, err -> {
                if (err == null) { UiUtils.toast(this, "Something went wrong"); return; }
                if (!err.isEmpty()) { nameL.setError(err); return; }
                d.dismiss();
                UiUtils.toast(this, food.emoji + " " + food.name + " saved to My Foods");
                search.setText("");
                mode = WellnessRepository.MODE_MINE;
                selected = null;
                refreshList();
            });
        }));
        d.show();
    }

    // ------------------------------------------------------------ barcode scanning

    private void scanMenu() {
        OptionSheet.show(this, "Scan a barcode", "Get nutrition info from the package",
                R.drawable.ic_barcode, R.color.pink_primary, R.color.pink_light,
                OptionSheet.opt(R.drawable.ic_camera, R.color.purple, R.color.lavender,
                        "Scan with camera", "Point your camera at the barcode", this::scanWithCamera),
                OptionSheet.opt(R.drawable.ic_keyboard, R.color.blue_water, R.color.blue_light,
                        "Type the number", "Enter the digits under the barcode", this::typeBarcode));
    }

    /** Google Play services shows its own scanner screen, so the app needs no camera permission. */
    private void scanWithCamera() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
                .enableAutoZoom()
                .build();
        GmsBarcodeScanning.getClient(this, options).startScan()
                .addOnSuccessListener(barcode -> lookupBarcode(barcode.getRawValue()))
                .addOnFailureListener(e -> new NpDialogBuilder(this)
                        .setTitle("Scanner not available")
                        .setMessage("The camera scanner needs Google Play services (it may still be downloading). "
                                + "You can type the barcode number instead.")
                        .setPositiveButton("Type number", (d, w) -> typeBarcode())
                        .setNegativeButton("Cancel", null).show());
    }

    private void typeBarcode() {
        Dialogs.text(this, "Barcode number", "Digits under the barcode", "", 14, code -> lookupBarcode(code));
    }

    private void lookupBarcode(String code) {
        if (code == null || code.replaceAll("[^0-9]", "").length() < 6) {
            UiUtils.toast(this, "That doesn't look like a food barcode.");
            return;
        }
        UiUtils.toast(this, "Looking up " + code + "…");
        AppExecutors.io(() -> {
            OpenFoodFacts.Result r;
            String error = null;
            try {
                r = OpenFoodFacts.lookup(code);
            } catch (Exception e) {
                r = null;
                error = "No internet connection. Please try again.";
            }
            final OpenFoodFacts.Result res = r;
            final String err = error;
            AppExecutors.main(() -> {
                if (isFinishing()) return;
                if (err != null) { UiUtils.toast(this, err); return; }
                if (res == null || res.food == null) {
                    new NpDialogBuilder(this)
                            .setTitle("Not found 🔍")
                            .setMessage("This product isn't in the Open Food Facts database yet. "
                                    + "You can add it yourself with its nutrition label.")
                            .setPositiveButton("+ New food", (d, w) -> createCustomFood())
                            .setNegativeButton("Cancel", null).show();
                    return;
                }
                showScanned(res);
            });
        });
    }

    private void showScanned(OpenFoodFacts.Result r) {
        FoodItem f = r.food;
        String grade = r.nutriScore.isEmpty() ? "" : "\nNutri-Score: " + r.nutriScore.toUpperCase(Locale.ROOT)
                + (r.nutriScore.compareTo("c") <= 0 ? " 💚" : " 🧡");
        String msg = String.format(Locale.US, "Per %s:\n🔥 %d kcal\n🥩 Protein %.1fg\n🌾 Carbs %.1fg\n🧈 Fat %.1fg%s"
                        + "\n\nData from Open Food Facts (community database). Check the package label if unsure.",
                f.serving, f.calories, f.protein, f.carbs, f.fat, grade);
        new NpDialogBuilder(this)
                .setTitle("🏷️ " + f.name)
                .setMessage(msg)
                .setPositiveButton("Log it", (d, w) -> repo.logMeal(f, category, 1, res -> {
                    Feedback.show(this, res, "🏷️ " + f.name + " added");
                    loadToday();
                }))
                .setNeutralButton("Save to My Foods", (d, w) -> {
                    CustomFood c = new CustomFood();
                    c.name = f.name;
                    c.emoji = "🏷️";
                    c.category = category;
                    c.serving = f.serving.length() > 20 ? f.serving.substring(0, 20) : f.serving;
                    c.calories = f.calories;
                    c.protein = f.protein;
                    c.carbs = f.carbs;
                    c.fat = f.fat;
                    c.healthy = f.healthy;
                    repo.addCustomFood(c, err -> UiUtils.toast(this,
                            err == null || !err.isEmpty() ? (err == null ? "Couldn't save" : err) : "Saved to My Foods ✏️"));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static float parse(TextView t) {
        try { return Math.max(0f, Math.min(500f, Float.parseFloat(t.getText().toString().trim()))); }
        catch (NumberFormatException e) { return 0f; }
    }

    private void confirmDeleteCustom(FoodItem f) {
        new NpDialogBuilder(this)
                .setTitle("Delete " + f.name + "?")
                .setMessage("This removes it from My Foods. Meals you already logged stay in your diary.")
                .setPositiveButton("Delete", (d, w) -> repo.deleteCustomFood(f.customId, ok -> {
                    if (selected != null && selected.name.equals(f.name)) selected = null;
                    refreshList();
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ------------------------------------------------------------ logged today

    private void loadToday() {
        repo.getDayNutrition(DateUtils.todayKey(), n -> {
            todayList.removeAllViews();
            if (n == null || n.meals.isEmpty()) {
                todayTotal.setText("Nothing yet. Pick a food above!");
                return;
            }
            for (MealRecord m : n.meals) todayList.addView(loggedRow(m));
            todayTotal.setText(String.format(Locale.US, "Total: %,d / %,d kcal", n.calories, n.goal));
        });
    }

    private View loggedRow(MealRecord m) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_logged, todayList, false);
        ((TextView) row.findViewById(R.id.logged_emoji)).setText(m.emoji == null ? "🍽️" : m.emoji);
        ((TextView) row.findViewById(R.id.logged_name)).setText(m.foodName);
        String servings = m.servings == Math.round(m.servings)
                ? String.valueOf(Math.round(m.servings)) : String.format(Locale.US, "%.1f", m.servings);
        ((TextView) row.findViewById(R.id.logged_sub)).setText(String.format(Locale.US, "%s · ×%s · %d kcal · %s",
                m.category, servings, m.calories, DateUtils.format("h:mm a", timeOf(m.timestamp))));
        View.OnClickListener edit = v -> Dialogs.number(this, "Servings of " + m.foodName,
                "Number of servings", true, 0.5f, 20, value ->
                        repo.editMealServings(m.id, value, ok -> loadToday()));
        row.findViewById(R.id.logged_edit).setOnClickListener(edit);
        row.findViewById(R.id.logged_info).setOnClickListener(edit);
        row.findViewById(R.id.logged_delete).setOnClickListener(v -> new NpDialogBuilder(this)
                .setTitle("Remove " + m.foodName + "?")
                .setMessage("This removes it from today's diary.")
                .setPositiveButton("Remove", (d, w) -> row.animate().alpha(0f)
                        .translationX(UiUtils.dp(this, 40)).setDuration(180)
                        .withEndAction(() -> repo.deleteMeal(m.id, ok -> loadToday())).start())
                .setNegativeButton("Cancel", null)
                .show());
        return row;
    }

    private static java.util.Calendar timeOf(long millis) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(millis);
        return c;
    }

    // ------------------------------------------------------------ adapter

    private class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.VH> {
        private List<FoodItem> items = new ArrayList<>();

        void setItems(List<FoodItem> list) { items = list; notifyDataSetChanged(); }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            FoodItem f = items.get(position);
            boolean fav = favorites.contains(f.name.toLowerCase(Locale.ROOT));
            h.emoji.setText(f.emoji);
            h.name.setText((fav ? "⭐ " : "") + f.name);
            h.kcal.setText(f.calories + " kcal" + (f.isCustom() ? " · mine" : ""));
            boolean isSel = selected != null && selected.name.equals(f.name);
            h.itemView.setBackgroundResource(isSel ? R.drawable.bg_card_pink : R.drawable.bg_tile);
            h.itemView.setOnClickListener(v -> select(f, false));
            h.itemView.setOnLongClickListener(v -> {
                if (f.isCustom()) { confirmDeleteCustom(f); return true; }
                return false;
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            final TextView emoji, name, kcal;
            VH(View v) {
                super(v);
                emoji = v.findViewById(R.id.food_emoji);
                name = v.findViewById(R.id.food_name);
                kcal = v.findViewById(R.id.food_kcal);
            }
        }
    }
}
