package com.nutripulse.app.data;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.nutripulse.app.models.Pet;
import com.nutripulse.app.utils.SessionManager;

/** Shows Berry's equipped hat, glasses and room background on any pet screen. */
public final class PetLook {
    private PetLook() {}

    /**
     * @param roomView  full-size ImageView at the back of the pet area (shows the room)
     * @param crown     evolution crown; hidden while a hat is worn
     */
    public static void apply(Pet pet, @Nullable ImageView roomView,
                             TextView hatView, TextView faceView, View crown) {
        apply(pet == null ? 0 : pet.hat, pet == null ? 0 : pet.face, pet == null ? 0 : pet.room,
                pet != null && pet.getStage() >= 2, roomView, hatView, faceView, crown);
    }

    public static void apply(int hat, int face, int room, boolean evolved, @Nullable ImageView roomView,
                             TextView hatView, TextView faceView, View crown) {
        ShopItems.Item h = ShopItems.find(hat), f = ShopItems.find(face), r = ShopItems.find(room);
        showArt(hatView, h);
        showArt(faceView, f);
        long uid = new SessionManager(hatView.getContext()).getUserId();
        place(hatView, h == null ? null : LookPrefs.get(hatView.getContext(), uid, h.id));
        place(faceView, f == null ? null : LookPrefs.get(faceView.getContext(), uid, f.id));
        crown.setVisibility(evolved && h == null ? View.VISIBLE : View.GONE);
        if (roomView != null) {
            roomView.setImageResource(r != null ? r.roomDrawable : ShopItems.DEFAULT_ROOM);
            View stage = (View) roomView.getParent();
            stage.setClipToOutline(true);          // keep the picture inside the rounded corners
        }
    }

    /** Draws the illustrated accessory (no emoji) inside the view, as a 64dp square. */
    public static void showArt(TextView v, @Nullable ShopItems.Item item) {
        if (item == null) {
            v.setForeground(null);
            v.setText("");
            v.setVisibility(View.GONE);
            return;
        }
        int size = Math.round(64 * v.getResources().getDisplayMetrics().density);
        v.setText("");
        v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 2);
        v.setMinWidth(size); v.setMinimumWidth(size);
        v.setMinHeight(size); v.setMinimumHeight(size);
        if (item.art != 0) {
            v.setForeground(androidx.core.content.ContextCompat.getDrawable(v.getContext(), item.art));
        } else {
            v.setForeground(null);
            v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 44);
            v.setText(item.emoji);            // fallback for any item without art yet
        }
        v.setVisibility(View.VISIBLE);
    }

    /** Applies a saved position/size/rotation (in dp) to an accessory view. */
    public static void place(TextView v, float[] p) {
        if (p == null) p = LookPrefs.DEFAULT;
        float d = v.getResources().getDisplayMetrics().density;
        v.setTranslationX(p[0] * d);
        v.setTranslationY(p[1] * d);
        v.setScaleX(p[2]);
        v.setScaleY(p[2]);
        v.setRotation(p[3]);
    }
}
