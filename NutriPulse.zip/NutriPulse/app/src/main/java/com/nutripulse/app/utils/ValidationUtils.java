package com.nutripulse.app.utils;

import android.text.TextUtils;
import android.util.Patterns;

import java.util.regex.Pattern;

public final class ValidationUtils {
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9_.]{3,20}$");

    private ValidationUtils() {}

    public static boolean isEmpty(String s) { return s == null || s.trim().isEmpty(); }

    public static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches();
    }

    public static boolean isValidUsername(String username) {
        return username != null && USERNAME.matcher(username.trim()).matches();
    }

    public static boolean isValidFullName(String name) {
        return name != null && name.trim().length() >= 2;
    }

    /**
     * Minimum password policy. Returns null when the password is acceptable,
     * otherwise a friendly message describing what's missing.
     */
    public static String passwordProblem(String password) {
        if (password == null || password.isEmpty()) return "Password is required";
        if (password.length() < 8) return "Use at least 8 characters";
        if (!password.matches(".*[A-Z].*")) return "Add at least one uppercase letter";
        if (!password.matches(".*[a-z].*")) return "Add at least one lowercase letter";
        if (!password.matches(".*\\d.*")) return "Add at least one number";
        if (password.contains(" ")) return "Spaces are not allowed";
        return null;
    }

    /** 0..4 strength score used for the strength meter on the register screen. */
    public static int passwordStrength(String password) {
        if (password == null) return 0;
        int score = 0;
        if (password.length() >= 8) score++;
        if (password.matches(".*[A-Z].*") && password.matches(".*[a-z].*")) score++;
        if (password.matches(".*\\d.*")) score++;
        if (password.matches(".*[^A-Za-z0-9].*") || password.length() >= 12) score++;
        return score;
    }

    public static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase();
    }
}
