package com.nutripulse.app.auth;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteConstraintException;
import android.util.Log;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.nutripulse.app.cloud.Cloud;
import com.nutripulse.app.cloud.CloudBackup;
import com.nutripulse.app.data.UserInitializer;
import com.nutripulse.app.database.AppDatabase;
import com.nutripulse.app.models.User;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.PasswordUtils;
import com.nutripulse.app.utils.SessionManager;
import com.nutripulse.app.utils.ValidationUtils;

import java.util.concurrent.TimeUnit;

/**
 * Single entry point for account creation, login, password reset and logout.
 *
 * Two modes, chosen automatically:
 *  - OFFLINE (no google-services.json): Room + PBKDF2 hashing on the device.
 *  - CLOUD (Firebase set up): Firebase Authentication is the source of truth, Firestore keeps a
 *    backup, and a local hashed copy still allows logging in without internet.
 *
 * All callbacks are delivered on the main thread.
 */
public class AuthManager {

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String message);
    }

    private static final String TAG = "AuthManager";
    private static final int MAX_ATTEMPTS = 5;
    private static final long LOCK_MS = 60_000;          // 1 minute lockout after 5 failures
    private static final String GENERIC_LOGIN_ERROR = "Incorrect email or password.";
    private static final String GENERIC_ERROR = "Something went wrong. Please try again.";

    private static volatile AuthManager instance;

    private final Context app;
    private final AppDatabase db;
    private final SessionManager session;
    private final SharedPreferences lockPrefs;

    private AuthManager(Context context) {
        app = context.getApplicationContext();
        db = AppDatabase.get(app);
        session = new SessionManager(app);
        lockPrefs = app.getSharedPreferences("nutripulse_login_guard", Context.MODE_PRIVATE);
    }

    public static AuthManager get(Context context) {
        if (instance == null) {
            synchronized (AuthManager.class) {
                if (instance == null) instance = new AuthManager(context);
            }
        }
        return instance;
    }

    public SessionManager session() { return session; }

    public boolean isLoggedIn() { return session.isLoggedIn(); }

    /** True when Firebase is set up (cloud login, reset emails, backup, AI). */
    public boolean isCloud() { return Cloud.isReady(app); }

    // ================================================================== LOGIN

    public void login(String emailRaw, String password, boolean rememberMe, Callback<User> cb) {
        final String email = ValidationUtils.normalizeEmail(emailRaw);
        AppExecutors.io(() -> {
            long lockedFor = remainingLock(email);
            if (lockedFor > 0) {
                post(cb, null, "Too many failed attempts. Try again in " + ((lockedFor + 999) / 1000) + " seconds.");
                return;
            }
            if (!isCloud()) {
                loginLocal(email, password, rememberMe, cb);
                return;
            }
            try {
                AuthResult result = Tasks.await(Cloud.auth().signInWithEmailAndPassword(email, password),
                        30, TimeUnit.SECONDS);
                onCloudSignIn(result.getUser(), email, password, rememberMe, cb);
            } catch (Exception e) {
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                if (cause instanceof FirebaseNetworkException || e instanceof java.util.concurrent.TimeoutException) {
                    loginLocal(email, password, rememberMe, cb);          // no internet: use the device copy
                } else {
                    tryLinkLocalAccount(email, password, rememberMe, cb);  // maybe a local-only account
                }
            }
        });
    }

    /** Runs on a background thread. */
    private void loginLocal(String email, String password, boolean rememberMe, Callback<User> cb) {
        try {
            User user = db.userDao().findByEmail(email);
            boolean ok = user != null && PasswordUtils.verify(password, user.passwordSalt, user.passwordHash);
            if (!ok) {
                registerFailure(email);
                post(cb, null, GENERIC_LOGIN_ERROR);    // same message whether the email exists or not
                return;
            }
            clearFailures(email);
            session.createSession(user.id, rememberMe, user.email);
            post(cb, user, null);
        } catch (Exception e) {
            Log.e(TAG, "local login failed", e);
            post(cb, null, GENERIC_ERROR);
        }
    }

    /** Firebase accepted the password. Make sure a matching local account exists (restore on a new phone). */
    private void onCloudSignIn(FirebaseUser fu, String email, String password, boolean rememberMe, Callback<User> cb) {
        try {
            User u = db.userDao().findByEmail(email);
            boolean newOnThisPhone = u == null;
            if (newOnThisPhone) {
                u = new User();
                u.email = email;
                u.fullName = fu.getDisplayName() != null && !fu.getDisplayName().isEmpty()
                        ? fu.getDisplayName() : email.substring(0, email.indexOf('@'));
                u.username = uniqueUsername(email.substring(0, email.indexOf('@')));
                u.registrationDate = System.currentTimeMillis();
            }
            // Keep the offline copy in sync with the cloud password (e.g. after a reset email)
            u.passwordSalt = PasswordUtils.newSalt();
            u.passwordHash = PasswordUtils.hash(password, u.passwordSalt);
            if (newOnThisPhone) {
                u.id = db.userDao().insert(u);
                boolean restored = false;
                try {
                    restored = CloudBackup.restoreBlocking(app, fu.getUid(), u.id);
                } catch (Exception e) {
                    Log.w(TAG, "restore failed", e);
                }
                if (!restored) {
                    final User fresh = u;
                    db.runInTransaction(() -> UserInitializer.initialize(db, fresh));
                }
                u = db.userDao().findById(u.id);
            } else {
                db.userDao().updatePassword(u.id, u.passwordHash, u.passwordSalt);
            }
            clearFailures(email);
            session.createSession(u.id, rememberMe, u.email);
            post(cb, u, null);
        } catch (Exception e) {
            Log.e(TAG, "cloud sign-in finish failed", e);
            post(cb, null, GENERIC_ERROR);
        }
    }

    /**
     * Firebase rejected the login. If the details match an account that only exists on this phone
     * (made before cloud setup or while offline), create the cloud account now and continue.
     */
    private void tryLinkLocalAccount(String email, String password, boolean rememberMe, Callback<User> cb) {
        User local = db.userDao().findByEmail(email);
        if (local == null || !PasswordUtils.verify(password, local.passwordSalt, local.passwordHash)) {
            registerFailure(email);
            post(cb, null, GENERIC_LOGIN_ERROR);
            return;
        }
        try {
            AuthResult r = Tasks.await(Cloud.auth().createUserWithEmailAndPassword(email, password), 30, TimeUnit.SECONDS);
            setDisplayName(r.getUser(), local.fullName);
            clearFailures(email);
            session.createSession(local.id, rememberMe, local.email);
            post(cb, local, null);
            CloudBackup.backup(app, local.id, (ok, msg) -> { });
        } catch (Exception e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            if (cause instanceof FirebaseAuthUserCollisionException) {
                // The cloud account exists with a newer password: the old device password no longer counts.
                registerFailure(email);
                post(cb, null, GENERIC_LOGIN_ERROR + " If you reset your password by email, use the new one.");
            } else {
                // Offline: let the user in with the device copy; linking happens next time.
                clearFailures(email);
                session.createSession(local.id, rememberMe, local.email);
                post(cb, local, null);
            }
        }
    }

    // =============================================================== REGISTER

    public void register(String fullName, String emailRaw, String username, String password, Callback<User> cb) {
        final String email = ValidationUtils.normalizeEmail(emailRaw);
        final String uname = username.trim();
        AppExecutors.io(() -> {
            try {
                if (db.userDao().countEmail(email) > 0) { post(cb, null, "EMAIL_TAKEN"); return; }
                if (db.userDao().countUsername(uname) > 0) { post(cb, null, "USERNAME_TAKEN"); return; }

                FirebaseUser cloudUser = null;
                if (isCloud()) {
                    try {
                        cloudUser = Tasks.await(Cloud.auth().createUserWithEmailAndPassword(email, password),
                                30, TimeUnit.SECONDS).getUser();
                        setDisplayName(cloudUser, fullName.trim());
                    } catch (Exception e) {
                        Throwable cause = e.getCause() != null ? e.getCause() : e;
                        if (cause instanceof FirebaseAuthUserCollisionException) { post(cb, null, "EMAIL_TAKEN"); return; }
                        if (!(cause instanceof FirebaseNetworkException) && !(e instanceof java.util.concurrent.TimeoutException)) {
                            Log.w(TAG, "cloud register failed", e);
                            post(cb, null, "Could not create your cloud account: " + cause.getMessage());
                            return;
                        }
                        // No internet: create the account on this phone; it links to the cloud at next login.
                    }
                }

                User user = new User();
                user.fullName = fullName.trim();
                user.email = email;
                user.username = uname;
                user.passwordSalt = PasswordUtils.newSalt();
                user.passwordHash = PasswordUtils.hash(password, user.passwordSalt);
                user.registrationDate = System.currentTimeMillis();
                db.runInTransaction(() -> {
                    user.id = db.userDao().insert(user);
                    UserInitializer.initialize(db, user);   // Berry Lv1, goals, achievements, preferences
                });
                session.createSession(user.id, true, user.email);
                post(cb, user, null);
                if (cloudUser != null) CloudBackup.backup(app, user.id, (ok, msg) -> { });
            } catch (SQLiteConstraintException dup) {
                post(cb, null, "That email or username is already registered.");
            } catch (Exception e) {
                Log.e(TAG, "register failed", e);
                post(cb, null, "Could not create your account. Please try again.");
            }
        });
    }

    // ========================================================= PASSWORD RESET

    /**
     * CLOUD mode: Firebase emails a secure reset link. The answer is the same whether or not the
     * email is registered, so nobody can use this screen to discover accounts.
     */
    public void sendResetEmail(String emailRaw, Callback<Void> cb) {
        final String email = ValidationUtils.normalizeEmail(emailRaw);
        Cloud.auth().sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            Exception e = task.getException();
            if (e instanceof FirebaseNetworkException) cb.onError("No internet connection. Please try again.");
            else cb.onSuccess(null);
        });
    }

    /** OFFLINE mode: verify email + username, then set a new password on this device. */
    public void resetPassword(String emailRaw, String username, String newPassword, Callback<Void> cb) {
        final String email = ValidationUtils.normalizeEmail(emailRaw);
        AppExecutors.io(() -> {
            try {
                User user = db.userDao().findByEmail(email);
                if (user == null || !user.username.equalsIgnoreCase(username.trim())) {
                    post(cb, null, "We couldn't verify those details. Check your email and username.");
                    return;
                }
                String salt = PasswordUtils.newSalt();
                db.userDao().updatePassword(user.id, PasswordUtils.hash(newPassword, salt), salt);
                clearFailures(email);
                post(cb, null, null);
            } catch (Exception e) {
                Log.e(TAG, "reset failed", e);
                post(cb, null, GENERIC_ERROR);
            }
        });
    }

    /** Change password for the logged-in user (requires the current password). */
    public void changePassword(String currentPassword, String newPassword, Callback<Void> cb) {
        final long id = session.getUserId();
        AppExecutors.io(() -> {
            try {
                User user = id > 0 ? db.userDao().findById(id) : null;
                if (user == null) { post(cb, null, "NO_SESSION"); return; }
                FirebaseUser fu = Cloud.user(app);
                if (fu != null) {
                    try {
                        Tasks.await(fu.reauthenticate(EmailAuthProvider.getCredential(user.email, currentPassword)),
                                30, TimeUnit.SECONDS);
                        Tasks.await(fu.updatePassword(newPassword), 30, TimeUnit.SECONDS);
                    } catch (Exception e) {
                        Throwable cause = e.getCause() != null ? e.getCause() : e;
                        post(cb, null, cause instanceof FirebaseNetworkException
                                ? "You need internet to change your cloud password."
                                : "Your current password is incorrect.");
                        return;
                    }
                } else if (!PasswordUtils.verify(currentPassword, user.passwordSalt, user.passwordHash)) {
                    post(cb, null, "Your current password is incorrect.");
                    return;
                }
                String salt = PasswordUtils.newSalt();
                db.userDao().updatePassword(user.id, PasswordUtils.hash(newPassword, salt), salt);
                post(cb, null, null);
            } catch (Exception e) {
                Log.e(TAG, "change password failed", e);
                post(cb, null, GENERIC_ERROR);
            }
        });
    }

    // ================================================================== OTHER

    public void loadCurrentUser(Callback<User> cb) {
        final long id = session.getUserId();
        AppExecutors.io(() -> {
            User u = id > 0 ? db.userDao().findById(id) : null;
            if (u == null) post(cb, null, "NO_SESSION"); else post(cb, u, null);
        });
    }

    /** Ends the session (and the Firebase sign-in). Account and wellness data are kept. */
    public void logout() {
        session.logout();
        if (isCloud()) Cloud.auth().signOut();
    }

    // ================================================================ helpers

    private String uniqueUsername(String base) {
        String clean = base.replaceAll("[^A-Za-z0-9_.]", "");
        if (clean.length() < 3) clean = clean + "user";
        if (clean.length() > 16) clean = clean.substring(0, 16);
        String name = clean;
        int n = 1;
        while (db.userDao().countUsername(name) > 0) name = clean + (n++);
        return name;
    }

    private static void setDisplayName(FirebaseUser fu, String name) {
        if (fu == null) return;
        fu.updateProfile(new UserProfileChangeRequest.Builder().setDisplayName(name).build());
    }

    private long remainingLock(String email) {
        long until = lockPrefs.getLong("until_" + email, 0);
        return Math.max(0, until - System.currentTimeMillis());
    }

    private void registerFailure(String email) {
        int attempts = lockPrefs.getInt("count_" + email, 0) + 1;
        SharedPreferences.Editor e = lockPrefs.edit();
        if (attempts >= MAX_ATTEMPTS) {
            e.putLong("until_" + email, System.currentTimeMillis() + LOCK_MS).putInt("count_" + email, 0);
        } else {
            e.putInt("count_" + email, attempts);
        }
        e.apply();
    }

    private void clearFailures(String email) {
        lockPrefs.edit().remove("count_" + email).remove("until_" + email).apply();
    }

    private static <T> void post(Callback<T> cb, T value, String error) {
        AppExecutors.main(() -> {
            if (error == null) cb.onSuccess(value); else cb.onError(error);
        });
    }
}
