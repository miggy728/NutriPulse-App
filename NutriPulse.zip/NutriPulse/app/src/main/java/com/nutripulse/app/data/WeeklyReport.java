package com.nutripulse.app.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Builds the weekly/monthly report from day-by-day numbers.
 * Pure Java (no Android), so the math can be unit tested.
 */
public class WeeklyReport {

    public static class DayRow {
        public String dateKey;
        public String label;        // e.g. "Mon 17"
        public int calories;
        public float protein, carbs, fat;
        public int water;
        public int steps;
        public float weight = Float.NaN;
        public int mood;            // 0 = not logged
        public boolean logged;      // any food logged
    }

    // Inputs
    public String userName = "";
    public String userEmail = "";
    public String rangeLabel = "";
    public int calorieGoal = 2000, waterGoal = 8, stepGoal = 7000;
    public float heightCm;
    public int streak, petLevel, achievementsUnlocked, achievementsTotal;
    public List<DayRow> days = new ArrayList<>();

    // Results
    public int daysLogged, waterGoalDays, stepGoalDays, calorieGoalDays;
    public int avgCalories, totalSteps, avgSteps;
    public float avgWater, avgMood = Float.NaN;
    public float weightChange = Float.NaN, latestWeight = Float.NaN;
    public DayRow bestStepDay;
    public List<String> highlights = new ArrayList<>();
    public List<String> tips = new ArrayList<>();
    public String moodInsight;

    public WeeklyReport compute() {
        int n = Math.max(1, days.size());
        int calSum = 0, calDays = 0, waterSum = 0, moodSum = 0, moodDays = 0;
        float firstWeight = Float.NaN;
        for (DayRow d : days) {
            if (d.logged) { daysLogged++; calSum += d.calories; calDays++; }
            if (d.water >= waterGoal) waterGoalDays++;
            if (d.steps >= stepGoal) stepGoalDays++;
            // "Within goal" = logged and between 80% and 110% of the calorie goal
            if (d.logged && d.calories >= calorieGoal * 0.8 && d.calories <= calorieGoal * 1.1) calorieGoalDays++;
            waterSum += d.water;
            totalSteps += d.steps;
            if (d.mood > 0) { moodSum += d.mood; moodDays++; }
            if (!Float.isNaN(d.weight)) {
                if (Float.isNaN(firstWeight)) firstWeight = d.weight;
                latestWeight = d.weight;
            }
            if (d.steps > 0 && (bestStepDay == null || d.steps > bestStepDay.steps)) bestStepDay = d;
        }
        avgCalories = calDays == 0 ? 0 : Math.round((float) calSum / calDays);
        avgWater = (float) waterSum / n;
        avgSteps = Math.round((float) totalSteps / n);
        if (moodDays > 0) avgMood = (float) moodSum / moodDays;
        if (!Float.isNaN(firstWeight) && !Float.isNaN(latestWeight)) weightChange = latestWeight - firstWeight;

        buildHighlights(n);
        buildMoodInsight();
        return this;
    }

    private void buildHighlights(int n) {
        if (daysLogged == n) highlights.add("🌟 You logged food every single day. Amazing consistency!");
        else if (daysLogged > 0) highlights.add("📒 You logged food on " + daysLogged + " of " + n + " days.");
        if (waterGoalDays > 0) highlights.add("💧 You reached your water goal on " + waterGoalDays + " day(s).");
        if (bestStepDay != null) highlights.add(String.format(Locale.US,
                "👟 Your most active day was %s with %,d steps.", bestStepDay.label, bestStepDay.steps));
        if (streak >= 3) highlights.add("🔥 You're on a " + streak + "-day logging streak!");
        if (!Float.isNaN(weightChange) && Math.abs(weightChange) >= 0.1f) {
            highlights.add(String.format(Locale.US, "⚖️ Weight change in this period: %+.1f kg.", weightChange));
        }
        if (highlights.isEmpty()) highlights.add("🌱 A fresh start! Log a meal and some water to see your progress here.");

        // Gentle, specific tips for the weakest areas (no pressure, just ideas)
        if (daysLogged < n * 0.6) tips.add("Try logging at least one meal a day. Even breakfast counts!");
        if (waterGoalDays < n * 0.5) tips.add("Keep a water bottle nearby and sip between tasks.");
        if (avgSteps < stepGoal * 0.6) tips.add("A 10-minute walk after a meal is an easy way to add steps.");
        if (daysLogged > 0 && avgCalories < calorieGoal * 0.6)
            tips.add("Your logged calories are quite low. Make sure you're eating enough, regular meals.");
        if (tips.isEmpty()) tips.add("You're doing well across the board. Keep the same rhythm next week!");
    }

    /** A simple pattern (not proof): average mood on water-goal days vs other days. */
    private void buildMoodInsight() {
        int goodSum = 0, goodN = 0, otherSum = 0, otherN = 0, lowDays = 0;
        for (DayRow d : days) {
            if (d.mood == 0) continue;
            if (d.mood <= 2) lowDays++;
            if (d.water >= waterGoal) { goodSum += d.mood; goodN++; } else { otherSum += d.mood; otherN++; }
        }
        if (lowDays >= 3) {
            moodInsight = "You noted a low mood on " + lowDays + " days. That's worth paying attention to. "
                    + "Talking with someone you trust, or a counselor, can really help 💗";
        } else if (goodN >= 2 && otherN >= 2) {
            float a = (float) goodSum / goodN, b = (float) otherSum / otherN;
            if (a - b >= 0.5f) {
                moodInsight = String.format(Locale.US, "On days you hit your water goal, your mood averaged %.1f vs %.1f "
                        + "on other days. Just a pattern, but a nice one! 💧", a, b);
            }
        }
    }

    public static String moodEmoji(float avg) {
        if (Float.isNaN(avg)) return "–";
        int i = Math.max(1, Math.min(5, Math.round(avg)));
        return new String[]{"", "😢", "😕", "😐", "🙂", "😄"}[i];
    }
}
