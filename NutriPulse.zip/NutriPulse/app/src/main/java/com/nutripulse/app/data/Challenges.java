package com.nutripulse.app.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Weekly challenges: three are picked each week (Monday to Sunday) from this pool. */
public final class Challenges {
    public static final int REWARD_EXP = 40;

    public static final class Def {
        public final String id, emoji, title;
        public final int target;
        Def(String id, String emoji, String title, int target) {
            this.id = id; this.emoji = emoji; this.title = title; this.target = target;
        }
    }

    public static final class Status {
        public Def def;
        public int progress;
        public boolean claimed;
        public boolean isDone() { return progress >= def.target; }
    }

    private Challenges() {}

    public static final List<Def> POOL = Arrays.asList(
            new Def("water_days", "💧", "Reach your water goal on 4 days", 4),
            new Def("log_days", "📒", "Log food on 6 different days", 6),
            new Def("healthy_meals", "🥗", "Log 10 healthy foods", 10),
            new Def("veggies", "🥦", "Eat vegetables 4 times", 4),
            new Def("fruit", "🍎", "Eat fruit 5 times", 5),
            new Def("steps_total", "👟", "Walk 30,000 steps this week", 30000),
            new Def("mood_days", "😊", "Check in your mood on 5 days", 5),
            new Def("quiz_days", "🧠", "Answer the daily quiz on 4 days", 4),
            new Def("all_goals_days", "⭐", "Finish all daily goals on 2 days", 2)
    );

    private static final String[] VEGGIE_WORDS = {"salad", "pinakbet", "chopsuey", "gulay", "carrot", "monggo",
            "talong", "veggies", "sinigang", "tofu", "kangkong", "malunggay", "ampalaya", "broccoli"};
    private static final String[] FRUIT_WORDS = {"apple", "banana", "mango", "saba", "saging", "orange",
            "calamansi", "buko", "fruit", "pakwan", "watermelon", "guava", "bayabas", "papaya"};

    public static boolean isVeggie(String name) { return containsAny(name, VEGGIE_WORDS); }
    public static boolean isFruit(String name) { return containsAny(name, FRUIT_WORDS); }

    private static boolean containsAny(String name, String[] words) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String w : words) if (n.contains(w)) return true;
        return false;
    }

    /** Monday of the current week. */
    public static Calendar weekStart() {
        Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        int dow = c.get(Calendar.DAY_OF_WEEK);               // Sunday=1 ... Saturday=7
        int back = (dow + 5) % 7;                            // days since Monday
        c.add(Calendar.DAY_OF_YEAR, -back);
        return c;
    }

    /** The same three challenges all week for everyone; they change every Monday. */
    public static List<Def> thisWeek(String weekKey) {
        List<Def> copy = new ArrayList<>(POOL);
        Collections.shuffle(copy, new Random(weekKey.hashCode()));
        return copy.subList(0, 3);
    }
}
