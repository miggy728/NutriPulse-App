package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** A food the user starred, saved by name. */
@Entity(tableName = "favorite_foods",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "foodName"}, unique = true)})
public class FavoriteFood {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String foodName = "";
    public long createdAt;
}
