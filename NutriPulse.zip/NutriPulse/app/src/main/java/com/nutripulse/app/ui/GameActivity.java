package com.nutripulse.app.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import com.nutripulse.app.R;
import com.nutripulse.app.views.SnackGameView;

/** Hosts the Snack Catch mini-game and hands out EXP for good scores. */
public class GameActivity extends BaseAuthActivity implements SnackGameView.Listener {

    private SnackGameView game;
    private TextView time, score, lives, best, panelEmoji, panelTitle, panelText;
    private View panel;
    private MaterialButton start;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_game);
        prefs = getSharedPreferences("nutripulse_game", Context.MODE_PRIVATE);

        game = findViewById(R.id.game_view);
        time = findViewById(R.id.game_time);
        score = findViewById(R.id.game_score);
        lives = findViewById(R.id.game_lives);
        best = findViewById(R.id.game_best);
        panel = findViewById(R.id.game_panel);
        panelEmoji = findViewById(R.id.game_panel_emoji);
        panelTitle = findViewById(R.id.game_panel_title);
        panelText = findViewById(R.id.game_panel_text);
        start = findViewById(R.id.game_start);

        game.setListener(this);
        best.setText("🏆 " + bestScore());
        findViewById(R.id.game_back).setOnClickListener(v -> finish());
        start.setOnClickListener(v -> {
            panel.setVisibility(View.GONE);
            game.start();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (game != null && game.isRunning()) {
            game.stop();
            panelEmoji.setText("⏸️");
            panelTitle.setText("Paused");
            panelText.setText("Tap Start to play a new round.");
            start.setText("▶  Start");
            panel.setVisibility(View.VISIBLE);
        }
    }

    private String bestKey() { return "best_" + session.getUserId(); }

    private int bestScore() { return prefs.getInt(bestKey(), 0); }

    @Override
    public void onHud(int s, int l, int secondsLeft) {
        score.setText("⭐ " + s);
        time.setText("⏱ " + secondsLeft);
        StringBuilder h = new StringBuilder();
        for (int i = 0; i < 3; i++) h.append(i < l ? "❤️" : "🤍");
        lives.setText(h.toString());
    }

    @Override
    public void onGameOver(int finalScore) {
        boolean record = finalScore > bestScore();
        if (record) prefs.edit().putInt(bestKey(), finalScore).apply();
        best.setText("🏆 " + bestScore());
        repo.rewardGame(finalScore, r -> {
            String reward;
            if (r == null || !r.ok) reward = r != null && r.error != null ? r.error : "";
            else reward = r.expGained > 0 ? "Berry earned +" + r.expGained + " EXP and +" + r.coinsGained + " 🪙!" : "";
            panelEmoji.setText(finalScore >= 20 ? "🏆🍓" : finalScore >= 10 ? "🎉🍓" : "🍓");
            panelTitle.setText(record ? "New best score: " + finalScore + "!" : "Score: " + finalScore);
            panelText.setText((finalScore >= 15 ? "Wow, Berry is so full of healthy food! 💗"
                    : "Nice try! Healthy snacks make Berry strong 💪") + (reward.isEmpty() ? "" : "\n\n" + reward));
            start.setText("↻  Play again");
            panel.setVisibility(View.VISIBLE);
            Feedback.show(this, r != null && r.ok ? r : null, null);
        });
    }
}
