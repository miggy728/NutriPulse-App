package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "weight_records",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey"})})
public class WeightRecord {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    public float weightKg;
    @NonNull public String dateKey = "";
    public long timestamp;
}
