package com.nutripulse.app.ui;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.R;
import com.nutripulse.app.data.ChatBot;
import com.nutripulse.app.data.AiPrompt;
import com.nutripulse.app.cloud.GeminiChat;
import android.content.SharedPreferences;
import com.nutripulse.app.models.ChatMessage;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.ChatHistory;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.UiUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** "Chat with Berry": an offline wellness chatbot that knows the logged-in user's data. */
public class ChatActivity extends BaseAuthActivity {

    private final List<ChatMessage> messages = new ArrayList<>();
    private final ChatBot bot = new ChatBot();
    private ChatHistory history;
    private ChatAdapter adapter;
    private RecyclerView list;
    private EditText input;
    private LinearLayout suggestions;
    private ImageView avatar;
    private TextView status;
    private boolean waiting = false;
    private SharedPreferences aiPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_chat);

        history = new ChatHistory(this, session.getUserId());
        aiPrefs = getSharedPreferences("nutripulse_ai", MODE_PRIVATE);
        list = findViewById(R.id.chat_list);
        input = findViewById(R.id.chat_input);
        suggestions = findViewById(R.id.chat_suggestions);
        avatar = findViewById(R.id.chat_avatar);
        status = findViewById(R.id.chat_status);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        list.setLayoutManager(lm);
        adapter = new ChatAdapter();
        list.setAdapter(adapter);

        findViewById(R.id.chat_back).setOnClickListener(v -> finish());
        findViewById(R.id.chat_menu).setOnClickListener(v -> showMenu());
        findViewById(R.id.chat_send).setOnClickListener(v -> sendFromInput());
        avatar.setOnClickListener(UiUtils::bounce);
        input.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendFromInput(); return true; }
            return false;
        });

        updateStatus();

        // Berry's name in the header
        repo.getPet(pet -> {
            if (pet != null) ((TextView) findViewById(R.id.chat_title)).setText(pet.name);
        });

        messages.addAll(history.load());
        adapter.notifyDataSetChanged();
        if (messages.isEmpty()) {
            repo.loadChatContext(ctx -> {
                if (ctx == null) { redirectToLogin(); return; }
                addBerry(bot.greeting(ctx));
            });
        } else {
            showSuggestions(Arrays.asList("How am I doing?", "What should I eat?", "Give me a tip"));
            scrollToEnd();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (history != null) history.save(messages);
    }

    // ------------------------------------------------------------ sending

    private void sendFromInput() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        send(text);
    }

    private void send(String text) {
        if (waiting) return;
        waiting = true;
        messages.add(new ChatMessage(ChatMessage.FROM_USER, text, System.currentTimeMillis()));
        adapter.notifyItemInserted(messages.size() - 1);
        showSuggestions(new ArrayList<>());
        showTyping(true);

        // Fresh data each time, so answers reflect what was just logged.
        repo.loadChatContext(ctx -> {
            if (ctx == null) { redirectToLogin(); return; }
            ChatBot.Reply reply = bot.reply(text, ctx);
            if (aiOn() && !ChatBot.mustUseOffline(reply)) {
                // Real AI answer (Gemini via Firebase). Falls back to offline Berry on any problem.
                List<ChatMessage> past = new ArrayList<>(messages.subList(0, Math.max(0, messages.size() - 2)));
                GeminiChat.ask(this, AiPrompt.build(ctx, past, text), new GeminiChat.Callback() {
                    @Override public void onReply(String aiText) {
                        if (isFinishing()) return;
                        showTyping(false);
                        addBerryText(aiText, reply.suggestions);
                    }
                    @Override public void onError(String err) {
                        if (isFinishing()) return;
                        showTyping(false);
                        android.util.Log.w("NutriPulseAI", "Gemini failed: " + err);
                        boolean debuggable = (getApplicationInfo().flags
                                & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
                        String why = debuggable ? "\n[debug] " + err : "";
                        addBerryText(reply.text + "\n\n(📴 offline answer: AI is unavailable right now)" + why, reply.suggestions);
                    }
                });
                return;
            }
            long delay = 450 + Math.min(1200, reply.text.length() * 6L);   // feels like typing
            AppExecutors.mainDelayed(() -> {
                if (isFinishing()) return;
                if (ChatBot.ACTION_LOG_WATER.equals(reply.action)) {
                    repo.addWater(1, r -> {
                        showTyping(false);
                        String extra = "";
                        if (r != null && r.ok) {
                            extra = "\n\n✅ Done! " + (ctx.water + 1) + " / " + ctx.user.hydrationGoal + " cups today.";
                            if (r.expGained > 0) extra += " +" + r.expGained + " EXP for me! 💗";
                            if (!r.completedGoals.isEmpty()) extra += "\n🎯 Goal complete: " + String.join(", ", r.completedGoals);
                            if (r.leveledUp) extra += "\n🎉 I leveled up to Lv." + r.newLevel + "!";
                            if (!r.unlocked.isEmpty()) extra += "\n🏆 Achievement: " + String.join(", ", r.unlocked);
                        }
                        addBerryText(reply.text + extra, reply.suggestions);
                    });
                } else {
                    showTyping(false);
                    addBerry(reply);
                }
            }, delay);
        });
    }

    private void addBerry(ChatBot.Reply reply) {
        addBerryText(reply.text, reply.suggestions);
    }

    private void addBerryText(String text, List<String> chips) {
        messages.add(new ChatMessage(ChatMessage.FROM_BERRY, text, System.currentTimeMillis()));
        adapter.notifyItemInserted(messages.size() - 1);
        scrollToEnd();
        UiUtils.bounce(avatar);
        showSuggestions(chips);
        waiting = false;
        history.save(messages);
    }

    private boolean aiOn() {
        return GeminiChat.isAvailable(this) && aiPrefs.getBoolean("ai_on_" + session.getUserId(), false);
    }

    private void updateStatus() {
        status.setText(aiOn() ? "● AI mode (Gemini)" : "● Your wellness buddy");
        status.setTextColor(ContextCompat.getColor(this, aiOn() ? R.color.purple : R.color.green_ok));
    }

    private void toggleAi() {
        if (!GeminiChat.isAvailable(this)) {
            new NpDialogBuilder(this)
                    .setTitle("AI mode isn't set up")
                    .setMessage("Smart AI answers need Firebase. See FIREBASE_SETUP.md in the project (Firebase AI Logic). "
                            + "Until then, offline Berry is here for you 💗")
                    .setPositiveButton("OK", null).show();
            return;
        }
        if (aiOn()) {
            aiPrefs.edit().putBoolean("ai_on_" + session.getUserId(), false).apply();
            updateStatus();
            UiUtils.toast(this, "AI mode off. Offline Berry is back!");
            return;
        }
        new NpDialogBuilder(this)
                .setTitle("Turn on Smart AI mode?")
                .setMessage("Berry will use Google Gemini (through Firebase) for smarter answers.\n\n"
                        + "What is sent: your message, recent chat, your first name and today's numbers "
                        + "(calories, water, steps, foods, goals). Your email and password are never sent.\n\n"
                        + "AI can make mistakes and is not medical advice. Safety questions are always answered "
                        + "by offline Berry with hotline info.")
                .setPositiveButton("Turn on", (d, w) -> {
                    aiPrefs.edit().putBoolean("ai_on_" + session.getUserId(), true).apply();
                    updateStatus();
                })
                .setNegativeButton("Not now", null)
                .show();
    }

    private void showTyping(boolean on) {
        int last = messages.size() - 1;
        boolean hasTyping = last >= 0 && messages.get(last).sender == ChatMessage.TYPING;
        if (on && !hasTyping) {
            messages.add(new ChatMessage(ChatMessage.TYPING, "", 0));
            adapter.notifyItemInserted(messages.size() - 1);
            status.setText("✎ typing…");
            status.setTextColor(ContextCompat.getColor(this, R.color.pink_primary));
        } else if (!on && hasTyping) {
            messages.remove(last);
            adapter.notifyItemRemoved(last);
            updateStatus();
        }
        scrollToEnd();
    }

    private void scrollToEnd() {
        if (!messages.isEmpty()) list.post(() -> list.smoothScrollToPosition(messages.size() - 1));
    }

    private void showSuggestions(List<String> chips) {
        suggestions.removeAllViews();
        for (String chip : chips) {
            TextView t = new TextView(this);
            t.setText(chip);
            t.setTextSize(13);
            t.setTextColor(ContextCompat.getColor(this, R.color.pink_dark));
            t.setBackgroundResource(R.drawable.bg_pill);
            int h = UiUtils.dp(this, 14), v = UiUtils.dp(this, 8);
            t.setPadding(h, v, h, v);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(UiUtils.dp(this, 4), UiUtils.dp(this, 4), UiUtils.dp(this, 4), UiUtils.dp(this, 4));
            t.setOnClickListener(x -> send(chip));
            suggestions.addView(t, lp);
        }
    }

    private void showMenu() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_chat_options, null, false);
        boolean on = aiOn();
        com.google.android.material.switchmaterial.SwitchMaterial sw = v.findViewById(R.id.opt_ai_switch);
        sw.setChecked(on);
        ((TextView) v.findViewById(R.id.opt_ai_sub)).setText(on
                ? "On: Berry answers with Gemini AI"
                : "Off: Berry uses quick offline answers");
        androidx.appcompat.app.AlertDialog dialog = new NpDialogBuilder(this).setView(v).create();
        v.findViewById(R.id.opt_ai).setOnClickListener(x -> {
            sw.setChecked(!sw.isChecked());                    // instant visual feedback
            x.postDelayed(() -> { dialog.dismiss(); toggleAi(); }, 180);
        });
        v.findViewById(R.id.opt_help).setOnClickListener(x -> { dialog.dismiss(); send("help"); });
        v.findViewById(R.id.opt_clear).setOnClickListener(x -> {
            dialog.dismiss();
            new NpDialogBuilder(this)
                    .setTitle("Clear chat history?")
                    .setMessage("All messages with Berry will be removed. Your wellness data won't be affected.")
                    .setPositiveButton("Clear", (d2, w2) -> {
                        history.clear();
                        messages.clear();
                        adapter.notifyDataSetChanged();
                        repo.loadChatContext(ctx -> { if (ctx != null) addBerry(bot.greeting(ctx)); });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
        dialog.show();
    }

    // ------------------------------------------------------------ adapter

    private class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.VH> {
        @Override public int getItemViewType(int position) { return messages.get(position).sender; }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            int layout = viewType == ChatMessage.FROM_USER ? R.layout.item_chat_user : R.layout.item_chat_berry;
            return new VH(LayoutInflater.from(parent.getContext()).inflate(layout, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            ChatMessage m = messages.get(position);
            if (h.pulse != null) { h.pulse.cancel(); h.pulse = null; h.text.setAlpha(1f); }
            if (m.sender == ChatMessage.TYPING) {
                h.text.setText("●  ●  ●");
                h.pulse = ObjectAnimator.ofFloat(h.text, View.ALPHA, 1f, 0.3f);
                h.pulse.setDuration(500);
                h.pulse.setRepeatCount(ValueAnimator.INFINITE);
                h.pulse.setRepeatMode(ValueAnimator.REVERSE);
                h.pulse.start();
            } else {
                h.text.setText(m.text);
            }
            if (h.icon != null) {
                h.icon.setImageResource(DateUtils.isSleepyTime() ? R.drawable.mascot_berry_sleep : R.drawable.mascot_berry);
            }
            // Pop-in animation for new bubbles
            if (position == messages.size() - 1) {
                h.itemView.setAlpha(0f);
                h.itemView.setTranslationY(UiUtils.dp(ChatActivity.this, 12));
                h.itemView.animate().alpha(1f).translationY(0f).setDuration(220).start();
            }
        }

        @Override public int getItemCount() { return messages.size(); }

        class VH extends RecyclerView.ViewHolder {
            final TextView text;
            final ImageView icon;
            ObjectAnimator pulse;

            VH(View v) {
                super(v);
                text = v.findViewById(R.id.chat_text);
                icon = v.findViewById(R.id.chat_berry_icon);   // null for user bubbles
            }
        }
    }
}
