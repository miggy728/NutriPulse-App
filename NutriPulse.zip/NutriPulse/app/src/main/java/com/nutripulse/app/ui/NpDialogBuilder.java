package com.nutripulse.app.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.utils.UiUtils;

/**
 * Same as MaterialAlertDialogBuilder, but guarantees breathing room around the dialog buttons
 * (some phones ignore the theme margins, which made the pink button touch the dialog edge).
 */
public class NpDialogBuilder extends MaterialAlertDialogBuilder {

    public NpDialogBuilder(@NonNull Context context) { super(context); }

    @NonNull
    @Override
    public AlertDialog create() {
        AlertDialog dialog = super.create();
        if (dialog.getWindow() != null) {
            View decor = dialog.getWindow().getDecorView();
            decor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override public void onGlobalLayout() {
                    Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                    if (pos == null) return;
                    decor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    space(dialog);
                }
            });
        }
        return dialog;
    }

    /**
     * Puts the breathing room on the button BAR (padding), not on the buttons (margins):
     * margins made the bar clip the pink button on some phones.
     */
    private static void space(AlertDialog dialog) {
        Context c = dialog.getContext();
        Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (pos.getParent() instanceof ViewGroup) {
            ViewGroup bar = (ViewGroup) pos.getParent();
            bar.setPaddingRelative(UiUtils.dp(c, 16), UiUtils.dp(c, 14), UiUtils.dp(c, 18), UiUtils.dp(c, 18));
            bar.setClipToPadding(false);
            bar.setClipChildren(false);
            if (bar.getParent() instanceof ViewGroup) {
                ((ViewGroup) bar.getParent()).setClipChildren(false);
                ((ViewGroup) bar.getParent()).setClipToPadding(false);
            }
        }
        int[] which = {AlertDialog.BUTTON_NEUTRAL, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_POSITIVE};
        for (int w : which) {
            Button b = dialog.getButton(w);
            if (b == null || !(b.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) continue;
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) b.getLayoutParams();
            lp.topMargin = 0;
            lp.bottomMargin = 0;
            lp.setMarginStart(w == AlertDialog.BUTTON_POSITIVE ? UiUtils.dp(c, 10) : 0);
            lp.setMarginEnd(0);
            b.setLayoutParams(lp);
            b.setMinHeight(UiUtils.dp(c, 44));
            b.setMinimumHeight(UiUtils.dp(c, 44));
            b.setLetterSpacing(0f);
            b.setAllCaps(false);
        }
    }
}
