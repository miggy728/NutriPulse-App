package com.nutripulse.app.data;

/**
 * Body Mass Index helper using the WHO adult categories.
 * BMI is a general screening number only. It doesn't consider muscle, age or body shape,
 * and it is not meant for people under 18 or during pregnancy.
 */
public final class Bmi {
    private Bmi() {}

    /** Returns NaN if height or weight is missing. */
    public static float calculate(float weightKg, float heightCm) {
        if (weightKg <= 0 || heightCm <= 0) return Float.NaN;
        float m = heightCm / 100f;
        return weightKg / (m * m);
    }

    public static String category(float bmi) {
        if (Float.isNaN(bmi)) return "Not available";
        if (bmi < 18.5f) return "Below the healthy range";
        if (bmi < 25f) return "Within the healthy range";
        if (bmi < 30f) return "Above the healthy range";
        return "Well above the healthy range";
    }

    /** 0..1 position of the marker on a 15–35 scale bar. */
    public static float gaugePosition(float bmi) {
        if (Float.isNaN(bmi)) return 0f;
        return Math.max(0f, Math.min(1f, (bmi - 15f) / 20f));
    }

    /** Healthy weight range (kg) for a height, from BMI 18.5 to 24.9. */
    public static float[] healthyRange(float heightCm) {
        float m = heightCm / 100f;
        return new float[]{18.5f * m * m, 24.9f * m * m};
    }
}
