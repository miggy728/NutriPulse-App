package com.nutripulse.app.ui;

import android.os.Bundle;
import android.widget.TextView;

import com.nutripulse.app.R;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.views.LineChartView;
import com.nutripulse.app.data.Bmi;
import android.view.View;

import java.util.Locale;

/** Charts of weight, calories, steps and water for the logged-in user. */
public class ProgressActivity extends BaseAuthActivity {

    private String metric = "weight";
    private String range = "7D";
    private LineChartView chart;
    private TextView chartTitle, goalNote, sWeight, sGoal, sCalories;
    private final int[] metricIds = {R.id.tab_weight, R.id.tab_calories, R.id.tab_steps, R.id.tab_water, R.id.tab_mood};
    private final String[] metrics = {"weight", "calories", "steps", "water", "mood"};
    private final int[] rangeIds = {R.id.range_7d, R.id.range_30d, R.id.range_3m, R.id.range_6m, R.id.range_1y};
    private final String[] ranges = {"7D", "30D", "3M", "6M", "1Y"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_progress);
        BottomNav.setup(this, BottomNav.PROGRESS);

        chart = findViewById(R.id.progress_chart);
        chartTitle = findViewById(R.id.progress_chart_title);
        goalNote = findViewById(R.id.progress_goal_note);
        sWeight = findViewById(R.id.summary_weight);
        sGoal = findViewById(R.id.summary_goal);
        sCalories = findViewById(R.id.summary_calories);

        for (int i = 0; i < metricIds.length; i++) {
            final String m = metrics[i];
            findViewById(metricIds[i]).setOnClickListener(v -> { metric = m; refresh(); });
        }
        for (int i = 0; i < rangeIds.length; i++) {
            final String r = ranges[i];
            findViewById(rangeIds[i]).setOnClickListener(v -> { range = r; refresh(); });
        }
        findViewById(R.id.progress_back).setOnClickListener(v -> finish());
        findViewById(R.id.progress_action).setOnClickListener(v -> addEntry());
        findViewById(R.id.progress_report).setOnClickListener(v ->
                startActivity(new android.content.Intent(this, ReportActivity.class)));
        findViewById(R.id.bmi_edit).setOnClickListener(v -> Dialogs.number(this, "Your height",
                "Height in cm (e.g. 160)", true, 90, 250, cm -> repo.setHeight(cm, u -> loadBmi())));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!noSession()) refresh();
    }

    private void refresh() {
        for (int i = 0; i < metricIds.length; i++) findViewById(metricIds[i]).setSelected(metrics[i].equals(metric));
        for (int i = 0; i < rangeIds.length; i++) findViewById(rangeIds[i]).setSelected(ranges[i].equals(range));

        repo.getChart(metric, range, data -> {
            if (data == null) return;
            String name = "mood".equals(metric) ? "Mood (1 = very low, 5 = great)"
                    : metric.substring(0, 1).toUpperCase(Locale.US) + metric.substring(1);
            chartTitle.setText("mood".equals(metric) ? name : name + " (" + data.unit + ")");
            chart.setData(data.labels, data.values, data.unit, data.goal);
            boolean daily = range.equals("7D") || range.equals("30D");
            String note = data.goal > 0 ? "Dashed line = your goal (" + fmt(data.goal) + " " + data.unit + ")" : "";
            if (!daily && !"weight".equals(metric)) note += (note.isEmpty() ? "" : "\n") + "Values are daily averages.";
            if ("weight".equals(metric) && data.goal <= 0) note = "Set a target weight in Settings → Health Goals.";
            goalNote.setText(note);
        });
        repo.getProgressSummary(s -> {
            if (s == null) return;
            sWeight.setText(s.weightChange == null ? "–"
                    : String.format(Locale.US, "%+.1f kg", s.weightChange));
            sGoal.setText(s.goalProgressPercent < 0 ? "–" : s.goalProgressPercent + "%");
            sCalories.setText(String.format(Locale.US, "%,d", s.totalCalories30d));
        });
        loadBmi();
    }

    private void addEntry() {
        switch (metric) {
            case "weight":
                Dialogs.number(this, "Log weight", "Weight in kg", true, 20, 400, v ->
                        repo.addWeight(v, r -> { Feedback.show(this, r, "⚖️ Weight saved"); refresh(); }));
                break;
            case "steps":
                Dialogs.number(this, "Log steps", "Steps walked", false, 1, 100000, v ->
                        repo.addSteps((int) v, r -> { Feedback.show(this, r, "👟 Steps logged"); refresh(); }));
                break;
            case "water":
                Dialogs.number(this, "Log water", "Cups of water", false, 1, 20, v ->
                        repo.addWater((int) v, r -> { Feedback.show(this, r, "💧 Water logged"); refresh(); }));
                break;
            case "mood":
                UiUtils.toast(this, "Check in your mood on the Home screen 🙂");
                break;
            default:
                startActivity(new android.content.Intent(this, MealLoggerActivity.class));
        }
    }

    private void loadBmi() {
        repo.getBmiInputs(in -> {
            if (in == null) return;
            float height = in[0], weight = in[1];
            TextView value = findViewById(R.id.bmi_value), cat = findViewById(R.id.bmi_category),
                    note = findViewById(R.id.bmi_note), edit = findViewById(R.id.bmi_edit);
            View marker = findViewById(R.id.bmi_marker), gauge = findViewById(R.id.bmi_gauge);
            edit.setText(height > 0 ? String.format(Locale.US, "%.0f cm", height) : "Set height");
            float bmi = Bmi.calculate(weight, height);
            if (Float.isNaN(bmi)) {
                value.setText("–");
                cat.setText(height <= 0 ? "Add your height to see your BMI." : "Log your weight to see your BMI.");
                marker.setVisibility(View.GONE);
            } else {
                value.setText(String.format(Locale.US, "%.1f", bmi));
                cat.setText(Bmi.category(bmi));
                marker.setVisibility(View.VISIBLE);
                gauge.post(() -> marker.setTranslationX(
                        Bmi.gaugePosition(bmi) * (gauge.getWidth() - marker.getWidth())));
            }
            String range = "";
            if (height > 0) {
                float[] r = Bmi.healthyRange(height);
                range = String.format(Locale.US, "Healthy weight range for your height: %.1f–%.1f kg.\n", r[0], r[1]);
            }
            note.setText(range + "BMI is only a rough guide. It doesn't consider muscle or body shape, "
                    + "and isn't for people under 18 or during pregnancy. A doctor can give you the full picture 💗");
        });
    }

    private static String fmt(float f) {
        return f == Math.round(f) ? String.format(Locale.US, "%,d", Math.round(f)) : String.format(Locale.US, "%.1f", f);
    }
}
