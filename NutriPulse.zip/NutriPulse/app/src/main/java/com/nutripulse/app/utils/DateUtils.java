package com.nutripulse.app.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class DateUtils {
    private DateUtils() {}

    private static SimpleDateFormat keyFormat() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    }

    public static String todayKey() { return keyOf(Calendar.getInstance()); }

    public static String keyOf(Calendar c) { return keyFormat().format(c.getTime()); }

    /** Key for the day that is {@code daysAgo} days before today. */
    public static String daysAgoKey(int daysAgo) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -daysAgo);
        return keyOf(c);
    }

    public static Calendar parse(String key) {
        Calendar c = Calendar.getInstance();
        try {
            Date d = keyFormat().parse(key);
            if (d != null) c.setTime(d);
        } catch (Exception ignored) { }
        return c;
    }

    /** e.g. "Tuesday, 17 November" */
    public static String friendlyToday() {
        return new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date());
    }

    public static String format(String pattern, Calendar c) {
        return new SimpleDateFormat(pattern, Locale.getDefault()).format(c.getTime());
    }

    public static String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h < 12) return "Good morning";
        if (h < 18) return "Good afternoon";
        return "Good evening";
    }

    public static boolean isSleepyTime() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 22 || h < 6;
    }
}
