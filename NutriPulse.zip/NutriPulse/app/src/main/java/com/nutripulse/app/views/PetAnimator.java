package com.nutripulse.app.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.nutripulse.app.R;
import com.nutripulse.app.utils.PetSounds;

import java.util.Random;

/**
 * Brings Berry to life.
 *
 * - Idle: gentle breathing (squash and stretch), bobbing, random blinking and little fidgets.
 * - Sleeping: slow breathing with floating "Zzz".
 * - Reactions: tap, eat, drink, play, EXP pop-ups and a level-up celebration.
 *
 * Usage: create it in onCreate, call start() in onResume and stop() in onPause.
 * The pet "body" (mascot + crown) must be a direct child of the stage FrameLayout.
 */
public class PetAnimator {

    private final FrameLayout stage;
    private final View body;
    private final ImageView face;
    @Nullable private final View shadow;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final float dp;

    private AnimatorSet idle;
    private Animator current;
    private boolean running, busy, sleeping;

    public PetAnimator(FrameLayout stage, View body, ImageView face, @Nullable View shadow) {
        this.stage = stage;
        this.body = body;
        this.face = face;
        this.shadow = shadow;
        this.dp = stage.getResources().getDisplayMetrics().density;
    }

    // ================================================================ lifecycle

    public void start() {
        if (running) return;
        running = true;
        body.post(() -> {
            body.setPivotX(body.getWidth() / 2f);
            body.setPivotY(body.getHeight());       // squash from the feet, not the middle
            if (running && !busy) startIdle();
        });
        scheduleBlink();
        scheduleFidget();
        scheduleZzz();
    }

    public void stop() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (idle != null) idle.cancel();
        if (current != null) current.cancel();
        resetPose();
    }

    public void setSleeping(boolean value) {
        boolean changed = value != sleeping;
        sleeping = value;
        if (!busy) face.setImageResource(restingFace());
        if (changed && running && !busy) startIdle();
    }

    public boolean isSleeping() { return sleeping; }

    private int restingFace() {
        return sleeping ? R.drawable.mascot_berry_sleep : R.drawable.mascot_berry;
    }

    // ================================================================ idle loop

    private void startIdle() {
        if (idle != null) idle.cancel();
        long breath = sleeping ? 1800 : 900;
        ObjectAnimator breathe = ObjectAnimator.ofPropertyValuesHolder(body,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, sleeping ? 1.03f : 1.04f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, sleeping ? 0.97f : 0.95f));
        loop(breathe, breath);

        ObjectAnimator bob = ObjectAnimator.ofFloat(body, View.TRANSLATION_Y, 0f, sleeping ? -2 * dp : -7 * dp);
        loop(bob, breath);

        idle = new AnimatorSet();
        if (shadow != null) {
            ObjectAnimator shadowPulse = ObjectAnimator.ofPropertyValuesHolder(shadow,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.9f),
                    PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.75f));
            loop(shadowPulse, breath);
            idle.playTogether(breathe, bob, shadowPulse);
        } else {
            idle.playTogether(breathe, bob);
        }
        idle.start();
    }

    private static void loop(ValueAnimator a, long duration) {
        a.setDuration(duration);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
    }

    private void scheduleBlink() {
        handler.postDelayed(() -> {
            if (!running) return;
            if (!sleeping && !busy) {
                blinkOnce();
                if (rnd.nextInt(4) == 0) handler.postDelayed(this::blinkOnce, 260); // sometimes a double blink
            }
            scheduleBlink();
        }, 2200 + rnd.nextInt(3200));
    }

    private void blinkOnce() {
        if (sleeping || busy) return;
        face.setImageResource(R.drawable.mascot_berry_blink);
        handler.postDelayed(() -> { if (!busy) face.setImageResource(restingFace()); }, 130);
    }

    /** Every so often Berry does a little something on its own. */
    private void scheduleFidget() {
        handler.postDelayed(() -> {
            if (!running) return;
            if (!sleeping && !busy) {
                switch (rnd.nextInt(3)) {
                    case 0: react(hop(28), null); break;
                    case 1: react(wiggleAnim(8), null); break;
                    default: sparkle("✨", 2); break;
                }
            }
            scheduleFidget();
        }, 7000 + rnd.nextInt(5000));
    }

    private void scheduleZzz() {
        handler.postDelayed(() -> {
            if (!running) return;
            if (sleeping) floatZ();
            scheduleZzz();
        }, 1500);
    }

    // ================================================================ public reactions

    /** Tap on Berry. */
    public void onTap() {
        if (sleeping) {
            PetSounds.sleepy(stage.getContext());
            react(wiggleAnim(5), null);
            floatZ();
            return;
        }
        PetSounds.tap(stage.getContext());
        happyFace(1200);
        switch (rnd.nextInt(3)) {
            case 0: react(hop(46), null); break;
            case 1: react(spinJump(), null); break;
            default: react(wiggleAnim(12), null); break;
        }
        hearts("💗", 4);
    }

    /** A food emoji flies into Berry, who chomps it happily. */
    public void playEat(String foodEmoji) {
        TextView food = particle(foodEmoji, 30);
        float startX = 16 * dp, startY = stage.getHeight() - 60 * dp;
        float endX = centerX() - 18 * dp, endY = body.getY() + body.getHeight() * 0.55f;
        food.setX(startX);
        food.setY(startY);
        food.animate().x(endX).y(endY).rotation(360).scaleX(0.6f).scaleY(0.6f)
                .setDuration(550).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    stage.removeView(food);
                    PetSounds.eat(stage.getContext());
                    happyFace(1400);
                    react(chomp(), null);
                    hearts("💗", 5);
                }).start();
    }

    /** A water drop falls on Berry's head, followed by a happy shake and splash. */
    public void playDrink() {
        TextView drop = particle("💧", 28);
        drop.setX(centerX() - 14 * dp);
        drop.setY(0);
        drop.animate().y(body.getY() + 10 * dp).setDuration(500)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> {
                    stage.removeView(drop);
                    PetSounds.drink(stage.getContext());
                    happyFace(1200);
                    react(wiggleAnim(10), null);
                    burst(new String[]{"💧", "💦", "💧"}, 6, 70);
                }).start();
    }

    /** Playtime: a few bouncy hops with a spin and sparkles. */
    public void playPlay() {
        PetSounds.play(stage.getContext());
        happyFace(2000);
        AnimatorSet set = new AnimatorSet();
        set.playSequentially(hop(30), hop(40), spinJump());
        react(set, null);
        sparkle("⭐", 3);
        handler.postDelayed(() -> sparkle("✨", 3), 500);
    }

    /** "+10 EXP" floats up above Berry. */
    public void expPop(int exp) {
        if (exp <= 0) return;
        handler.postDelayed(() -> PetSounds.exp(stage.getContext()), 250);
        TextView t = particle("+" + exp + " EXP", 15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(ContextCompat.getColor(stage.getContext(), R.color.pink_dark));
        t.setBackgroundResource(R.drawable.bg_bubble);
        int pad = (int) (8 * dp);
        t.setPadding(pad, pad / 2, pad, pad / 2);
        t.setX(centerX() + 20 * dp);
        t.setY(body.getY() + 10 * dp);
        t.setAlpha(0f);
        t.animate().alpha(1f).translationYBy(-50 * dp).setDuration(500)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> t.animate().alpha(0f).translationYBy(-20 * dp).setStartDelay(500)
                        .setDuration(400).withEndAction(() -> stage.removeView(t)).start())
                .start();
    }

    /** Big celebration with confetti. */
    public void levelUp(int newLevel) {
        PetSounds.levelUp(stage.getContext());
        happyFace(2500);
        AnimatorSet set = new AnimatorSet();
        set.playSequentially(hop(60), spinJump(), hop(30));
        react(set, null);
        burst(new String[]{"🎉", "✨", "⭐", "💖", "🎊"}, 16, 150);
        TextView banner = particle("LEVEL UP!  Lv." + newLevel, 20);
        banner.setTypeface(Typeface.DEFAULT_BOLD);
        banner.setTextColor(ContextCompat.getColor(stage.getContext(), R.color.white));
        banner.setBackgroundResource(R.drawable.bg_pill_pink);
        int pad = (int) (12 * dp);
        banner.setPadding(pad, pad / 2, pad, pad / 2);
        banner.post(() -> {
            banner.setX((stage.getWidth() - banner.getWidth()) / 2f);
            banner.setY(stage.getHeight() * 0.35f);
            banner.setScaleX(0.2f);
            banner.setScaleY(0.2f);
            banner.animate().scaleX(1f).scaleY(1f).setDuration(450)
                    .setInterpolator(new OvershootInterpolator(3f))
                    .withEndAction(() -> banner.animate().alpha(0f).setStartDelay(1400).setDuration(500)
                            .withEndAction(() -> stage.removeView(banner)).start())
                    .start();
        });
    }

    // ================================================================ building blocks

    private void react(Animator anim, @Nullable Runnable after) {
        if (current != null) current.cancel();
        busy = true;
        if (idle != null) idle.cancel();
        current = anim;
        anim.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (cancelled) return;
                busy = false;
                body.setRotation(0f);
                if (after != null) after.run();
                if (running) startIdle();
            }
        });
        anim.start();
    }

    private Animator pose(long ms, float sx, float sy, float ty, float rot, TimeInterpolator in) {
        ObjectAnimator o = ObjectAnimator.ofPropertyValuesHolder(body,
                PropertyValuesHolder.ofFloat(View.SCALE_X, sx),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, sy),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, ty),
                PropertyValuesHolder.ofFloat(View.ROTATION, rot));
        o.setDuration(ms);
        o.setInterpolator(in);
        return o;
    }

    /** Squash, leap, land, settle. Height in dp. */
    private Animator hop(float heightDp) {
        float h = -heightDp * dp;
        AnimatorSet s = new AnimatorSet();
        s.playSequentially(
                pose(110, 1.12f, 0.86f, 0, 0, new DecelerateInterpolator()),
                pose(260, 0.94f, 1.08f, h, 0, new DecelerateInterpolator()),
                pose(220, 1f, 1f, 0, 0, new AccelerateInterpolator()),
                pose(90, 1.1f, 0.9f, 0, 0, new DecelerateInterpolator()),
                pose(180, 1f, 1f, 0, 0, new OvershootInterpolator(3f)));
        if (shadow != null) {
            ObjectAnimator sh = ObjectAnimator.ofFloat(shadow, View.SCALE_X, 1f, 0.6f, 1f);
            sh.setDuration(590);
            sh.setStartDelay(110);
            AnimatorSet both = new AnimatorSet();
            both.playTogether(s, sh);
            return both;
        }
        return s;
    }

    private Animator spinJump() {
        AnimatorSet s = new AnimatorSet();
        s.playSequentially(
                pose(110, 1.12f, 0.86f, 0, 0, new DecelerateInterpolator()),
                pose(360, 0.95f, 1.05f, -55 * dp, 360, new DecelerateInterpolator()),
                pose(240, 1f, 1f, 0, 360, new AccelerateInterpolator()),
                pose(180, 1f, 1f, 0, 360, new OvershootInterpolator(3f)));
        return s;
    }

    private Animator wiggleAnim(float degrees) {
        ObjectAnimator w = ObjectAnimator.ofFloat(body, View.ROTATION,
                0, -degrees, degrees, -degrees * 0.7f, degrees * 0.7f, -degrees * 0.3f, 0);
        w.setDuration(650);
        return w;
    }

    private Animator chomp() {
        AnimatorSet s = new AnimatorSet();
        s.playSequentially(
                pose(110, 1.1f, 0.88f, 0, 0, new DecelerateInterpolator()),
                pose(110, 0.97f, 1.04f, 0, 0, new DecelerateInterpolator()),
                pose(110, 1.1f, 0.88f, 0, 0, new DecelerateInterpolator()),
                pose(110, 0.97f, 1.04f, 0, 0, new DecelerateInterpolator()),
                pose(200, 1f, 1f, 0, 0, new OvershootInterpolator(2f)));
        return s;
    }

    private void happyFace(long ms) {
        face.setImageResource(sleeping ? R.drawable.mascot_berry_sleep : R.drawable.mascot_berry_happy);
        handler.postDelayed(() -> face.setImageResource(restingFace()), ms);
    }

    private void resetPose() {
        body.setScaleX(1f); body.setScaleY(1f);
        body.setTranslationY(0f); body.setRotation(0f);
        if (shadow != null) { shadow.setScaleX(1f); shadow.setAlpha(1f); }
        face.setImageResource(restingFace());
        busy = false;
    }

    // ================================================================ particles

    private float centerX() { return body.getX() + body.getWidth() / 2f; }

    private TextView particle(String text, float sizeSp) {
        TextView t = new TextView(stage.getContext());
        t.setText(text);
        t.setTextSize(sizeSp);
        t.setElevation(10 * dp);
        stage.addView(t, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        return t;
    }

    /** Hearts drift upward and fade. */
    private void hearts(String emoji, int count) {
        for (int i = 0; i < count; i++) {
            TextView t = particle(emoji, 16 + rnd.nextInt(10));
            t.setX(centerX() + (rnd.nextInt(140) - 80) * dp);
            t.setY(body.getY() + body.getHeight() * 0.45f);
            t.setAlpha(0f);
            t.animate().alpha(1f).translationYBy(-(110 + rnd.nextInt(60)) * dp)
                    .translationXBy((rnd.nextInt(40) - 20) * dp)
                    .scaleX(1.3f).scaleY(1.3f)
                    .setStartDelay(i * 110L).setDuration(1100 + rnd.nextInt(400))
                    .setInterpolator(new DecelerateInterpolator())
                    .withEndAction(() -> t.animate().alpha(0f).setStartDelay(0).setDuration(250)
                            .withEndAction(() -> stage.removeView(t)).start())
                    .start();
        }
    }

    private void sparkle(String emoji, int count) {
        for (int i = 0; i < count; i++) {
            TextView t = particle(emoji, 14 + rnd.nextInt(8));
            t.setX(centerX() + (rnd.nextInt(180) - 100) * dp);
            t.setY(body.getY() + rnd.nextInt(Math.max(1, body.getHeight())));
            t.setAlpha(0f);
            t.setScaleX(0.3f);
            t.setScaleY(0.3f);
            t.animate().alpha(1f).scaleX(1.2f).scaleY(1.2f).rotation(90)
                    .setStartDelay(i * 150L).setDuration(400)
                    .withEndAction(() -> t.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f)
                            .setStartDelay(150).setDuration(350)
                            .withEndAction(() -> stage.removeView(t)).start())
                    .start();
        }
    }

    /** Particles explode outward in all directions (confetti, splashes). */
    private void burst(String[] emojis, int count, float radiusDp) {
        float cx = centerX() - 10 * dp, cy = body.getY() + body.getHeight() * 0.4f;
        for (int i = 0; i < count; i++) {
            TextView t = particle(emojis[i % emojis.length], 14 + rnd.nextInt(10));
            t.setX(cx);
            t.setY(cy);
            double angle = (Math.PI * 2 * i / count) + rnd.nextFloat() * 0.4;
            float dist = (radiusDp * 0.6f + rnd.nextInt((int) (radiusDp * 0.6f) + 1)) * dp;
            t.animate().translationXBy((float) Math.cos(angle) * dist)
                    .translationYBy((float) Math.sin(angle) * dist - 30 * dp)
                    .rotation(rnd.nextInt(720) - 360)
                    .alpha(0f).setDuration(1000 + rnd.nextInt(500))
                    .setInterpolator(new DecelerateInterpolator())
                    .withEndAction(() -> stage.removeView(t)).start();
        }
    }

    private void floatZ() {
        TextView z = particle(rnd.nextBoolean() ? "z" : "Z", 16 + rnd.nextInt(10));
        z.setTypeface(Typeface.DEFAULT_BOLD);
        z.setTextColor(ContextCompat.getColor(stage.getContext(), R.color.purple));
        z.setX(centerX() + 40 * dp);
        z.setY(body.getY() + 30 * dp);
        z.setAlpha(0f);
        z.animate().alpha(1f).translationYBy(-70 * dp).translationXBy(30 * dp).rotation(20)
                .setDuration(1600).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> z.animate().alpha(0f).setDuration(300)
                        .withEndAction(() -> stage.removeView(z)).start())
                .start();
    }
}
