package com.nutripulse.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.nutripulse.app.R;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.views.PetAnimator;
import com.nutripulse.app.data.PetLook;
import com.nutripulse.app.views.AccessoryEditor;

/** Berry's room: status, EXP and daily care activities. */
public class PetActivity extends BaseAuthActivity {

    private ImageView mascot, crown;
    private TextView name, stage, level, exp, state, bubble, tip;
    private ProgressBar expBar;
    private Pet pet;
    private PetAnimator petAnim;
    private AccessoryEditor editor;
    private boolean keepBubble = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_pet);
        BottomNav.setup(this, BottomNav.NONE);

        mascot = findViewById(R.id.pet_mascot);
        crown = findViewById(R.id.pet_crown);
        name = findViewById(R.id.pet_name);
        stage = findViewById(R.id.pet_stage);
        level = findViewById(R.id.pet_level);
        exp = findViewById(R.id.pet_exp);
        expBar = findViewById(R.id.pet_exp_bar);
        state = findViewById(R.id.pet_state);
        bubble = findViewById(R.id.pet_bubble);
        tip = findViewById(R.id.pet_tip);

        findViewById(R.id.pet_back).setOnClickListener(v -> finish());
        findViewById(R.id.pet_action).setOnClickListener(v -> startActivity(new android.content.Intent(this, ShopActivity.class)));
        findViewById(R.id.pet_game).setOnClickListener(v -> startActivity(new android.content.Intent(this, GameActivity.class)));
        findViewById(R.id.pet_shop).setOnClickListener(v -> startActivity(new android.content.Intent(this, ShopActivity.class)));
        findViewById(R.id.pet_rename).setOnClickListener(v -> rename());
        name.setOnClickListener(v -> rename());
        petAnim = new PetAnimator(findViewById(R.id.pet_stage_area), findViewById(R.id.pet_pet_body),
                mascot, findViewById(R.id.pet_shadow));
        editor = new AccessoryEditor(findViewById(R.id.pet_stage_area), findViewById(R.id.pet_hat),
                findViewById(R.id.pet_face), session.getUserId(), new AccessoryEditor.Callbacks() {
                    @Override public void onEditStart() {
                        petAnim.stop();
                        findViewById(R.id.pet_adjust).setVisibility(View.GONE);
                    }
                    @Override public void onEditEnd() {
                        petAnim.start();
                        load();
                    }
                });
        findViewById(R.id.pet_adjust).setOnClickListener(v -> {
            if (pet != null) editor.start(pet.hat, pet.face);
        });
        mascot.setOnClickListener(v -> {
            petAnim.onTap();
            bubble.setText(petAnim.isSleeping() ? "Zzz… five more minutes…" : "Hehe, that tickles! 💗");
        });
        bubble.setOnClickListener(v -> startActivity(new android.content.Intent(this, ChatActivity.class)));
        findViewById(R.id.care_feed).setOnClickListener(v -> care("feed", "Yum! Thank you for the healthy food! 🍎"));
        findViewById(R.id.care_water).setOnClickListener(v -> care("water", "Ahh, refreshing! 💧"));
        findViewById(R.id.care_play).setOnClickListener(v -> care("play", "Wheee! That was fun! 🎮"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (noSession()) return;
        petAnim.start();
        load();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (editor != null && editor.isEditing()) editor.finish(true);
        if (petAnim != null) petAnim.stop();
    }

    private void load() {
        repo.loadSnapshot(s -> {
            if (s == null) { redirectToLogin(); return; }
            pet = s.pet;
            name.setText(pet.name);
            stage.setText(pet.getStageName());
            level.setText("Lv." + pet.level);
            expBar.setProgress(pet.exp);
            exp.setText(pet.exp + " / " + Pet.EXP_PER_LEVEL + " EXP");
            if (!editor.isEditing()) {   // don't undo the user's adjustments mid-edit
                PetLook.apply(pet, findViewById(R.id.pet_room),
                        findViewById(R.id.pet_hat), findViewById(R.id.pet_face), crown);
            }
            ((TextView) findViewById(R.id.pet_coins)).setText(String.valueOf(pet.coins));
            findViewById(R.id.pet_adjust).setVisibility(
                    (pet.hat != 0 || pet.face != 0) && !editor.isEditing() ? View.VISIBLE : View.GONE);
            boolean sleepy = DateUtils.isSleepyTime();
            petAnim.setSleeping(sleepy);
            state.setText(sleepy ? "🌙 Sleeping…" : "☀️ Awake & " + s.stats.mood.replace("!", ""));
            if (!keepBubble) bubble.setText(sleepy ? "Zzz…" : s.stats.speech);
            keepBubble = false;
            tip.setText("Tip: " + s.stats.tip);

            setBar(R.id.pet_mood_bar, R.id.pet_mood_label, s.stats.moodScore, s.stats.mood);
            setBar(R.id.pet_energy_bar, R.id.pet_energy_label, s.stats.energy, describe(s.stats.energy));
            setBar(R.id.pet_gut_bar, R.id.pet_gut_label, s.stats.gutHealth, describe(s.stats.gutHealth));
            setBar(R.id.pet_water_bar, R.id.pet_water_label, s.stats.hydration, describe(s.stats.hydration));

            setLeft(R.id.care_feed_left, "feed", 10);
            setLeft(R.id.care_water_left, "water", 5);
            setLeft(R.id.care_play_left, "play", 5);
        });
    }

    private void setBar(int barId, int labelId, int value, String label) {
        ((ProgressBar) findViewById(barId)).setProgress(value);
        ((TextView) findViewById(labelId)).setText(label);
    }

    private void setLeft(int id, String action, int expValue) {
        int left = repo.careRemaining(action);
        ((TextView) findViewById(id)).setText(left > 0 ? "+" + expValue + " EXP · " + left + " left" : "Done today");
    }

    private static String describe(int v) {
        if (v >= 85) return "Excellent";
        if (v >= 65) return "Good";
        if (v >= 40) return "Okay";
        return "Low";
    }

    private void care(String action, String line) {
        repo.careAction(action, r -> {
            if (r != null && r.ok) {
                switch (action) {
                    case "feed": petAnim.playEat("🍎"); break;
                    case "water": petAnim.playDrink(); break;
                    default: petAnim.playPlay(); break;
                }
                bubble.setText(line);
                keepBubble = true;
                petAnim.expPop(r.expGained);
                if (r.leveledUp) petAnim.levelUp(r.newLevel);
            }
            Feedback.show(this, r, null);
            load();
        });
    }

    private void rename() {
        if (pet == null) return;
        Dialogs.text(this, "Rename your pet", "Pet name", pet.name, 16, n ->
                repo.renamePet(n, p -> load()));
    }
}
