package com.nutripulse.app.utils;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import com.nutripulse.app.data.WeeklyReport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Draws the wellness report into an A4 PDF with Android's built-in PdfDocument
 * (no extra libraries). Text is kept plain (no emoji) so it prints cleanly everywhere.
 */
public final class PdfExporter {
    private static final int PAGE_W = 595, PAGE_H = 842, M = 40;   // A4 in points
    private static final int PINK = Color.parseColor("#FF4F8B"), PINK_LIGHT = Color.parseColor("#FFE1EC"),
            DARK = Color.parseColor("#3A2238"), MUTED = Color.parseColor("#8A7489"), PURPLE = Color.parseColor("#A57CF0");

    private PdfDocument doc;
    private PdfDocument.Page page;
    private Canvas c;
    private int pageNo = 0;
    private float y;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    private PdfExporter() {}

    /** Writes the PDF to the app's cache folder (shareable through FileProvider). */
    public static File create(Context context, WeeklyReport r, String fileName) throws Exception {
        File dir = new File(context.getCacheDir(), "reports");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create folder");
        File out = new File(dir, fileName);
        new PdfExporter().draw(r, out);
        return out;
    }

    /** Copies the PDF into the phone's Downloads folder (Android 10+). Returns null if not supported. */
    public static Uri saveToDownloads(Context context, File pdf) throws Exception {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null;
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, pdf.getName());
        v.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
        v.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IllegalStateException("Could not create file in Downloads");
        try (InputStream in = new FileInputStream(pdf);
             OutputStream os = context.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new IllegalStateException("Could not open Downloads file");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        v.clear();
        v.put(MediaStore.Downloads.IS_PENDING, 0);
        context.getContentResolver().update(uri, v, null, null);
        return uri;
    }

    // ------------------------------------------------------------------ drawing

    private void draw(WeeklyReport r, File out) throws Exception {
        doc = new PdfDocument();
        newPage();

        // Header band
        p.setColor(PINK);
        c.drawRoundRect(new RectF(M, M, PAGE_W - M, M + 86), 16, 16, p);
        text("NutriPulse", M + 18, M + 34, 24, Color.WHITE, true);
        text("Wellness Report", M + 18, M + 58, 14, Color.WHITE, false);
        text("Eat Smart. Live Healthy.", M + 18, M + 76, 10, Color.WHITE, false);
        textRight(r.userName, PAGE_W - M - 18, M + 34, 14, Color.WHITE, true);
        textRight(r.rangeLabel, PAGE_W - M - 18, M + 56, 11, Color.WHITE, false);
        y = M + 112;

        // Summary boxes (3 x 2)
        String[][] boxes = {
                {"Avg calories / day", r.avgCalories + " kcal", "Goal " + r.calorieGoal},
                {"Days with food logged", r.daysLogged + " / " + r.days.size(), "Streak " + r.streak + " day(s)"},
                {"Water goal reached", r.waterGoalDays + " day(s)", String.format(Locale.US, "Avg %.1f cups", r.avgWater)},
                {"Total steps", String.format(Locale.US, "%,d", r.totalSteps), String.format(Locale.US, "Avg %,d / day", r.avgSteps)},
                {"Average mood", Float.isNaN(r.avgMood) ? "-" : String.format(Locale.US, "%.1f / 5", r.avgMood), "1 = very low, 5 = great"},
                {"Weight change", Float.isNaN(r.weightChange) ? "-" : String.format(Locale.US, "%+.1f kg", r.weightChange),
                        Float.isNaN(r.latestWeight) ? "No weight logged" : String.format(Locale.US, "Latest %.1f kg", r.latestWeight)},
        };
        float bw = (PAGE_W - 2 * M - 20) / 3f, bh = 64;
        for (int i = 0; i < boxes.length; i++) {
            float bx = M + (i % 3) * (bw + 10), by = y + (i / 3) * (bh + 10);
            p.setColor(PINK_LIGHT);
            c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), 10, 10, p);
            text(boxes[i][0], bx + 10, by + 18, 9, MUTED, false);
            text(boxes[i][1], bx + 10, by + 40, 16, DARK, true);
            text(boxes[i][2], bx + 10, by + 56, 8.5f, MUTED, false);
        }
        y += 2 * (bh + 10) + 14;

        // Calories bar chart
        heading("Calories per day");
        drawBars(r, y, 120);
        y += 140;

        heading("Highlights");
        for (String h : r.highlights) paragraph("- " + plain(h), 10.5f, DARK);
        if (r.moodInsight != null) {
            y += 4;
            paragraph("Mood note: " + plain(r.moodInsight), 10.5f, PURPLE);
        }
        y += 6;
        heading("Berry's ideas for next week");
        for (String t : r.tips) paragraph("- " + plain(t), 10.5f, DARK);
        y += 10;

        // Day-by-day table
        heading("Day by day");
        String[] cols = {"Day", "Calories", "Protein", "Water", "Steps", "Weight", "Mood"};
        float[] cx = {M, M + 90, M + 165, M + 235, M + 300, M + 380, M + 450};
        tableRow(cols, cx, true);
        for (WeeklyReport.DayRow d : r.days) {
            String[] row = {d.label, d.logged ? String.valueOf(d.calories) : "-",
                    d.logged ? String.format(Locale.US, "%.0f g", d.protein) : "-",
                    d.water > 0 ? d.water + " cups" : "-",
                    d.steps > 0 ? String.format(Locale.US, "%,d", d.steps) : "-",
                    Float.isNaN(d.weight) ? "-" : String.format(Locale.US, "%.1f kg", d.weight),
                    d.mood > 0 ? d.mood + " / 5" : "-"};
            tableRow(row, cx, false);
        }

        y += 16;
        ensureSpace(40);
        text("Berry Lv." + r.petLevel + "  |  Achievements " + r.achievementsUnlocked + " / " + r.achievementsTotal,
                M, y, 9.5f, PINK, true);
        y += 16;
        paragraph("Generated by NutriPulse. Values are estimates from your own logs and are not medical advice. "
                + "Talk to a doctor or registered dietitian for personal health guidance.", 8.5f, MUTED);

        doc.finishPage(page);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            doc.writeTo(fos);
        } finally {
            doc.close();
        }
    }

    private void newPage() {
        if (page != null) doc.finishPage(page);
        pageNo++;
        page = doc.startPage(new PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create());
        c = page.getCanvas();
        y = M;
        text("Page " + pageNo, PAGE_W - M - 40, PAGE_H - 20, 8, MUTED, false);
    }

    private void ensureSpace(float needed) {
        if (y + needed > PAGE_H - M) newPage();
    }

    private void heading(String s) {
        ensureSpace(40);
        text(s, M, y, 13, PINK, true);
        y += 16;
    }

    private void tableRow(String[] cells, float[] xs, boolean header) {
        ensureSpace(18);
        if (header) {
            p.setColor(PINK_LIGHT);
            c.drawRect(M - 4, y - 11, PAGE_W - M, y + 5, p);
        }
        for (int i = 0; i < cells.length; i++) text(cells[i], xs[i], y, 9.5f, DARK, header);
        y += 16;
    }

    private void drawBars(WeeklyReport r, float top, float height) {
        int n = r.days.size();
        float left = M, right = PAGE_W - M, bottom = top + height - 14;
        float max = r.calorieGoal;
        for (WeeklyReport.DayRow d : r.days) max = Math.max(max, d.calories);
        max *= 1.1f;
        float slot = (right - left) / n, w = Math.min(28, slot * 0.6f);
        int step = n <= 7 ? 1 : (int) Math.ceil(n / 8f);
        for (int i = 0; i < n; i++) {
            WeeklyReport.DayRow d = r.days.get(i);
            float x = left + slot * (i + 0.5f);
            float h = (bottom - top) * d.calories / max;
            if (d.calories > 0) {
                p.setColor(d.calories >= r.calorieGoal * 0.8 && d.calories <= r.calorieGoal * 1.1 ? PINK : Color.parseColor("#FFB3CC"));
                c.drawRoundRect(new RectF(x - w / 2, bottom - h, x + w / 2, bottom), 5, 5, p);
            }
            if (i % step == 0) textCenter(d.label, x, bottom + 12, 8, MUTED);
        }
        float gy = bottom - (bottom - top) * r.calorieGoal / max;
        p.setColor(PURPLE);
        p.setStrokeWidth(1);
        for (float x = left; x < right; x += 8) c.drawLine(x, gy, Math.min(x + 4, right), gy, p);
        text("Goal " + r.calorieGoal + " kcal", right - 80, gy - 4, 8, PURPLE, false);
    }

    /** Word-wraps text across the page width. */
    private void paragraph(String s, float size, int color) {
        p.setTextSize(size);
        p.setTypeface(Typeface.DEFAULT);
        float maxW = PAGE_W - 2 * M;
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(test) > maxW && line.length() > 0) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) lines.add(line.toString());
        for (String l : lines) {
            ensureSpace(size + 6);
            text(l, M, y, size, color, false);
            y += size + 5;
        }
    }

    private void text(String s, float x, float yy, float size, int color, boolean bold) {
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        c.drawText(s, x, yy, p);
    }

    private void textRight(String s, float x, float yy, float size, int color, boolean bold) {
        p.setTextAlign(Paint.Align.RIGHT);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        c.drawText(s, x, yy, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void textCenter(String s, float x, float yy, float size, int color) {
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(Typeface.DEFAULT);
        c.drawText(s, x, yy, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    /** Removes emoji and other symbols the PDF may not render. */
    static String plain(String s) {
        StringBuilder b = new StringBuilder();
        s.codePoints().forEach(cp -> {
            if (cp < 0x2000 || (cp >= 0x2010 && cp <= 0x2027)) b.appendCodePoint(cp);
        });
        return b.toString().replaceAll("\\s{2,}", " ").trim();
    }
}
