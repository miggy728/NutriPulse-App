package com.nutripulse.app.utils;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public final class UiUtils {
    private UiUtils() {}

    public static void toast(Context c, String msg) {
        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
    }

    public static int dp(Context c, float dp) {
        return Math.round(dp * c.getResources().getDisplayMetrics().density);
    }

    public static String text(TextInputLayout layout) {
        return layout.getEditText() == null ? "" : layout.getEditText().getText().toString();
    }

    public static void clearErrors(TextInputLayout... layouts) {
        for (TextInputLayout l : layouts) { l.setError(null); l.setErrorEnabled(false); }
    }

    public static void hideKeyboard(Activity a) {
        View v = a.getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    /** Small bounce used when Berry is tapped or gains EXP. */
    public static void bounce(View v) {
        v.animate().scaleX(1.12f).scaleY(0.9f).setDuration(120).withEndAction(() ->
                v.animate().scaleX(0.95f).scaleY(1.08f).setDuration(120).withEndAction(() ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()).start()).start();
    }
}
