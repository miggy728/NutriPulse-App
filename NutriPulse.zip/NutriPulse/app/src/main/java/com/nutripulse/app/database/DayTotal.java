package com.nutripulse.app.database;

/** Simple projection used for chart queries: one total value per day. */
public class DayTotal {
    public String dateKey;
    public float total;
}
