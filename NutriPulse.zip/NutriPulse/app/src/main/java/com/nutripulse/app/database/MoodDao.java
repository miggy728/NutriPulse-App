package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.nutripulse.app.models.MoodRecord;

import java.util.List;

/** Mood check-ins, always filtered by userId. */
@Dao
public interface MoodDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long save(MoodRecord record);

    @Query("SELECT * FROM mood_records WHERE userId = :userId AND dateKey = :dateKey LIMIT 1")
    MoodRecord forDay(long userId, String dateKey);

    @Query("SELECT * FROM mood_records WHERE userId = :userId AND dateKey >= :fromKey ORDER BY dateKey ASC")
    List<MoodRecord> since(long userId, String fromKey);

    @Query("SELECT dateKey AS dateKey, mood AS total FROM mood_records WHERE userId = :userId AND dateKey >= :fromKey")
    List<DayTotal> dailyMood(long userId, String fromKey);
}
