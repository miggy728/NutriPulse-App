package com.nutripulse.app.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.nutripulse.app.auth.LoginActivity;
import com.nutripulse.app.data.WellnessRepository;
import com.nutripulse.app.utils.SessionManager;

/**
 * Parent of every screen that needs a logged-in user.
 * Without a valid session the user is sent to Login and the screen closes,
 * so protected screens can't be reached by deep links or the back stack.
 */
public abstract class BaseAuthActivity extends AppCompatActivity {

    protected SessionManager session;
    protected WellnessRepository repo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new SessionManager(this);
        if (!session.isLoggedIn()) {
            redirectToLogin();
            return;
        }
        repo = new WellnessRepository(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isFinishing() && !session.isLoggedIn()) redirectToLogin();
    }

    /** True if onCreate already bailed out because there is no session. */
    protected boolean noSession() {
        return repo == null || isFinishing();
    }

    protected void redirectToLogin() {
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
