package com.nutripulse.app.utils;

import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Secure password hashing with PBKDF2-HMAC-SHA256 and a random 16-byte salt per user.
 * Plaintext passwords never touch the database.
 */
public final class PasswordUtils {
    private static final int ITERATIONS = 120_000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_BYTES = 16;

    private PasswordUtils() {}

    public static String newSalt() {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    public static String hash(String password, String saltB64) {
        char[] chars = password.toCharArray();
        try {
            byte[] salt = Base64.decode(saltB64, Base64.NO_WRAP);
            KeySpec spec = new PBEKeySpec(chars, salt, ITERATIONS, KEY_LENGTH_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (Exception e) {
            throw new IllegalStateException("Password hashing failed", e);
        } finally {
            Arrays.fill(chars, '\0');
        }
    }

    /** Constant-time comparison so timing doesn't leak how much of the hash matched. */
    public static boolean verify(String password, String saltB64, String expectedHashB64) {
        String actual = hash(password, saltB64);
        return MessageDigest.isEqual(
                Base64.decode(actual, Base64.NO_WRAP),
                Base64.decode(expectedHashB64, Base64.NO_WRAP));
    }
}
