package com.nutripulse.app.models;

/** One chat bubble. Stored per user in private SharedPreferences (see ChatHistory). */
public class ChatMessage {
    public static final int FROM_BERRY = 0, FROM_USER = 1, TYPING = 2;

    public final int sender;
    public final String text;
    public final long time;

    public ChatMessage(int sender, String text, long time) {
        this.sender = sender;
        this.text = text;
        this.time = time;
    }
}
