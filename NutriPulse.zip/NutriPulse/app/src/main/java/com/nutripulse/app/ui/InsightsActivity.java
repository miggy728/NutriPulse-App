package com.nutripulse.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.R;
import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.data.Challenges;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import java.util.Locale;
import com.nutripulse.app.models.Pet;

import java.util.ArrayList;
import java.util.List;

/** Achievements and pet evolution for the logged-in user. */
public class InsightsActivity extends BaseAuthActivity {

    private final List<Achievement> items = new ArrayList<>();
    private RecyclerView.Adapter<VH> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_insights);
        findViewById(R.id.insights_back).setOnClickListener(v -> finish());

        RecyclerView list = findViewById(R.id.insights_list);
        list.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new RecyclerView.Adapter<VH>() {
            @NonNull @Override
            public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
                return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_achievement, p, false));
            }
            @Override
            public void onBindViewHolder(@NonNull VH h, int i) { h.bind(items.get(i)); }
            @Override
            public int getItemCount() { return items.size(); }
        };
        list.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (noSession()) return;
        loadChallenges();
        repo.getAchievements(list -> {
            if (list == null) return;
            items.clear();
            items.addAll(list);
            adapter.notifyDataSetChanged();
            int unlocked = 0;
            for (Achievement a : list) if (a.unlocked) unlocked++;
            ((TextView) findViewById(R.id.insights_count)).setText(unlocked + "/" + list.size());
            ((TextView) findViewById(R.id.insights_headline)).setText(
                    unlocked == 0 ? "Let's get started!" : "You're doing great!");
            ((TextView) findViewById(R.id.insights_sub)).setText(
                    unlocked == 0 ? "Log a meal to earn your first badge." : unlocked + " achievements unlocked. Keep it up!");
        });
        repo.getPet(pet -> {
            if (pet == null) return;
            int next = pet.nextEvolutionLevel();
            ((TextView) findViewById(R.id.insights_next)).setText(next > 0
                    ? "⭐ Next Evolution: Reach Lv." + next + " (now Lv." + pet.level + ")"
                    : "👑 " + pet.name + " is fully evolved!");
            float[] alpha = {1f, pet.getStage() >= 2 ? 1f : 0.35f, pet.getStage() >= 3 ? 1f : 0.35f};
            int[] ids = {R.id.evo_1, R.id.evo_2, R.id.evo_3};
            for (int i = 0; i < 3; i++) findViewById(ids[i]).setAlpha(alpha[i]);
        });
    }

    private void loadChallenges() {
        repo.getChallenges(list -> {
            LinearLayout box = findViewById(R.id.challenges_list);
            box.removeAllViews();
            if (list == null) return;
            for (Challenges.Status st : list) box.addView(challengeRow(st, box));
        });
    }

    private View challengeRow(Challenges.Status st, LinearLayout parent) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_challenge, parent, false);
        ((TextView) row.findViewById(R.id.ch_emoji)).setText(st.def.emoji);
        ((TextView) row.findViewById(R.id.ch_title)).setText(st.def.title);
        ProgressBar bar = row.findViewById(R.id.ch_bar);
        bar.setMax(st.def.target);
        bar.setProgress(st.progress);
        ((TextView) row.findViewById(R.id.ch_progress)).setText(
                String.format(Locale.US, "%,d / %,d", st.progress, st.def.target));
        TextView claim = row.findViewById(R.id.ch_claim);
        if (st.claimed) {
            claim.setText("✓ Done");
            claim.setBackgroundResource(R.drawable.bg_pill);
            claim.setTextColor(ContextCompat.getColor(this, R.color.green_ok));
        } else if (st.isDone()) {
            claim.setText("Claim +" + Challenges.REWARD_EXP);
            claim.setOnClickListener(v -> repo.claimChallenge(st.def.id, r -> {
                Feedback.show(this, r, "🏁 Challenge complete!");
                loadChallenges();
            }));
        } else {
            claim.setText("+" + Challenges.REWARD_EXP + " EXP");
            claim.setBackgroundResource(R.drawable.bg_pill);
            claim.setTextColor(ContextCompat.getColor(this, R.color.pink_dark));
        }
        return row;
    }

    private class VH extends RecyclerView.ViewHolder {
        final TextView emoji, title, state;
        VH(View v) {
            super(v);
            emoji = v.findViewById(R.id.ach_emoji);
            title = v.findViewById(R.id.ach_title);
            state = v.findViewById(R.id.ach_state);
        }
        void bind(Achievement a) {
            emoji.setText(a.emoji);
            title.setText(a.title);
            state.setText(a.unlocked ? "Unlocked!" : "Locked");
            state.setTextColor(ContextCompat.getColor(InsightsActivity.this,
                    a.unlocked ? R.color.green_ok : R.color.text_muted));
            itemView.setAlpha(a.unlocked ? 1f : 0.5f);
            itemView.setOnClickListener(v -> new NpDialogBuilder(InsightsActivity.this)
                    .setTitle(a.emoji + " " + a.title)
                    .setMessage(a.description + (a.unlocked ? "\n\nUnlocked ✓" : "\n\nNot unlocked yet"))
                    .setPositiveButton("OK", null).show());
        }
    }
}
