package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;

import java.util.List;

/** Daily goals, achievements and dietary preferences, all scoped by userId. */
@Dao
public interface GoalDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertGoals(List<DailyGoal> goals);

    @Update
    void updateGoal(DailyGoal goal);

    @Query("SELECT * FROM daily_goals WHERE userId = :userId AND dateKey >= :fromKey")
    List<DailyGoal> goalsSince(long userId, String fromKey);

    /** Days on which a given goal was completed, newest first (used for the quiz streak). */
    @Query("SELECT dateKey FROM daily_goals WHERE userId = :userId AND goalKey = :goalKey AND completed = 1 ORDER BY dateKey DESC")
    List<String> completedDays(long userId, String goalKey);

    @Query("SELECT * FROM daily_goals WHERE userId = :userId AND dateKey = :dateKey ORDER BY id")
    List<DailyGoal> goalsForDay(long userId, String dateKey);

    @Query("SELECT * FROM daily_goals WHERE userId = :userId AND dateKey = :dateKey AND goalKey = :goalKey LIMIT 1")
    DailyGoal goal(long userId, String dateKey, String goalKey);

    @Query("UPDATE daily_goals SET title = :title WHERE userId = :userId AND dateKey = :dateKey AND goalKey = :goalKey")
    void renameGoal(long userId, String dateKey, String goalKey, String title);

    // Achievements
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertAchievements(List<Achievement> list);

    @Update
    void updateAchievement(Achievement achievement);

    @Query("SELECT * FROM achievements WHERE userId = :userId ORDER BY unlocked DESC, id ASC")
    List<Achievement> achievements(long userId);

    @Query("SELECT * FROM achievements WHERE userId = :userId AND achKey = :key LIMIT 1")
    Achievement achievement(long userId, String key);

    // Dietary preferences
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void savePreference(DietaryPreference preference);

    @Query("SELECT * FROM dietary_preferences WHERE userId = :userId LIMIT 1")
    DietaryPreference preference(long userId);
}
