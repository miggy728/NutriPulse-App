package com.nutripulse.app.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Small offline food database (approximate values per serving). */
public final class FoodCatalog {
    private FoodCatalog() {}

    private static final List<FoodItem> ALL = Arrays.asList(
            // Meals
            new FoodItem("Chicken Breast", "🍗", "Meal", "100 g", 165, 31f, 0f, 3.6f, true, 0),
            new FoodItem("Boiled Egg", "🥚", "Meal", "1 large", 78, 6.3f, 0.6f, 5.3f, true, 0),
            new FoodItem("Steamed Rice", "🍚", "Meal", "1 cup", 205, 4.3f, 45f, 0.4f, true, 0),
            new FoodItem("Brown Rice", "🍚", "Meal", "1 cup", 216, 5f, 45f, 1.8f, true, 0),
            new FoodItem("Oatmeal Bowl", "🥣", "Meal", "1 bowl", 350, 12f, 58f, 7f, true, 0),
            new FoodItem("Grilled Chicken Salad", "🥗", "Meal", "1 bowl", 450, 38f, 20f, 22f, true, 0),
            new FoodItem("Salmon with Veggies", "🐟", "Meal", "1 plate", 520, 40f, 18f, 30f, true, 0),
            new FoodItem("Tinola (Chicken Soup)", "🍲", "Meal", "1 bowl", 290, 28f, 10f, 14f, true, 0),
            new FoodItem("Pork Adobo", "🍖", "Meal", "1 serving", 450, 28f, 6f, 34f, false, 0),
            new FoodItem("Sinigang na Hipon", "🍤", "Meal", "1 bowl", 230, 24f, 14f, 8f, true, 0),
            new FoodItem("Pancit Canton", "🍜", "Meal", "1 plate", 420, 14f, 60f, 14f, false, 0),
            new FoodItem("Tofu Stir-fry", "🥢", "Meal", "1 plate", 300, 20f, 16f, 17f, true, 0),
            new FoodItem("Cheeseburger", "🍔", "Meal", "1 burger", 540, 28f, 40f, 30f, false, 0),
            // Filipino favorites (approximate values per typical serving)
            new FoodItem("Sinangag (Garlic Rice)", "🍚", "Meal", "1 cup", 270, 5f, 45f, 7f, false, 0),
            new FoodItem("Tapsilog", "🍳", "Meal", "1 plate", 650, 35f, 55f, 30f, false, 0),
            new FoodItem("Longsilog", "🌭", "Meal", "1 plate", 700, 25f, 60f, 38f, false, 0),
            new FoodItem("Pork Sisig", "🍳", "Meal", "1 serving", 480, 25f, 6f, 40f, false, 0),
            new FoodItem("Lugaw", "🥣", "Meal", "1 bowl", 180, 4f, 38f, 1f, true, 0),
            new FoodItem("Arroz Caldo", "🍲", "Meal", "1 bowl", 320, 18f, 42f, 8f, true, 0),
            new FoodItem("Champorado", "🍫", "Meal", "1 bowl", 300, 6f, 58f, 5f, false, 0),
            new FoodItem("Daing na Bangus", "🐟", "Meal", "1 piece", 300, 30f, 0f, 19f, true, 0),
            new FoodItem("Inihaw na Isda", "🐟", "Meal", "1 fish", 220, 38f, 0f, 7f, true, 0),
            new FoodItem("Pinakbet", "🥬", "Meal", "1 cup", 160, 6f, 14f, 9f, true, 0),
            new FoodItem("Ginisang Monggo", "🫘", "Meal", "1 bowl", 250, 14f, 30f, 8f, true, 0),
            new FoodItem("Chopsuey", "🥦", "Meal", "1 cup", 180, 10f, 14f, 9f, true, 0),
            new FoodItem("Tortang Talong", "🍆", "Meal", "1 piece", 200, 9f, 8f, 15f, true, 0),
            new FoodItem("Lumpiang Shanghai", "🥟", "Meal", "5 pieces", 320, 13f, 22f, 20f, false, 0),
            new FoodItem("Kare-Kare", "🥜", "Meal", "1 serving", 520, 28f, 15f, 39f, false, 0),
            new FoodItem("Bulalo", "🍖", "Meal", "1 bowl", 450, 35f, 10f, 30f, false, 0),
            new FoodItem("Fried Chicken", "🍗", "Meal", "1 piece", 320, 25f, 10f, 20f, false, 0),
            new FoodItem("Chicken Inasal", "🍗", "Meal", "1 piece", 300, 32f, 3f, 17f, true, 0),
            new FoodItem("Pancit Bihon", "🍜", "Meal", "1 plate", 350, 15f, 50f, 10f, true, 0),
            new FoodItem("Ginataang Gulay", "🥥", "Meal", "1 cup", 220, 4f, 18f, 15f, true, 0),
            // Snacks
            new FoodItem("Apple", "🍎", "Snack", "1 medium", 95, 0.5f, 25f, 0.3f, true, 0),
            new FoodItem("Banana", "🍌", "Snack", "1 medium", 105, 1.3f, 27f, 0.4f, true, 0),
            new FoodItem("Greek Yogurt", "🥛", "Snack", "1 cup", 150, 20f, 8f, 4f, true, 0),
            new FoodItem("Mixed Nuts", "🥜", "Snack", "30 g", 175, 5f, 6f, 15f, true, 0),
            new FoodItem("Mango", "🥭", "Snack", "1 cup", 99, 1.4f, 25f, 0.6f, true, 0),
            new FoodItem("Carrot Sticks", "🥕", "Snack", "1 cup", 50, 1.1f, 12f, 0.3f, true, 0),
            new FoodItem("Potato Chips", "🍟", "Snack", "1 small bag", 160, 2f, 15f, 10f, false, 0),
            new FoodItem("Chocolate Bar", "🍫", "Snack", "1 bar", 230, 3f, 25f, 13f, false, 0),
            new FoodItem("Pandesal", "🥖", "Snack", "2 pieces", 240, 7f, 44f, 4f, true, 0),
            new FoodItem("Ensaymada", "🥐", "Snack", "1 piece", 330, 6f, 42f, 15f, false, 0),
            new FoodItem("Turon", "🍌", "Snack", "1 piece", 210, 2f, 38f, 7f, false, 0),
            new FoodItem("Banana Cue", "🍢", "Snack", "1 stick", 230, 1.5f, 48f, 5f, false, 0),
            new FoodItem("Nilagang Saging (Saba)", "🍌", "Snack", "1 piece", 110, 1f, 29f, 0.3f, true, 0),
            new FoodItem("Kamote (Boiled)", "🍠", "Snack", "1 medium", 115, 2f, 27f, 0.1f, true, 0),
            new FoodItem("Puto", "🧁", "Snack", "2 pieces", 160, 3f, 34f, 1.5f, true, 0),
            new FoodItem("Bibingka", "🥮", "Snack", "1 piece", 290, 6f, 45f, 9f, false, 0),
            new FoodItem("Halo-Halo", "🍧", "Snack", "1 glass", 400, 7f, 75f, 9f, false, 0),
            new FoodItem("Taho", "🍮", "Snack", "1 cup", 180, 8f, 32f, 2.5f, true, 0),
            new FoodItem("Fishball", "🍡", "Snack", "10 pieces", 180, 7f, 22f, 7f, false, 0),
            // Drinks
            new FoodItem("Water", "💧", "Drink", "1 cup", 0, 0f, 0f, 0f, true, 1),
            new FoodItem("Fresh Buko Juice", "🥥", "Drink", "1 cup", 46, 1.7f, 9f, 0.5f, true, 1),
            new FoodItem("Low-fat Milk", "🥛", "Drink", "1 cup", 102, 8f, 12f, 2.4f, true, 0),
            new FoodItem("Green Tea", "🍵", "Drink", "1 cup", 2, 0f, 0f, 0f, true, 1),
            new FoodItem("Orange Juice", "🧃", "Drink", "1 cup", 112, 1.7f, 26f, 0.5f, true, 0),
            new FoodItem("Milk Tea", "🧋", "Drink", "1 cup", 300, 3f, 50f, 9f, false, 0),
            new FoodItem("Calamansi Juice", "🍋", "Drink", "1 cup", 60, 0.2f, 15f, 0f, true, 1),
            new FoodItem("Salabat (Ginger Tea)", "🫖", "Drink", "1 cup", 30, 0f, 8f, 0f, true, 1),
            new FoodItem("Sago't Gulaman", "🧋", "Drink", "1 cup", 160, 0f, 40f, 0f, false, 0),
            new FoodItem("3-in-1 Coffee", "☕", "Drink", "1 sachet", 110, 1f, 19f, 3.5f, false, 0),
            new FoodItem("Black Coffee", "☕", "Drink", "1 cup", 2, 0.3f, 0f, 0f, true, 0),
                        new FoodItem("Soda", "🥤", "Drink", "1 can", 140, 0f, 39f, 0f, false, 0)
    );

    public static List<FoodItem> byCategory(String category, String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<FoodItem> out = new ArrayList<>();
        for (FoodItem f : ALL) {
            boolean catOk = category == null || f.category.equals(category);
            boolean qOk = q.isEmpty() || f.name.toLowerCase(Locale.ROOT).contains(q);
            if (catOk && qOk) out.add(f);
        }
        return out;
    }

    public static FoodItem find(String name) {
        for (FoodItem f : ALL) if (f.name.equalsIgnoreCase(name)) return f;
        return null;
    }
}
