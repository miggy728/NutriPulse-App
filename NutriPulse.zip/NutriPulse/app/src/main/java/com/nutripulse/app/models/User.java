package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * A registered NutriPulse account.
 * Passwords are NEVER stored: only a PBKDF2 hash and its random salt.
 */
@Entity(tableName = "users",
        indices = {@Index(value = "email", unique = true),
                   @Index(value = "username", unique = true)})
public class User {
    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull public String fullName = "";
    @NonNull public String username = "";
    @NonNull public String email = "";

    /** Base64 PBKDF2-HMAC-SHA256 hash (authentication reference). */
    @NonNull public String passwordHash = "";
    /** Base64 random salt used for this user's hash. */
    @NonNull public String passwordSalt = "";

    public long registrationDate;
    public String profilePictureUri;

    public int calorieGoal = 2000;   // kcal per day
    public int hydrationGoal = 8;    // cups per day
    public float weightGoal = 0f;    // kg, 0 = not set
    public int stepGoal = 7000;      // steps per day
    /** Height in cm for BMI (0 = not set). Added in database v5. */
    @ColumnInfo(defaultValue = "0") public float heightCm = 0f;

    public String getFirstName() {
        String trimmed = fullName.trim();
        int space = trimmed.indexOf(' ');
        return space > 0 ? trimmed.substring(0, space) : trimmed;
    }
}
