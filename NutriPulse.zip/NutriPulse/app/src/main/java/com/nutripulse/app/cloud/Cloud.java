package com.nutripulse.app.cloud;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

/**
 * Tells the rest of the app whether Firebase is set up.
 * Without app/google-services.json, Firebase never starts and every cloud feature
 * quietly falls back to the offline (Room) version.
 */
public final class Cloud {
    private Cloud() {}

    public static boolean isReady(Context c) {
        try {
            return !FirebaseApp.getApps(c.getApplicationContext()).isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    public static FirebaseAuth auth() { return FirebaseAuth.getInstance(); }

    public static FirebaseFirestore db() { return FirebaseFirestore.getInstance(); }

    /** The signed-in Firebase user, or null (also null when Firebase isn't set up). */
    public static FirebaseUser user(Context c) {
        return isReady(c) ? auth().getCurrentUser() : null;
    }
}
