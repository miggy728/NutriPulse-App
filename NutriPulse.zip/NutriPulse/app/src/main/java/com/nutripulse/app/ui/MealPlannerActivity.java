package com.nutripulse.app.ui;

import android.app.DatePickerDialog;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.view.inputmethod.EditorInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.data.FoodCatalog;
import com.nutripulse.app.data.FoodItem;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.UiUtils;
import androidx.core.content.ContextCompat;
import java.util.Arrays;
import com.nutripulse.app.views.ProgressRingView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Weekly meal plan + nutrition summary for the selected day (the "Diary" tab). */
public class MealPlannerActivity extends BaseAuthActivity {

    private Calendar selectedDay = Calendar.getInstance();
    private LinearLayout daysRow, plansBox;
    private TextView title, kcal, goal, protein, carbs, fat;
    private ProgressRingView ring;
    private LinearLayout notesList;
    private EditText notesInput;
    private TextView notesEmpty, notesCount, notesClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_meal_planner);
        BottomNav.setup(this, BottomNav.DIARY);

        daysRow = findViewById(R.id.planner_days);
        plansBox = findViewById(R.id.planner_plans);
        title = findViewById(R.id.planner_title);
        kcal = findViewById(R.id.planner_kcal);
        goal = findViewById(R.id.planner_goal);
        protein = findViewById(R.id.planner_protein);
        carbs = findViewById(R.id.planner_carbs);
        fat = findViewById(R.id.planner_fat);
        ring = findViewById(R.id.planner_ring);

        findViewById(R.id.planner_back).setOnClickListener(v -> finish());
        findViewById(R.id.planner_action).setOnClickListener(v -> pickDate());
        findViewById(R.id.planner_details).setOnClickListener(v -> showDetails());
        findViewById(R.id.planner_copy).setOnClickListener(v -> showCopyMenu());

        notesList = findViewById(R.id.notes_list);
        notesInput = findViewById(R.id.notes_input);
        notesEmpty = findViewById(R.id.notes_empty);
        notesCount = findViewById(R.id.notes_count);
        notesClear = findViewById(R.id.notes_clear);
        findViewById(R.id.notes_add).setOnClickListener(v -> addNotes());
        notesInput.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { addNotes(); return true; }
            return false;
        });
        notesClear.setOnClickListener(v -> repo.clearDoneNotes(selectedKey(), ok -> loadNotes()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!noSession()) refresh();
    }

    private void refresh() {
        buildWeek();
        loadPlans();
        loadNutrition();
        loadNotes();
    }

    // ------------------------------------------------------------ My Meal Notes

    private void addNotes() {
        String raw = notesInput.getText().toString().trim();
        if (raw.isEmpty()) {
            notesInput.setError("Write something first ✏️");
            return;
        }
        List<String> lines = new ArrayList<>(Arrays.asList(raw.split("\\r?\\n")));
        notesInput.setText("");
        repo.addNotes(selectedKey(), lines, ok -> loadNotes());
    }

    private void loadNotes() {
        repo.getNotes(selectedKey(), notes -> {
            notesList.removeAllViews();
            if (notes == null) return;
            int done = 0;
            for (MealNote n : notes) {
                if (n.done) done++;
                notesList.addView(noteRow(n));
            }
            notesEmpty.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
            notesCount.setText(notes.isEmpty() ? "" : done + "/" + notes.size());
            notesClear.setVisibility(done > 0 ? View.VISIBLE : View.GONE);
        });
    }

    private View noteRow(MealNote n) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_note, notesList, false);
        CheckBox check = row.findViewById(R.id.note_check);
        TextView text = row.findViewById(R.id.note_text);
        text.setText(n.text);
        styleNote(text, n.done);
        check.setChecked(n.done);
        check.setOnCheckedChangeListener((b, checked) -> {
            styleNote(text, checked);
            repo.setNoteDone(n.id, checked, ok -> loadNotes());
        });
        text.setOnClickListener(v -> Dialogs.text(this, "Edit note", "Note", n.text, 120,
                newText -> repo.editNote(n.id, newText, ok -> loadNotes())));
        row.findViewById(R.id.note_delete).setOnClickListener(v -> {
            row.animate().alpha(0f).translationX(UiUtils.dp(this, 40)).setDuration(180)
                    .withEndAction(() -> repo.deleteNote(n.id, ok -> loadNotes())).start();
        });
        return row;
    }

    private void styleNote(TextView t, boolean done) {
        if (done) {
            t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            t.setTextColor(ContextCompat.getColor(this, R.color.text_muted));
        } else {
            t.setPaintFlags(t.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            t.setTextColor(ContextCompat.getColor(this, R.color.text_dark));
        }
    }

    private String selectedKey() { return DateUtils.keyOf(selectedDay); }

    private void buildWeek() {
        daysRow.removeAllViews();
        Calendar c = (Calendar) selectedDay.clone();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        String sel = selectedKey();
        for (int i = 0; i < 7; i++) {
            final Calendar day = (Calendar) c.clone();
            View v = LayoutInflater.from(this).inflate(R.layout.item_day, daysRow, false);
            ((TextView) v.findViewById(R.id.day_name)).setText(DateUtils.format("EEE", day));
            ((TextView) v.findViewById(R.id.day_num)).setText(DateUtils.format("d", day));
            boolean isSel = DateUtils.keyOf(day).equals(sel);
            v.setSelected(isSel);
            v.findViewById(R.id.day_name).setSelected(isSel);
            v.findViewById(R.id.day_num).setSelected(isSel);
            v.setOnClickListener(x -> { selectedDay = day; refresh(); });
            daysRow.addView(v);
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
        boolean today = selectedKey().equals(DateUtils.todayKey());
        title.setText(today ? "Today's Plan" : DateUtils.format("EEEE", selectedDay) + "'s Plan");
    }

    private void loadPlans() {
        repo.getPlans(selectedKey(), plans -> {
            plansBox.removeAllViews();
            if (plans == null) return;
            for (MealPlan p : plans) plansBox.addView(planRow(p));
        });
    }

    private View planRow(MealPlan p) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_plan, plansBox, false);
        ((TextView) row.findViewById(R.id.plan_emoji)).setText(p.emoji == null ? "🍽️" : p.emoji);
        ((TextView) row.findViewById(R.id.plan_slot)).setText(p.slot);
        ((TextView) row.findViewById(R.id.plan_name)).setText(p.name);
        ((TextView) row.findViewById(R.id.plan_kcal)).setText(p.calories + " kcal");
        CheckBox check = row.findViewById(R.id.plan_check);
        check.setChecked(p.completed);
        check.setOnCheckedChangeListener((b, checked) ->
                repo.setPlanCompleted(p.id, checked, r -> {
                    if (checked) Feedback.show(this, r, p.slot + " done! 💗");
                    loadNutrition();
                }));
        row.setOnClickListener(v -> editPlan(p));
        return row;
    }

    private void editPlan(MealPlan p) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_plan, null);
        AutoCompleteTextView name = view.findViewById(R.id.plan_edit_name);
        TextInputLayout kcalLayout = view.findViewById(R.id.plan_edit_kcal_layout);
        TextView kcalInput = view.findViewById(R.id.plan_edit_kcal);
        List<String> names = new ArrayList<>();
        for (FoodItem f : FoodCatalog.byCategory(null, null)) names.add(f.name);
        name.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, names));
        name.setText(p.name);
        kcalInput.setText(String.valueOf(p.calories));
        name.setOnItemClickListener((parent, v, pos, id) -> {
            FoodItem f = FoodCatalog.find((String) parent.getItemAtPosition(pos));
            if (f != null) kcalInput.setText(String.valueOf(f.calories));
        });

        AlertDialog dialog = new NpDialogBuilder(this)
                .setTitle("Edit " + p.slot)
                .setView(view)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            int k;
            try { k = Integer.parseInt(kcalInput.getText().toString().trim()); }
            catch (NumberFormatException e) { k = -1; }
            if (n.isEmpty()) { ((TextInputLayout) view.findViewById(R.id.plan_edit_name_layout)).setError("Enter a meal"); return; }
            if (k < 0 || k > 5000) { kcalLayout.setError("Enter 0–5000 kcal"); return; }
            repo.editPlan(p.id, n, k, ok -> loadPlans());
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void loadNutrition() {
        repo.getDayNutrition(selectedKey(), n -> {
            if (n == null) return;
            kcal.setText(String.format(Locale.US, "%,d", n.calories));
            goal.setText(String.format(Locale.US, "/ %,d kcal", n.goal));
            protein.setText(String.format(Locale.US, "%.0fg", n.protein));
            carbs.setText(String.format(Locale.US, "%.0fg", n.carbs));
            fat.setText(String.format(Locale.US, "%.0fg", n.fat));
            ring.setProgress(n.calories, n.goal);
        });
    }

    // ------------------------------------------------------------ copy plans + notes

    private void showCopyMenu() {
        String day = DateUtils.format("EEE d MMM", selectedDay);
        OptionSheet.show(this, "Copy meal plan & notes", "Breakfast, lunch, dinner and your notes",
                R.drawable.ic_copy, R.color.pink_primary, R.color.pink_light,
                OptionSheet.opt(R.drawable.ic_back, R.color.purple, R.color.lavender,
                        "From the previous day", "Copy it into " + day, () -> copyChoice(0, day)),
                OptionSheet.opt(R.drawable.ic_chevron, R.color.blue_water, R.color.blue_light,
                        "To the next day", "Copy " + day + " forward one day", () -> copyChoice(1, day)),
                OptionSheet.opt(R.drawable.ic_calendar, R.color.leaf_dark, R.color.green_light,
                        "To the rest of this week", "Copy " + day + " until Sunday", () -> copyChoice(2, day)));
    }

    private void copyChoice(int which, String day) {
        String here = selectedKey();
        List<String> targets = new ArrayList<>();
        if (which == 0) {
            Calendar prev = (Calendar) selectedDay.clone();
            prev.add(Calendar.DAY_OF_YEAR, -1);
            confirmCopy(DateUtils.keyOf(prev), java.util.Collections.singletonList(here),
                    "This replaces " + day + "'s Breakfast/Lunch/Dinner and adds the notes.");
            return;
        } else if (which == 1) {
            Calendar next = (Calendar) selectedDay.clone();
            next.add(Calendar.DAY_OF_YEAR, 1);
            targets.add(DateUtils.keyOf(next));
        } else {
            Calendar c = (Calendar) selectedDay.clone();
            c.setFirstDayOfWeek(Calendar.MONDAY);
            c.add(Calendar.DAY_OF_YEAR, 1);
            while (c.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
                targets.add(DateUtils.keyOf(c));
                c.add(Calendar.DAY_OF_YEAR, 1);
            }
            if (targets.isEmpty()) {
                UiUtils.toast(this, "This is already the last day of the week");
                return;
            }
        }
        confirmCopy(here, targets, "This replaces the plan on " + targets.size()
                + " day(s) and adds this day's notes there.");
    }

    private void confirmCopy(String from, List<String> to, String message) {
        new NpDialogBuilder(this)
                .setTitle("Copy?")
                .setMessage(message)
                .setPositiveButton("Copy", (d, w) -> repo.getPlans(from, plansReady ->   // makes sure source has a plan
                        repo.copyDay(from, to, n -> {
                            UiUtils.toast(this, n == null ? "Copy failed" : "Copied to " + n + " day(s) ✅");
                            refresh();
                        })))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showDetails() {
        repo.getDayNutrition(selectedKey(), n -> {
            if (n == null) return;
            View v = getLayoutInflater().inflate(R.layout.dialog_food_diary, null, false);
            ((TextView) v.findViewById(R.id.fd_date)).setText(DateUtils.format("EEEE, d MMMM", selectedDay));
            ((TextView) v.findViewById(R.id.fd_kcal)).setText(String.format(Locale.US, "%,d", n.calories));
            ((TextView) v.findViewById(R.id.fd_goal)).setText(n.goal > 0
                    ? String.format(Locale.US, "/ %,d kcal", n.goal) : "kcal");
            ((TextView) v.findViewById(R.id.fd_count)).setText(n.meals.size() + (n.meals.size() == 1 ? " item" : " items"));
            ((android.widget.ProgressBar) v.findViewById(R.id.fd_bar)).setProgress(
                    n.goal > 0 ? Math.min(100, Math.round(n.calories * 100f / n.goal)) : 0);
            ((TextView) v.findViewById(R.id.fd_protein)).setText(String.format(Locale.US, "%.0fg protein", n.protein));
            ((TextView) v.findViewById(R.id.fd_carbs)).setText(String.format(Locale.US, "%.0fg carbs", n.carbs));
            ((TextView) v.findViewById(R.id.fd_fat)).setText(String.format(Locale.US, "%.0fg fat", n.fat));

            LinearLayout list = v.findViewById(R.id.fd_list);
            v.findViewById(R.id.fd_empty).setVisibility(n.meals.isEmpty() ? View.VISIBLE : View.GONE);
            v.findViewById(R.id.fd_summary).setVisibility(n.meals.isEmpty() ? View.GONE : View.VISIBLE);
            java.text.SimpleDateFormat time = new java.text.SimpleDateFormat("h:mm a", Locale.US);
            for (MealRecord m : n.meals) {
                View row = getLayoutInflater().inflate(R.layout.item_diary_entry, list, false);
                TextView emoji = row.findViewById(R.id.de_emoji);
                if (m.emoji == null || m.emoji.isEmpty()) {
                    emoji.setVisibility(View.GONE);
                    row.findViewById(R.id.de_icon).setVisibility(View.VISIBLE);
                } else {
                    emoji.setText(m.emoji);
                }
                ((TextView) row.findViewById(R.id.de_name)).setText(m.foodName);
                TextView cat = row.findViewById(R.id.de_cat);
                cat.setText(m.category);
                int catColor = "Snack".equalsIgnoreCase(m.category) ? R.color.orange
                        : "Drink".equalsIgnoreCase(m.category) ? R.color.blue_water : R.color.pink_primary;
                int catBg = "Snack".equalsIgnoreCase(m.category) ? R.color.orange_light
                        : "Drink".equalsIgnoreCase(m.category) ? R.color.blue_light : R.color.pink_light;
                cat.setTextColor(ContextCompat.getColor(this, catColor));
                cat.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, catBg)));
                StringBuilder meta = new StringBuilder();
                if (m.servings > 0 && m.servings != 1f) {
                    meta.append(m.servings == (int) m.servings ? String.valueOf((int) m.servings)
                            : String.valueOf(m.servings)).append(" servings");
                }
                if (m.timestamp > 0) {
                    if (meta.length() > 0) meta.append(" · ");
                    meta.append(time.format(new java.util.Date(m.timestamp)));
                }
                ((TextView) row.findViewById(R.id.de_meta)).setText(meta.toString());
                ((TextView) row.findViewById(R.id.de_kcal)).setText(String.format(Locale.US, "%,d", m.calories));
                list.addView(row);
            }
            androidx.appcompat.app.AlertDialog dialog = new NpDialogBuilder(this).setView(v).create();
            v.findViewById(R.id.fd_close).setOnClickListener(x -> dialog.dismiss());
            dialog.show();
        });
    }

    private void pickDate() {
        new DatePickerDialog(this, (dp, y, m, d) -> {
            Calendar c = Calendar.getInstance();
            c.set(y, m, d);
            selectedDay = c;
            refresh();
        }, selectedDay.get(Calendar.YEAR), selectedDay.get(Calendar.MONTH),
                selectedDay.get(Calendar.DAY_OF_MONTH)).show();
    }
}
