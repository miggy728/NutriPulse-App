package com.nutripulse.app.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.models.User;
import com.nutripulse.app.ui.HomeActivity;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.utils.ValidationUtils;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout emailLayout, passwordLayout;
    private CheckBox remember;
    private MaterialButton loginButton;
    private ProgressBar progress;
    private TextView errorBox;
    private AuthManager auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = AuthManager.get(this);

        // Already signed in during this app session? Skip the form.
        if (auth.isLoggedIn()) {
            goHome();
            return;
        }
        setContentView(R.layout.activity_login);

        emailLayout = findViewById(R.id.login_email_layout);
        passwordLayout = findViewById(R.id.login_password_layout);
        remember = findViewById(R.id.login_remember);
        loginButton = findViewById(R.id.login_button);
        progress = findViewById(R.id.login_progress);
        errorBox = findViewById(R.id.login_error);

        String remembered = auth.session().getRememberedEmail();
        if (!remembered.isEmpty() && emailLayout.getEditText() != null) {
            emailLayout.getEditText().setText(remembered);
            remember.setChecked(true);
        }

        loginButton.setOnClickListener(v -> attemptLogin());
        EditText pw = findViewById(R.id.login_password);
        pw.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { attemptLogin(); return true; }
            return false;
        });
        findViewById(R.id.login_register).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.login_forgot).setOnClickListener(v ->
                startActivity(new Intent(this, ForgotPasswordActivity.class)));
        findViewById(R.id.login_mascot).setOnClickListener(UiUtils::bounce);
    }

    private void attemptLogin() {
        UiUtils.clearErrors(emailLayout, passwordLayout);
        errorBox.setVisibility(View.GONE);
        String email = UiUtils.text(emailLayout).trim();
        String password = UiUtils.text(passwordLayout);

        boolean valid = true;
        if (email.isEmpty()) {
            emailLayout.setError("Email is required");
            valid = false;
        } else if (!ValidationUtils.isValidEmail(email)) {
            emailLayout.setError("Enter a valid email address");
            valid = false;
        }
        if (password.isEmpty()) {
            passwordLayout.setError("Password is required");
            valid = false;
        }
        if (!valid) return;

        UiUtils.hideKeyboard(this);
        setLoading(true);
        auth.login(email, password, remember.isChecked(), new AuthManager.Callback<User>() {
            @Override
            public void onSuccess(User user) {
                setLoading(false);
                UiUtils.toast(LoginActivity.this, "Welcome back, " + user.getFirstName() + "! 💗");
                goHome();
            }

            @Override
            public void onError(String message) {
                setLoading(false);
                errorBox.setText(message);
                errorBox.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setLoading(boolean loading) {
        loginButton.setEnabled(!loading);
        loginButton.setText(loading ? "" : getString(R.string.login));
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
    }

    private void goHome() {
        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
