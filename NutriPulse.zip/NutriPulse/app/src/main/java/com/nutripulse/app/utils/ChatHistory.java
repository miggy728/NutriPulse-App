package com.nutripulse.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.nutripulse.app.models.ChatMessage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Saves each user's chat with Berry separately (keyed by user id), keeping the latest 80 messages. */
public class ChatHistory {
    private static final int MAX = 80;
    private final SharedPreferences prefs;
    private final String key;

    public ChatHistory(Context context, long userId) {
        prefs = context.getApplicationContext().getSharedPreferences("nutripulse_chat", Context.MODE_PRIVATE);
        key = "history_" + userId;
    }

    public List<ChatMessage> load() {
        List<ChatMessage> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new ChatMessage(o.getInt("s"), o.getString("t"), o.optLong("w")));
            }
        } catch (Exception ignored) { }
        return list;
    }

    public void save(List<ChatMessage> messages) {
        JSONArray arr = new JSONArray();
        int start = Math.max(0, messages.size() - MAX);
        try {
            for (int i = start; i < messages.size(); i++) {
                ChatMessage m = messages.get(i);
                if (m.sender == ChatMessage.TYPING) continue;
                arr.put(new JSONObject().put("s", m.sender).put("t", m.text).put("w", m.time));
            }
        } catch (Exception ignored) { }
        prefs.edit().putString(key, arr.toString()).apply();
    }

    public void clear() { prefs.edit().remove(key).apply(); }
}
