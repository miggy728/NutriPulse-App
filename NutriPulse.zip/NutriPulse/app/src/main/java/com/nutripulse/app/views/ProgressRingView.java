package com.nutripulse.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/** Colourful calorie ring used on the Meal Planner nutrition summary. */
public class ProgressRingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private float fraction = 0f;

    public ProgressRingView(Context c, @Nullable AttributeSet attrs) {
        super(c, attrs);
        float stroke = 14 * getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(androidx.core.content.ContextCompat.getColor(c, com.nutripulse.app.R.color.pink_light));
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);
        arc.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setProgress(float value, float max) {
        fraction = max <= 0 ? 0 : Math.min(1f, value / max);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float pad = track.getStrokeWidth() / 2 + 2;
        float size = Math.min(getWidth(), getHeight());
        float left = (getWidth() - size) / 2f, top = (getHeight() - size) / 2f;
        box.set(left + pad, top + pad, left + size - pad, top + size - pad);
        canvas.drawArc(box, 0, 360, false, track);

        SweepGradient g = new SweepGradient(box.centerX(), box.centerY(),
                new int[]{Color.parseColor("#FF4F8B"), Color.parseColor("#A57CF0"),
                        Color.parseColor("#4AAEF5"), Color.parseColor("#3DBE7C"),
                        Color.parseColor("#FFB13D"), Color.parseColor("#FF4F8B")}, null);
        Matrix m = new Matrix();
        m.setRotate(-90, box.centerX(), box.centerY());
        g.setLocalMatrix(m);
        arc.setShader(g);
        if (fraction > 0) canvas.drawArc(box, -90, 360 * fraction, false, arc);
    }
}
