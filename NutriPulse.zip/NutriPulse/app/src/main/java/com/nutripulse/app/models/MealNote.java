package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** One line in the user's "My Meal Notes" list for a given day. */
@Entity(tableName = "meal_notes",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey"})})
public class MealNote {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String dateKey = "";
    @NonNull public String text = "";
    public boolean done;
    public long createdAt;
}
