package com.nutripulse.app.data;

import com.nutripulse.app.models.Achievement;

import java.util.ArrayList;
import java.util.List;

/** Definitions of every achievement a user can unlock. */
public final class Achievements {
    public static final String FIRST_MEAL = "first_meal";
    public static final String HEALTHY_EATER = "healthy_eater";
    public static final String HYDRATION_HERO = "hydration_hero";
    public static final String ACTIVE_DAY = "active_day";
    public static final String STEP_STAR = "step_star";
    public static final String WEIGH_IN = "weigh_in";
    public static final String LEVEL_UP = "level_up";
    public static final String BLOOM = "bloom";
    public static final String STREAK_3 = "streak_3";
    public static final String STREAK_7 = "streak_7";
    public static final String STREAK_30 = "streak_30";
    public static final String SHOPPER = "shopper";

    private Achievements() {}

    private static final String[][] DEFS = {
            {FIRST_MEAL, "First Bite", "Log your very first meal", "🍽️"},
            {HEALTHY_EATER, "Healthy Eater", "Log 5 healthy meals", "🏅"},
            {HYDRATION_HERO, "Hydration Hero", "Reach your daily water goal", "💧"},
            {ACTIVE_DAY, "Active Day", "Complete all daily goals in one day", "⭐"},
            {STEP_STAR, "Step Star", "Reach your daily step goal", "👟"},
            {WEIGH_IN, "Weigh-In Habit", "Log your weight 3 times", "⚖️"},
            {LEVEL_UP, "Growing Up", "Help Berry reach Level 2", "🌱"},
            {BLOOM, "Berry Bloom", "Evolve Berry at Level 5", "👑"},
            {STREAK_3, "On Fire", "Log food 3 days in a row (+15 EXP)", "🔥"},
            {STREAK_7, "Week Warrior", "Log food 7 days in a row (+30 EXP)", "🗓️"},
            {STREAK_30, "Unstoppable", "Log food 30 days in a row (+100 EXP)", "🏆"},
            {SHOPPER, "Dress-Up Day", "Buy your first item in the Berry Shop", "🛍️"},
    };

    public static List<Achievement> defaultsFor(long userId) {
        List<Achievement> list = new ArrayList<>();
        for (String[] d : DEFS) {
            Achievement a = new Achievement();
            a.userId = userId;
            a.achKey = d[0];
            a.title = d[1];
            a.description = d[2];
            a.emoji = d[3];
            list.add(a);
        }
        return list;
    }
}
