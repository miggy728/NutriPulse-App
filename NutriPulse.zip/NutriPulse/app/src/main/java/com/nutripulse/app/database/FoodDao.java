package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.FavoriteFood;
import com.nutripulse.app.models.MealRecord;

import java.util.List;

/** Custom foods, favorites and editing of logged meals. Every query is filtered by userId. */
@Dao
public interface FoodDao {
    // Custom foods
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insertCustom(CustomFood food);

    @Query("SELECT * FROM custom_foods WHERE userId = :userId ORDER BY name COLLATE NOCASE")
    List<CustomFood> customFoods(long userId);

    @Query("SELECT COUNT(*) FROM custom_foods WHERE userId = :userId AND name = :name COLLATE NOCASE")
    int countCustomNamed(long userId, String name);

    @Query("DELETE FROM custom_foods WHERE id = :id AND userId = :userId")
    void deleteCustom(long userId, long id);

    // Favorites
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insertFavorite(FavoriteFood fav);

    @Query("DELETE FROM favorite_foods WHERE userId = :userId AND foodName = :name")
    void deleteFavorite(long userId, String name);

    @Query("SELECT foodName FROM favorite_foods WHERE userId = :userId ORDER BY createdAt DESC")
    List<String> favoriteNames(long userId);

    // Recent foods: latest record of each distinct food name
    @Query("SELECT * FROM meal_records WHERE userId = :userId AND id IN " +
           "(SELECT MAX(id) FROM meal_records WHERE userId = :userId GROUP BY foodName) " +
           "ORDER BY timestamp DESC LIMIT 15")
    List<MealRecord> recentMeals(long userId);

    @Query("SELECT * FROM meal_records WHERE userId = :userId AND foodName = :name ORDER BY id DESC LIMIT 1")
    MealRecord lastMealNamed(long userId, String name);

    // Editing logged meals
    @Query("SELECT * FROM meal_records WHERE id = :id AND userId = :userId LIMIT 1")
    MealRecord meal(long userId, long id);

    @Query("UPDATE meal_records SET servings = :servings, calories = :calories, protein = :protein, " +
           "carbs = :carbs, fat = :fat WHERE id = :id AND userId = :userId")
    void updateMealAmounts(long userId, long id, float servings, int calories, float protein, float carbs, float fat);

    @Query("DELETE FROM meal_records WHERE id = :id AND userId = :userId")
    void deleteMeal(long userId, long id);

    @Query("SELECT COUNT(*) FROM meal_records WHERE userId = :userId AND dateKey = :dateKey")
    int mealsForDayCount(long userId, String dateKey);
}
