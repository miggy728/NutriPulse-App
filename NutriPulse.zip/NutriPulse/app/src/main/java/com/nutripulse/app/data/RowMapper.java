package com.nutripulse.app.data;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

/** Converts Room entities (public fields) to plain maps and back, for cloud backup. */
public final class RowMapper {
    private RowMapper() {}

    public static Map<String, Object> toMap(Object o) {
        Map<String, Object> m = new HashMap<>();
        for (Field f : o.getClass().getFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            try { m.put(f.getName(), f.get(o)); } catch (IllegalAccessException ignored) { }
        }
        return m;
    }

    /** Firestore returns whole numbers as Long and decimals as Double; this converts them back. */
    public static <T> T fromMap(Map<String, Object> m, Class<T> type) throws Exception {
        T o = type.getDeclaredConstructor().newInstance();
        for (Field f : type.getFields()) {
            if (Modifier.isStatic(f.getModifiers()) || Modifier.isFinal(f.getModifiers())) continue;
            Object v = m.get(f.getName());
            if (v == null) continue;
            Class<?> t = f.getType();
            if (t == long.class) f.setLong(o, ((Number) v).longValue());
            else if (t == int.class) f.setInt(o, ((Number) v).intValue());
            else if (t == float.class) f.setFloat(o, ((Number) v).floatValue());
            else if (t == double.class) f.setDouble(o, ((Number) v).doubleValue());
            else if (t == boolean.class) f.setBoolean(o, (Boolean) v);
            else if (t == String.class) f.set(o, String.valueOf(v));
        }
        return o;
    }

    public static void setIfPresent(Object o, String name, long value) {
        try {
            Field f = o.getClass().getField(name);
            if (f.getType() == long.class) f.setLong(o, value);
        } catch (NoSuchFieldException | IllegalAccessException ignored) { }
    }
}
