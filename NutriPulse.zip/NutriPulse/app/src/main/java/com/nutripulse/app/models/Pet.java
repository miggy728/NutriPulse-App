package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** The user's virtual pet. Exactly one per user. */
@Entity(tableName = "pets",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = "userId", unique = true)})
public class Pet {
    public static final int EXP_PER_LEVEL = 100;

    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String name = "Berry";
    public int level = 1;
    public int exp = 0;
    public long createdAt;

    // ---- Berry Shop (added in database v4)
    /** Coins earned together with EXP, spent in the Berry Shop. */
    @ColumnInfo(defaultValue = "0") public int coins = 0;
    /** Bit flags of owned shop item ids (see ShopItems). */
    @ColumnInfo(defaultValue = "0") public long ownedItems = 0;
    /** Equipped item ids, 0 = none. */
    @ColumnInfo(defaultValue = "0") public int hat = 0;
    @ColumnInfo(defaultValue = "0") public int face = 0;
    @ColumnInfo(defaultValue = "0") public int room = 0;

    public boolean owns(int itemId) { return (ownedItems & (1L << itemId)) != 0; }
    public void addOwned(int itemId) { ownedItems |= (1L << itemId); }

    /** Evolution stage: 1 = Sprout (Lv1-4), 2 = Bloom (Lv5-9), 3 = Royal Berry (Lv10+). */
    public int getStage() {
        if (level >= 10) return 3;
        if (level >= 5) return 2;
        return 1;
    }

    public String getStageName() {
        switch (getStage()) {
            case 3: return "Royal Berry";
            case 2: return "Bloom Berry";
            default: return "Sprout Berry";
        }
    }

    public int nextEvolutionLevel() {
        return level < 5 ? 5 : (level < 10 ? 10 : -1);
    }
}
