package com.nutripulse.app.views;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.nutripulse.app.R;
import com.nutripulse.app.data.LookPrefs;
import com.nutripulse.app.data.PetLook;

/**
 * TikTok-style accessory editing on top of a pet stage.
 *
 * - One finger: drag the selected accessory.
 * - Two fingers: pinch to resize, twist to rotate.
 * - Tap an accessory to select it.
 *
 * Accessories live inside Berry's body view, so once saved they move with every animation.
 * Positions are stored in dp per user and per item (see LookPrefs).
 */
public class AccessoryEditor {

    public interface Callbacks {
        void onEditStart();   // e.g. pause Berry's animation
        void onEditEnd();     // e.g. resume animation and reload
    }

    private static final float MIN_SCALE = 0.4f, MAX_SCALE = 3f, MAX_OFFSET_DP = 120f;

    private final FrameLayout stage;
    private final TextView hatView, faceView;
    private final long userId;
    private final Callbacks callbacks;
    private final float dp;

    private FrameLayout overlay;
    private TextView active;
    private int hatId, faceId;
    private float lastX, lastY, lastAngle = Float.NaN;
    private boolean needAnchor;
    private ScaleGestureDetector scaleDetector;

    public AccessoryEditor(FrameLayout stage, TextView hatView, TextView faceView, long userId, Callbacks cb) {
        this.stage = stage;
        this.hatView = hatView;
        this.faceView = faceView;
        this.userId = userId;
        this.callbacks = cb;
        this.dp = stage.getResources().getDisplayMetrics().density;
    }

    public boolean isEditing() { return overlay != null; }

    /** @param hatItemId / faceItemId the items currently shown (0 = none) */
    public void start(int hatItemId, int faceItemId) {
        if (overlay != null) return;
        if (hatItemId == 0 && faceItemId == 0) return;
        hatId = hatItemId;
        faceId = faceItemId;
        callbacks.onEditStart();
        buildOverlay();
        select(hatItemId != 0 ? hatView : faceView);
    }

    public void finish(boolean save) {
        if (overlay == null) return;
        if (save) {
            if (hatId != 0) store(hatView, hatId);
            if (faceId != 0) store(faceView, faceId);
        }
        hatView.setBackground(null);
        faceView.setBackground(null);
        stage.removeView(overlay);
        overlay = null;
        active = null;
        callbacks.onEditEnd();
    }

    private void store(TextView v, int itemId) {
        LookPrefs.save(stage.getContext(), userId, itemId,
                v.getTranslationX() / dp, v.getTranslationY() / dp, v.getScaleX(), v.getRotation());
    }

    private void resetActive() {
        if (active == null) return;
        PetLook.place(active, LookPrefs.DEFAULT);
    }

    // ------------------------------------------------------------------ UI

    private void buildOverlay() {
        Context c = stage.getContext();
        overlay = new FrameLayout(c);
        overlay.setElevation(30 * dp);
        overlay.setBackgroundColor(0x14000000);

        TextView done = pill(c, "✓  Save", R.drawable.bg_pill_pink, R.color.white);
        FrameLayout.LayoutParams lpDone = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        lpDone.setMargins(0, (int) (8 * dp), (int) (8 * dp), 0);
        done.setOnClickListener(v -> finish(true));
        overlay.addView(done, lpDone);

        TextView reset = pill(c, "↺ Reset", R.drawable.bg_pill, R.color.pink_dark);
        FrameLayout.LayoutParams lpReset = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        lpReset.setMargins((int) (8 * dp), (int) (8 * dp), 0, 0);
        reset.setOnClickListener(v -> resetActive());
        overlay.addView(reset, lpReset);

        TextView cancel = pill(c, "✕", R.drawable.bg_pill, R.color.text_muted);
        FrameLayout.LayoutParams lpCancel = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        lpCancel.setMargins((int) (92 * dp), (int) (8 * dp), 0, 0);
        cancel.setOnClickListener(v -> finish(false));
        overlay.addView(cancel, lpCancel);

        TextView hint = new TextView(c);
        hint.setText("Drag to move · Pinch to resize · Twist to rotate");
        hint.setTextSize(11);
        hint.setTextColor(ContextCompat.getColor(c, R.color.text_dark));
        hint.setBackgroundResource(R.drawable.bg_bubble);
        int p = (int) (8 * dp);
        hint.setPadding(p, p / 2, p, p / 2);
        FrameLayout.LayoutParams lpHint = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lpHint.setMargins(0, 0, 0, (int) (6 * dp));
        overlay.addView(hint, lpHint);

        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                if (active == null) return false;
                float s = clamp(active.getScaleX() * d.getScaleFactor(), MIN_SCALE, MAX_SCALE);
                active.setScaleX(s);
                active.setScaleY(s);
                return true;
            }
        });
        overlay.setOnTouchListener(this::onTouch);
        stage.addView(overlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private TextView pill(Context c, String text, int bg, int color) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(13);
        t.setTextColor(ContextCompat.getColor(c, color));
        t.setBackgroundResource(bg);
        int h = (int) (12 * dp), v = (int) (6 * dp);
        t.setPadding(h, v, h, v);
        return t;
    }

    private void select(TextView v) {
        if (v == null || v.getVisibility() != View.VISIBLE) return;
        active = v;
        hatView.setBackground(v == hatView ? ContextCompat.getDrawable(stage.getContext(), R.drawable.bg_edit_outline) : null);
        faceView.setBackground(v == faceView ? ContextCompat.getDrawable(stage.getContext(), R.drawable.bg_edit_outline) : null);
    }

    // ------------------------------------------------------------------ gestures

    private boolean onTouch(View v, MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                TextView hit = hitTest(e.getRawX(), e.getRawY());
                if (hit != null) select(hit);
                lastX = e.getRawX();
                lastY = e.getRawY();
                needAnchor = false;
                lastAngle = Float.NaN;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                lastAngle = angle(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (active == null) return true;
                if (e.getPointerCount() >= 2) {
                    float a = angle(e);
                    if (!Float.isNaN(lastAngle)) {
                        float delta = a - lastAngle;
                        if (delta > 180) delta -= 360;
                        if (delta < -180) delta += 360;
                        active.setRotation(active.getRotation() + delta);
                    }
                    lastAngle = a;
                } else if (!scaleDetector.isInProgress()) {
                    if (needAnchor) {
                        lastX = e.getRawX();
                        lastY = e.getRawY();
                        needAnchor = false;
                        return true;
                    }
                    float max = MAX_OFFSET_DP * dp;
                    active.setTranslationX(clamp(active.getTranslationX() + e.getRawX() - lastX, -max, max));
                    active.setTranslationY(clamp(active.getTranslationY() + e.getRawY() - lastY, -max, max));
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                lastAngle = Float.NaN;
                needAnchor = true;     // the remaining finger becomes the new drag anchor
                return true;
            default:
                return true;
        }
    }

    private TextView hitTest(float rawX, float rawY) {
        for (TextView v : new TextView[]{hatView, faceView}) {
            if (v.getVisibility() != View.VISIBLE) continue;
            // Center of the (moved and scaled) accessory in screen coordinates
            int[] parent = new int[2];
            ((View) v.getParent()).getLocationOnScreen(parent);
            float cx = parent[0] + v.getLeft() + v.getTranslationX() + v.getWidth() / 2f;
            float cy = parent[1] + v.getTop() + v.getTranslationY() + v.getHeight() / 2f;
            float radius = Math.max(v.getWidth(), v.getHeight()) * v.getScaleX() / 2f + 12 * dp;
            if (Math.hypot(rawX - cx, rawY - cy) <= radius) return v;
        }
        return null;
    }

    private static float angle(MotionEvent e) {
        if (e.getPointerCount() < 2) return Float.NaN;
        double dx = e.getX(1) - e.getX(0), dy = e.getY(1) - e.getY(0);
        return (float) Math.toDegrees(Math.atan2(dy, dx));
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
