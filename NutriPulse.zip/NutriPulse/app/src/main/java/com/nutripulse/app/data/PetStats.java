package com.nutripulse.app.data;

/** Berry's live status, calculated from today's logs. */
public class PetStats {
    public int energy;      // from calories eaten vs goal
    public int hydration;   // from water vs goal
    public int gutHealth;   // from healthy meals
    public int moodScore;
    public String mood;
    public String tip;
    public String speech;

    public static PetStats calculate(int calories, int calorieGoal, int cups, int hydrationGoal,
                                     int healthyMealsToday, int mealsToday) {
        PetStats s = new PetStats();
        s.energy = clamp(20 + (int) (80f * calories / Math.max(1, calorieGoal)));
        s.hydration = clamp((int) (100f * cups / Math.max(1, hydrationGoal)));
        s.gutHealth = clamp(mealsToday == 0 ? 60 : 55 + healthyMealsToday * 15
                - (mealsToday - healthyMealsToday) * 10);
        s.moodScore = (s.energy + s.hydration + s.gutHealth) / 3;
        if (s.moodScore >= 75) s.mood = "Happy!";
        else if (s.moodScore >= 50) s.mood = "Good";
        else if (s.moodScore >= 30) s.mood = "Okay";
        else s.mood = "Hungry";

        int lowest = Math.min(s.energy, Math.min(s.hydration, s.gutHealth));
        if (mealsToday == 0) {
            s.speech = "I'm hungry! Let's log a healthy meal together 💗";
            s.tip = "Start your day with a balanced breakfast.";
        } else if (lowest == s.hydration) {
            s.speech = "Can we drink some water? 💧";
            s.tip = "Drink more water to keep your pet even healthier!";
        } else if (lowest == s.gutHealth) {
            s.speech = "Fruits and veggies make my tummy happy!";
            s.tip = "Add fiber-rich foods like vegetables and fruit.";
        } else if (lowest == s.energy) {
            s.speech = "I need a little more fuel today!";
            s.tip = "Don't skip meals. Steady energy keeps Berry bouncy.";
        } else {
            s.speech = "You're doing great! Let's keep eating healthy together 💗";
            s.tip = "Keep it up! Consistency is the secret.";
        }
        if (s.moodScore >= 80) s.speech = "Yay! You're taking such good care of us! 💗";
        return s;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }
}
