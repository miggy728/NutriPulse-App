package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "meal_plans",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey", "slot"}, unique = true)})
public class MealPlan {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String dateKey = "";
    @NonNull public String slot = "Breakfast";  // Breakfast, Lunch, Dinner
    @NonNull public String name = "";
    public String emoji;
    public int calories;
    public boolean completed;
}
