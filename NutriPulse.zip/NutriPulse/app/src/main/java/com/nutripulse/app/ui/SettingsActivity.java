package com.nutripulse.app.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import android.Manifest;
import android.os.Build;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.nutripulse.app.reminders.ReminderScheduler;
import com.nutripulse.app.cloud.Cloud;
import com.nutripulse.app.cloud.CloudBackup;
import com.google.firebase.auth.FirebaseUser;
import com.nutripulse.app.utils.StepSensor;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.auth.AuthManager;
import com.nutripulse.app.auth.LoginActivity;
import com.nutripulse.app.models.User;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.utils.ValidationUtils;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Profile, goals, preferences, password and logout. */
public class SettingsActivity extends BaseAuthActivity {

    private static final List<String> DIETS = Arrays.asList(
            "No preference", "Balanced", "Vegetarian", "Vegan", "Pescatarian",
            "Low carb", "High protein", "Halal", "Diabetic-friendly");

    private User user;
    private ImageView avatar;
    private ImageView pendingAvatarPreview;
    private Uri pendingPhoto;

    private final ActivityResultLauncher<String[]> pickPhoto =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri == null) return;
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (SecurityException ignored) { }
                pendingPhoto = uri;
                if (pendingAvatarPreview != null) showPhoto(pendingAvatarPreview, uri.toString());
            });

    /** Reminder group waiting for the notification permission answer. */
    private String pendingReminder;
    private SwitchMaterial pendingSwitch;

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (pendingReminder == null) return;
                if (granted) {
                    ReminderScheduler.setOn(this, pendingReminder, true);
                    UiUtils.toast(this, "🔔 Reminder on! Berry will remind you.");
                } else {
                    if (pendingSwitch != null) pendingSwitch.setChecked(false);
                    UiUtils.toast(this, "Notifications are blocked. You can allow them in your phone's Settings.");
                }
                pendingReminder = null;
            });

    private final ActivityResultLauncher<String> stepPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                StepSensor sensor = new StepSensor(this);
                sensor.setEnabled(granted);
                if (pendingSwitch != null) pendingSwitch.setChecked(granted);
                UiUtils.toast(this, granted ? "👟 Step counter on! Your steps will be added automatically."
                        : "Step counter needs the Physical activity permission.");
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_settings);
        BottomNav.setup(this, BottomNav.PROFILE);
        avatar = findViewById(R.id.settings_avatar);

        findViewById(R.id.settings_back).setOnClickListener(v -> finish());
        findViewById(R.id.settings_edit).setOnClickListener(v -> editProfile());
        findViewById(R.id.row_app_settings).setOnClickListener(v -> appSettings());
        findViewById(R.id.row_notifications).setOnClickListener(v -> reminders());
        findViewById(R.id.row_diet).setOnClickListener(v -> dietaryPreferences());
        findViewById(R.id.row_goals).setOnClickListener(v -> healthGoals());
        findViewById(R.id.row_chat).setOnClickListener(v -> startActivity(new Intent(this, ChatActivity.class)));
        findViewById(R.id.row_insights).setOnClickListener(v -> startActivity(new Intent(this, InsightsActivity.class)));
        findViewById(R.id.row_about).setOnClickListener(v -> info("About NutriPulse",
                "NutriPulse 1.0\nEat Smart. Live Healthy.\n\nTrack meals, water, steps and weight while caring for Berry, "
                        + "your virtual wellness buddy. NutriPulse is not a substitute for professional medical advice."));
        findViewById(R.id.row_help).setOnLongClickListener(v -> { replayTour(); return true; });
        findViewById(R.id.row_help).setOnClickListener(v -> helpDialog());
        findViewById(R.id.row_logout).setOnClickListener(v -> confirmLogout());
        findViewById(R.id.row_cloud).setOnClickListener(v -> cloudDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!noSession()) loadUser();
    }

    private void loadUser() {
        repo.getUser(u -> {
            if (u == null) { redirectToLogin(); return; }
            user = u;
            ((TextView) findViewById(R.id.settings_name)).setText(u.fullName);
            ((TextView) findViewById(R.id.settings_username)).setText("@" + u.username);
            ((TextView) findViewById(R.id.settings_email)).setText(u.email);
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(u.registrationDate);
            ((TextView) findViewById(R.id.settings_since)).setText("Member since " + DateUtils.format("d MMM yyyy", c));
            showPhoto(avatar, u.profilePictureUri);
        });
    }

    private void showPhoto(ImageView view, String uri) {
        if (uri == null || uri.isEmpty()) return;
        try {
            view.setImageTintList(null);
            view.setImageURI(Uri.parse(uri));
        } catch (Exception e) {
            view.setImageResource(R.drawable.ic_person);
        }
    }

    // ------------------------------------------------------------ profile

    private void editProfile() {
        if (user == null) return;
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null);
        TextInputLayout nameL = v.findViewById(R.id.edit_name_layout);
        TextView nameInput = v.findViewById(R.id.edit_name);
        pendingAvatarPreview = v.findViewById(R.id.edit_avatar);
        pendingPhoto = null;
        nameInput.setText(user.fullName);
        showPhoto(pendingAvatarPreview, user.profilePictureUri);
        v.findViewById(R.id.edit_photo).setOnClickListener(x -> pickPhoto.launch(new String[]{"image/*"}));

        AlertDialog d = new NpDialogBuilder(this)
                .setTitle("Edit Profile")
                .setView(v)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String name = nameInput.getText().toString().trim();
            if (!ValidationUtils.isValidFullName(name)) { nameL.setError("Enter your full name"); return; }
            repo.updateProfile(name, pendingPhoto == null ? null : pendingPhoto.toString(), u -> {
                UiUtils.toast(this, "Profile updated 💗");
                loadUser();
            });
            d.dismiss();
        }));
        d.setOnDismissListener(x -> pendingAvatarPreview = null);
        d.show();
    }

    // ------------------------------------------------------------ goals

    private void healthGoals() {
        if (user == null) return;
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_health_goals, null);
        TextView cal = v.findViewById(R.id.goal_calories), water = v.findViewById(R.id.goal_water),
                weight = v.findViewById(R.id.goal_weight), steps = v.findViewById(R.id.goal_steps);
        cal.setText(String.valueOf(user.calorieGoal));
        water.setText(String.valueOf(user.hydrationGoal));
        weight.setText(user.weightGoal > 0 ? String.format(Locale.US, "%.1f", user.weightGoal) : "0");
        steps.setText(String.valueOf(user.stepGoal));

        AlertDialog d = new NpDialogBuilder(this)
                .setTitle("Health Goals")
                .setView(v)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            Integer c = parseInt(v, R.id.goal_calories_layout, cal, 800, 6000);
            Integer w = parseInt(v, R.id.goal_water_layout, water, 1, 30);
            Integer s = parseInt(v, R.id.goal_steps_layout, steps, 500, 100000);
            Float kg = parseFloat(v, R.id.goal_weight_layout, weight, 0, 400);
            if (c == null || w == null || s == null || kg == null) return;
            repo.updateGoals(c, w, kg, s, u -> { user = u; UiUtils.toast(this, "Goals saved 🎯"); });
            d.dismiss();
        }));
        d.show();
    }

    private Integer parseInt(View root, int layoutId, TextView input, int min, int max) {
        TextInputLayout l = root.findViewById(layoutId);
        l.setError(null);
        try {
            int v = Integer.parseInt(input.getText().toString().trim());
            if (v < min || v > max) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            l.setError("Enter " + min + "–" + max);
            return null;
        }
    }

    private Float parseFloat(View root, int layoutId, TextView input, float min, float max) {
        TextInputLayout l = root.findViewById(layoutId);
        l.setError(null);
        try {
            float v = Float.parseFloat(input.getText().toString().trim());
            if (v != 0 && (v < 20 || v > max) || v < min) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            l.setError("Enter 0 or a weight from 20 to " + (int) max + " kg");
            return null;
        }
    }

    // ------------------------------------------------------------ preferences

    private void dietaryPreferences() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_dietary, null);
        Spinner spinner = v.findViewById(R.id.diet_type);
        TextView avoid = v.findViewById(R.id.diet_avoid);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, DIETS));
        repo.getPreference(p -> {
            if (p == null) return;
            int idx = DIETS.indexOf(p.dietType);
            spinner.setSelection(Math.max(0, idx));
            avoid.setText(p.avoidFoods);
        });
        new NpDialogBuilder(this)
                .setTitle("Dietary Preferences")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> repo.savePreference(
                        (String) spinner.getSelectedItem(), avoid.getText().toString().trim(),
                        ok -> UiUtils.toast(this, "Preferences saved 🥗")))
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ------------------------------------------------------------ app settings / password

    private void appSettings() {
        OptionSheet.show(this, "App Settings", null, R.drawable.ic_tune, R.color.pink_primary, R.color.pink_light,
                OptionSheet.opt(R.drawable.ic_moon, R.color.purple, R.color.lavender,
                        "Theme", "Light, dark or follow your phone", this::chooseTheme),
                OptionSheet.opt(R.drawable.ic_language, R.color.blue_water, R.color.blue_light,
                        "Language / Wika", "English or Filipino", this::chooseLanguage),
                OptionSheet.opt(R.drawable.ic_volume, R.color.leaf_dark, R.color.green_light,
                        "Pet sounds", com.nutripulse.app.utils.PetSounds.isOn(this)
                                ? "On · tap to mute Berry" : "Off · tap to hear Berry again", () -> {
                            boolean on = !com.nutripulse.app.utils.PetSounds.isOn(this);
                            com.nutripulse.app.utils.PetSounds.setOn(this, on);
                            if (on) com.nutripulse.app.utils.PetSounds.tap(this);
                            UiUtils.toast(this, on ? "Pet sounds on" : "Pet sounds off");
                        }),
                OptionSheet.opt(R.drawable.ic_lock, R.color.orange, R.color.orange_light,
                        "Change password", "Keep your account safe", this::changePassword),
                OptionSheet.opt(R.drawable.ic_email, R.color.text_muted, R.color.pink_light,
                        "Forget my email", "Clear the email remembered on this phone", () -> {
                            // Keeps the session but forgets the email shown on the login screen next time.
                            session.createSession(session.getUserId(), true, "");
                            UiUtils.toast(this, "Remembered email cleared");
                        }));
    }

    private void chooseTheme() {
        int cur = com.nutripulse.app.NutriPulseApp.getTheme(this);
        OptionSheet.show(this, "Theme", null, R.drawable.ic_moon, R.color.purple, R.color.lavender,
                OptionSheet.opt(R.drawable.ic_sun, R.color.orange, R.color.orange_light, "Light", null,
                        () -> com.nutripulse.app.NutriPulseApp.setTheme(this, 0)).selected(cur == 0),
                OptionSheet.opt(R.drawable.ic_moon, R.color.purple, R.color.lavender, "Dark", null,
                        () -> com.nutripulse.app.NutriPulseApp.setTheme(this, 1)).selected(cur == 1),
                OptionSheet.opt(R.drawable.ic_phone, R.color.text_dark, R.color.pink_light, "Follow my phone", null,
                        () -> com.nutripulse.app.NutriPulseApp.setTheme(this, 2)).selected(cur == 2));
    }

    private void chooseLanguage() {
        boolean tl = "tl".equals(com.nutripulse.app.NutriPulseApp.getLanguage());
        OptionSheet.show(this, "Language / Wika", null, R.drawable.ic_language, R.color.blue_water, R.color.blue_light,
                OptionSheet.opt(R.drawable.ic_language, R.color.blue_water, R.color.blue_light, "English", null,
                        () -> com.nutripulse.app.NutriPulseApp.setLanguage("en")).selected(!tl),
                OptionSheet.opt(R.drawable.ic_language, R.color.pink_primary, R.color.pink_light, "Filipino", null,
                        () -> com.nutripulse.app.NutriPulseApp.setLanguage("tl")).selected(tl));
    }

    private void changePassword() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_change_password, null);
        TextInputLayout curL = v.findViewById(R.id.cp_current_layout);
        TextInputLayout newL = v.findViewById(R.id.cp_new_layout);
        TextInputLayout conL = v.findViewById(R.id.cp_confirm_layout);
        AlertDialog d = new NpDialogBuilder(this)
                .setTitle("Change Password")
                .setView(v)
                .setPositiveButton("Update", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            UiUtils.clearErrors(curL, newL, conL);
            String cur = UiUtils.text(curL), nw = UiUtils.text(newL), con = UiUtils.text(conL);
            if (cur.isEmpty()) { curL.setError("Required"); return; }
            String problem = ValidationUtils.passwordProblem(nw);
            if (problem != null) { newL.setError(problem); return; }
            if (!nw.equals(con)) { conL.setError("Passwords do not match"); return; }
            AuthManager.get(this).changePassword(cur, nw, new AuthManager.Callback<Void>() {
                @Override public void onSuccess(Void r) { d.dismiss(); UiUtils.toast(SettingsActivity.this, "Password updated 🔒"); }
                @Override public void onError(String m) { curL.setError(m); }
            });
        }));
        d.show();
    }

    // ------------------------------------------------------------ reminders & step counter

    private void reminders() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_reminders, null);
        bindReminder(v.findViewById(R.id.rem_meals), ReminderScheduler.MEALS);
        bindReminder(v.findViewById(R.id.rem_water), ReminderScheduler.WATER);
        bindReminder(v.findViewById(R.id.rem_streak), ReminderScheduler.STREAK);

        SwitchMaterial steps = v.findViewById(R.id.rem_steps);
        StepSensor sensor = new StepSensor(this);
        if (!sensor.isAvailable()) {
            steps.setEnabled(false);
            steps.setText("Automatic step counter\nThis phone has no step sensor");
        } else {
            steps.setChecked(sensor.isEnabled() && StepSensor.hasPermission(this));
            steps.setOnCheckedChangeListener((b, on) -> {
                if (!on) { sensor.setEnabled(false); return; }
                if (StepSensor.hasPermission(this)) {
                    sensor.setEnabled(true);
                    UiUtils.toast(this, "👟 Step counter on!");
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    pendingSwitch = steps;
                    stepPermission.launch(Manifest.permission.ACTIVITY_RECOGNITION);
                }
            });
        }
        new NpDialogBuilder(this)
                .setTitle("Notifications & Steps")
                .setView(v)
                .setPositiveButton("Done", null)
                .setOnDismissListener(d -> pendingSwitch = null)
                .show();
    }

    private void bindReminder(SwitchMaterial sw, String group) {
        sw.setChecked(ReminderScheduler.isOn(this, group) && ReminderScheduler.hasPermission(this));
        sw.setOnCheckedChangeListener((b, on) -> {
            if (!on) { ReminderScheduler.setOn(this, group, false); return; }
            if (ReminderScheduler.hasPermission(this)) {
                ReminderScheduler.setOn(this, group, true);
            } else if (Build.VERSION.SDK_INT >= 33) {
                pendingReminder = group;
                pendingSwitch = sw;
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        });
    }

    private void helpDialog() {
        new NpDialogBuilder(this)
                .setTitle("Help & Support")
                .setMessage("• Tap + to log food.\n• Tap the Hydration tile to add a cup of water.\n"
                        + "• Complete Today's Goals and weekly challenges to earn EXP and coins.\n"
                        + "• Berry evolves at Level 5 and Level 10.\n"
                        + "• Forgot your password? Use 'Forgot Password' on the login screen.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Replay tour", (d, w) -> replayTour())
                .show();
    }

    private void replayTour() {
        OnboardingActivity.reset(this, session.getUserId());
        startActivity(new Intent(this, OnboardingActivity.class));
    }

    // ------------------------------------------------------------ cloud

    private void cloudDialog() {
        if (!Cloud.isReady(this)) {
            info("Cloud not set up yet ☁️", "NutriPulse is running in offline mode: everything is saved on this phone.\n\n"
                    + "To turn on cloud login, password reset emails, backup and AI chat, add Firebase to the "
                    + "project (see FIREBASE_SETUP.md).");
            return;
        }
        FirebaseUser fu = Cloud.user(this);
        if (fu == null) {
            info("Not connected ☁️", "This account isn't connected to the cloud yet (it may have been created offline).\n\n"
                    + "Log out, then log in again while online to connect it.");
            return;
        }
        long last = CloudBackup.lastBackup(this, session.getUserId());
        String when = last == 0 ? "never" : android.text.format.DateUtils.getRelativeTimeSpanString(last).toString();
        new NpDialogBuilder(this)
                .setTitle("Cloud Account ☁️")
                .setMessage("Signed in as " + fu.getEmail() + "\nLast backup: " + when + "\n\n"
                        + "Your data is backed up automatically. Log in on another phone and it comes with you. "
                        + "Only you can read your backup.")
                .setPositiveButton("Back up now", (d, w) -> {
                    UiUtils.toast(this, "Backing up…");
                    CloudBackup.backup(this, session.getUserId(), (ok, msg) -> UiUtils.toast(this, msg));
                })
                .setNegativeButton("Close", null)
                .show();
    }

    // ------------------------------------------------------------ logout

    private void confirmLogout() {
        new NpDialogBuilder(this)
                .setTitle(R.string.logout)
                .setMessage(R.string.logout_confirm)
                .setPositiveButton(R.string.logout, (d, w) -> {
                    if (Cloud.user(this) != null) {
                        // Save the latest changes to the cloud first (best effort, max a few seconds)
                        UiUtils.toast(this, "Saving your data to the cloud…");
                        final boolean[] done = {false};
                        Runnable finish = () -> { if (!done[0]) { done[0] = true; doLogout(); } };
                        CloudBackup.backup(this, session.getUserId(), (ok, msg) -> finish.run());
                        com.nutripulse.app.utils.AppExecutors.mainDelayed(finish, 8000);
                        return;
                    }
                    doLogout();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void doLogout() {
        AuthManager.get(this).logout();   // clears the session only, data is kept
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private void info(String title, String msg) {
        new NpDialogBuilder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }
}
