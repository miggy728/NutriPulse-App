package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.nutripulse.app.models.User;

@Dao
public interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(User user);

    @Update
    void update(User user);

    @Query("SELECT * FROM users WHERE email = :email COLLATE NOCASE LIMIT 1")
    User findByEmail(String email);

    @Query("SELECT * FROM users WHERE username = :username COLLATE NOCASE LIMIT 1")
    User findByUsername(String username);

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    User findById(long id);

    @Query("SELECT COUNT(*) FROM users WHERE email = :email COLLATE NOCASE")
    int countEmail(String email);

    @Query("SELECT COUNT(*) FROM users WHERE username = :username COLLATE NOCASE")
    int countUsername(String username);

    @Query("UPDATE users SET passwordHash = :hash, passwordSalt = :salt WHERE id = :id")
    void updatePassword(long id, String hash, String salt);
}
