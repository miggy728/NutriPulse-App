package com.nutripulse.app.auth;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

import androidx.appcompat.app.AppCompatActivity;

import com.nutripulse.app.R;
import com.nutripulse.app.ui.HomeActivity;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.SessionManager;

/** Animated splash that decides where to go: Home (valid session) or Login. */
@SuppressLint("CustomSplashScreen")
public class SplashScreenActivity extends AppCompatActivity {

    private static final long SPLASH_MS = 1800;
    private boolean navigated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        animate();
        AppExecutors.mainDelayed(this::route, SPLASH_MS);
    }

    private void animate() {
        View mascot = findViewById(R.id.splash_mascot);
        View logo = findViewById(R.id.splash_logo_row);
        View tagline = findViewById(R.id.splash_tagline);

        logo.setAlpha(0f); logo.setTranslationY(-30f);
        logo.animate().alpha(1f).translationY(0f).setDuration(600).start();
        tagline.setAlpha(0f);
        tagline.animate().alpha(1f).setStartDelay(300).setDuration(600).start();

        mascot.setScaleX(0.3f); mascot.setScaleY(0.3f);
        mascot.animate().scaleX(1f).scaleY(1f).setDuration(700)
                .setInterpolator(new OvershootInterpolator(2f)).start();

        ObjectAnimator bob = ObjectAnimator.ofFloat(mascot, "translationY", 0f, -18f);
        bob.setDuration(650);
        bob.setRepeatMode(ValueAnimator.REVERSE);
        bob.setRepeatCount(ValueAnimator.INFINITE);
        bob.setInterpolator(new AccelerateDecelerateInterpolator());
        bob.setStartDelay(700);
        bob.start();

        int[] dots = {R.id.dot1, R.id.dot2, R.id.dot3};
        for (int i = 0; i < dots.length; i++) {
            ObjectAnimator a = ObjectAnimator.ofFloat(findViewById(dots[i]), "alpha", 0.25f, 1f);
            a.setDuration(450);
            a.setStartDelay(i * 150L);
            a.setRepeatMode(ValueAnimator.REVERSE);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.start();
        }
    }

    private void route() {
        if (navigated || isFinishing()) return;
        navigated = true;
        SessionManager session = new SessionManager(this);
        Class<?> next;
        if (session.canRestoreSession()) {
            next = HomeActivity.class;
        } else {
            session.logout();   // a non-remembered or expired session ends on cold start
            next = LoginActivity.class;
        }
        startActivity(new Intent(this, next));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
