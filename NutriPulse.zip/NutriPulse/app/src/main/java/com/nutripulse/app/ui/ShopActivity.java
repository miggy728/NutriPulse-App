package com.nutripulse.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nutripulse.app.R;
import com.nutripulse.app.data.PetLook;
import com.nutripulse.app.data.ShopItems;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.views.PetAnimator;
import com.nutripulse.app.views.AccessoryEditor;

import java.util.ArrayList;
import java.util.List;

/** Berry Shop: spend coins on hats, glasses and room themes, with a live preview. */
public class ShopActivity extends BaseAuthActivity {

    private String slot = ShopItems.HAT;
    private Pet pet;
    private ShopItems.Item selected;
    private final List<ShopItems.Item> items = new ArrayList<>();

    private TextView coins, tabHat, tabFace, tabRoom, hatView, faceView;
    private View stage, crown;
    private MaterialButton action;
    private PetAnimator petAnim;
    private RecyclerView.Adapter<VH> adapter;
    private AccessoryEditor editor;
    private TextView adjust;
    private int previewHat, previewFace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_shop);

        coins = findViewById(R.id.shop_coins);
        tabHat = findViewById(R.id.shop_tab_hat);
        tabFace = findViewById(R.id.shop_tab_face);
        tabRoom = findViewById(R.id.shop_tab_room);
        hatView = findViewById(R.id.shop_hat);
        faceView = findViewById(R.id.shop_face);
        stage = findViewById(R.id.shop_stage);
        crown = findViewById(R.id.shop_crown);
        action = findViewById(R.id.shop_action);
        ImageView mascot = findViewById(R.id.shop_mascot);
        petAnim = new PetAnimator((FrameLayout) stage, findViewById(R.id.shop_pet_body), mascot,
                findViewById(R.id.shop_shadow));
        mascot.setOnClickListener(v -> petAnim.onTap());
        adjust = findViewById(R.id.shop_adjust);
        editor = new AccessoryEditor((FrameLayout) stage, hatView, faceView, session.getUserId(),
                new AccessoryEditor.Callbacks() {
                    @Override public void onEditStart() {
                        petAnim.stop();
                        adjust.setVisibility(View.GONE);
                        action.setEnabled(false);
                    }
                    @Override public void onEditEnd() {
                        petAnim.start();
                        refresh();
                    }
                });
        adjust.setOnClickListener(v -> editor.start(previewHat, previewFace));

        findViewById(R.id.shop_back).setOnClickListener(v -> finish());
        tabHat.setOnClickListener(v -> setSlot(ShopItems.HAT));
        tabFace.setOnClickListener(v -> setSlot(ShopItems.FACE));
        tabRoom.setOnClickListener(v -> setSlot(ShopItems.ROOM));
        action.setOnClickListener(v -> onAction());

        RecyclerView list = findViewById(R.id.shop_list);
        list.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new RecyclerView.Adapter<VH>() {
            @NonNull @Override
            public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
                return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_shop, p, false));
            }
            @Override public void onBindViewHolder(@NonNull VH h, int i) { h.bind(items.get(i)); }
            @Override public int getItemCount() { return items.size(); }
        };
        list.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (noSession()) return;
        petAnim.start();
        repo.getPet(p -> {
            if (p == null) { redirectToLogin(); return; }
            pet = p;
            setSlot(slot);
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (editor != null && editor.isEditing()) editor.finish(true);
        if (petAnim != null) petAnim.stop();
    }

    private void setSlot(String s) {
        slot = s;
        tabHat.setSelected(ShopItems.HAT.equals(s));
        tabFace.setSelected(ShopItems.FACE.equals(s));
        tabRoom.setSelected(ShopItems.ROOM.equals(s));
        tabLabel(tabHat, R.drawable.ic_bow, getString(R.string.ui_hats));
        tabLabel(tabFace, R.drawable.ic_glasses, getString(R.string.ui_glasses));
        tabLabel(tabRoom, R.drawable.ic_home, getString(R.string.ui_rooms));
        items.clear();
        items.addAll(ShopItems.bySlot(s));
        selected = null;
        int equipped = equippedIn(s);
        for (ShopItems.Item i : items) if (i.id == equipped) selected = i;
        refresh();
    }

    private int equippedIn(String s) {
        if (pet == null) return 0;
        return ShopItems.HAT.equals(s) ? pet.hat : ShopItems.FACE.equals(s) ? pet.face : pet.room;
    }

    private void refresh() {
        if (pet == null) return;
        coins.setText(String.valueOf(pet.coins));
        // Preview: the selected item replaces what is equipped in this slot
        int hat = pet.hat, face = pet.face, room = pet.room;
        if (selected != null) {
            if (ShopItems.HAT.equals(slot)) hat = selected.id;
            else if (ShopItems.FACE.equals(slot)) face = selected.id;
            else room = selected.id;
        }
        PetLook.apply(hat, face, room, pet.getStage() >= 2, findViewById(R.id.shop_room),
                hatView, faceView, crown);
        previewHat = hat;
        previewFace = face;
        adjust.setVisibility((hat != 0 || face != 0) && !editor.isEditing() ? View.VISIBLE : View.GONE);

        if (selected == null) {
            action.setText("Pick an item to try it on");
            action.setEnabled(false);
        } else if (!pet.owns(selected.id)) {
            boolean afford = pet.coins >= selected.price;
            action.setEnabled(true);
            action.setText(afford ? "Buy " + selected.name + " for " + selected.price + " coins"
                    : "Need 🪙 " + (selected.price - pet.coins) + " more");
        } else if (equippedIn(slot) == selected.id) {
            action.setEnabled(true);
            action.setText(ShopItems.ROOM.equals(slot) ? "Use default room" : "Take it off");
        } else {
            action.setEnabled(true);
            action.setText(ShopItems.ROOM.equals(slot) ? "Use this room" : "Wear it!");
        }
        adapter.notifyDataSetChanged();
    }

    private void onAction() {
        if (selected == null || pet == null) return;
        final ShopItems.Item item = selected;
        if (!pet.owns(item.id)) {
            if (pet.coins < item.price) {
                new NpDialogBuilder(this)
                        .setTitle("Not enough coins")
                        .setMessage("You earn 1 coin for every EXP. Log healthy meals, drink water and finish "
                                + "your daily goals to earn more!")
                        .setPositiveButton("OK", null).show();
                return;
            }
            new NpDialogBuilder(this)
                    .setTitle("Buy " + item.name + "?")
                    .setMessage("This costs " + item.price + " coins. You have " + pet.coins + ".")
                    .setPositiveButton("Buy", (d, w) -> repo.buyItem(item.id, err -> {
                        if (err == null || !err.isEmpty()) {
                            UiUtils.toast(this, err == null ? "Something went wrong" : err);
                            return;
                        }
                        com.nutripulse.app.utils.PetSounds.coin(this);
                        petAnim.playPlay();
                        UiUtils.toast(this, "Yay! Berry loves the " + item.name + "! 💗");
                        reloadPet();
                    }))
                    .setNegativeButton("Cancel", null).show();
        } else {
            int newId = equippedIn(slot) == item.id ? 0 : item.id;
            repo.equip(slot, newId, p -> {
                if (p == null) return;
                pet = p;
                if (newId == 0) selected = null; else petAnim.onTap();
                refresh();
            });
        }
    }

    private void reloadPet() {
        repo.getPet(p -> { if (p != null) { pet = p; refresh(); } });
    }

    private class VH extends RecyclerView.ViewHolder {
        final TextView emoji, name, price;

        VH(View v) {
            super(v);
            emoji = v.findViewById(R.id.shop_item_emoji);
            name = v.findViewById(R.id.shop_item_name);
            price = v.findViewById(R.id.shop_item_price);
        }

        void bind(ShopItems.Item item) {
            if (item.roomDrawable != 0) {
                emoji.setText("");
                emoji.setForeground(null);
                emoji.setBackgroundResource(item.roomDrawable);
                emoji.setClipToOutline(true);
            } else if (item.art != 0) {
                emoji.setText("");
                emoji.setBackgroundResource(R.drawable.bg_card_pink);
                int inset = UiUtils.dp(emoji.getContext(), 6);
                int side = Math.max(0, (UiUtils.dp(emoji.getContext(), 78) - UiUtils.dp(emoji.getContext(), 58)) / 2);
                emoji.setForeground(new android.graphics.drawable.InsetDrawable(
                        ContextCompat.getDrawable(emoji.getContext(), item.art), side + inset, inset, side + inset, inset));
            } else {
                emoji.setForeground(null);
                emoji.setText(item.emoji);
                emoji.setBackgroundResource(R.drawable.bg_card_pink);
            }
            name.setText(item.name);
            boolean owned = pet != null && pet.owns(item.id);
            boolean equipped = owned && equippedIn(slot) == item.id;
            price.setText(equipped ? "✓ Using" : owned ? "Owned" : String.valueOf(item.price));
            price.setCompoundDrawablesRelativeWithIntrinsicBounds(equipped || owned ? 0 : R.drawable.ics_coin, 0, 0, 0);
            price.setCompoundDrawablePadding(UiUtils.dp(price.getContext(), 4));
            price.setTextColor(ContextCompat.getColor(ShopActivity.this,
                    equipped ? R.color.green_ok : owned ? R.color.purple : R.color.pink_dark));
            boolean isSel = selected != null && selected.id == item.id;
            itemView.setBackgroundResource(isSel ? R.drawable.bg_card_pink : R.drawable.bg_tile);
            itemView.setOnClickListener(v -> {
                selected = item;
                refresh();
            });
        }
    }

    /** Tab text with its icon centred right next to it (white when selected). */
    private void tabLabel(TextView tab, int icon, String label) {
        android.graphics.drawable.Drawable d = ContextCompat.getDrawable(this, icon);
        if (d == null) { tab.setText(label); return; }
        d = d.mutate();
        int size = UiUtils.dp(this, 18);
        d.setBounds(0, 0, size, size);
        d.setTint(ContextCompat.getColor(this, tab.isSelected() ? R.color.white : R.color.text_dark));
        android.text.SpannableString text = new android.text.SpannableString("  " + label);
        text.setSpan(new CenteredIcon(d), 0, 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tab.setText(text);
    }

    /** ImageSpan that sits on the text's vertical centre (ALIGN_CENTER needs API 29). */
    private static final class CenteredIcon extends android.text.style.ImageSpan {
        CenteredIcon(android.graphics.drawable.Drawable d) { super(d); }

        @Override
        public void draw(@androidx.annotation.NonNull android.graphics.Canvas canvas, CharSequence text, int start,
                         int end, float x, int top, int y, int bottom, @androidx.annotation.NonNull android.graphics.Paint paint) {
            android.graphics.drawable.Drawable d = getDrawable();
            android.graphics.Paint.FontMetricsInt fm = paint.getFontMetricsInt();
            int transY = y + (fm.descent + fm.ascent) / 2 - d.getBounds().height() / 2;
            canvas.save();
            canvas.translate(x, transY);
            d.draw(canvas);
            canvas.restore();
        }
    }
}
