package com.nutripulse.app.data;

import com.nutripulse.app.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Everything Berry can wear or decorate with. Ids must stay below 63 (stored as bit flags). */
public final class ShopItems {
    public static final String HAT = "hat", FACE = "face", ROOM = "room";

    public static final class Item {
        public final int id;
        public final String slot, name, emoji;
        public final int price;
        public final int roomDrawable;   // only for ROOM items
        public final int art;            // illustrated drawable (hats and glasses)

        Item(int id, String slot, String name, String emoji, int price, int roomDrawable) {
            this(id, slot, name, emoji, price, roomDrawable, 0);
        }

        Item(int id, String slot, String name, String emoji, int price, int roomDrawable, int art) {
            this.id = id; this.slot = slot; this.name = name; this.emoji = emoji;
            this.price = price; this.roomDrawable = roomDrawable; this.art = art;
        }
    }

    private ShopItems() {}

    public static final List<Item> ALL = Arrays.asList(
            new Item(1, HAT, "Pink Bow", "🎀", 50, 0, R.drawable.acc_bow),
            new Item(2, HAT, "Sakura Flower", "🌸", 80, 0, R.drawable.acc_sakura),
            new Item(3, HAT, "Baseball Cap", "🧢", 100, 0, R.drawable.acc_cap),
            new Item(4, HAT, "Sun Hat", "👒", 120, 0, R.drawable.acc_sunhat),
            new Item(5, HAT, "Graduation Cap", "🎓", 200, 0, R.drawable.acc_gradcap),
            new Item(6, HAT, "Top Hat", "🎩", 250, 0, R.drawable.acc_tophat),
            new Item(7, HAT, "Party Hat", "🥳", 150, 0, R.drawable.acc_partyhat),
            new Item(20, FACE, "Smart Glasses", "👓", 100, 0, R.drawable.acc_glasses),
            new Item(21, FACE, "Cool Shades", "🕶️", 150, 0, R.drawable.acc_shades),
            new Item(40, ROOM, "Lemon Kitchen", "🍋", 80, R.drawable.room_lemon),
            new Item(41, ROOM, "Mint Garden", "🌿", 100, R.drawable.room_mint),
            new Item(42, ROOM, "Rainbow Sky", "🌈", 100, R.drawable.room_sky),
            new Item(43, ROOM, "Sunset Beach", "🌅", 150, R.drawable.room_sunset),
            new Item(44, ROOM, "Starry Night", "🌙", 200, R.drawable.room_night)
    );

    public static List<Item> bySlot(String slot) {
        List<Item> out = new ArrayList<>();
        for (Item i : ALL) if (i.slot.equals(slot)) out.add(i);
        return out;
    }

    /** The free room everyone starts with. */
    public static final int DEFAULT_ROOM = R.drawable.room_sakura;

    public static Item find(int id) {
        for (Item i : ALL) if (i.id == id) return i;
        return null;
    }
}
