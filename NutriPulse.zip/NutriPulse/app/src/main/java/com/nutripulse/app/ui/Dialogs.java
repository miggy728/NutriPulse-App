package com.nutripulse.app.ui;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.utils.UiUtils;

import java.util.Locale;

/**
 * Modern input dialogs: coloured icon badge, title + helper line, rounded field with a unit,
 * quick-pick chips and two big buttons. The look is chosen automatically from the title, so every
 * existing call (steps, weight, water, height, servings, notes, pet name, barcode) gets it.
 */
public final class Dialogs {
    public interface NumberCallback { void onNumber(float value); }
    public interface TextCallback { void onText(String value); }

    private Dialogs() {}

    /** How a dialog looks: icon, colours, unit and quick values. */
    private static final class Look {
        int icon = R.drawable.ic_edit;
        int tint = R.color.pink_primary;
        int bg = R.color.pink_light;
        String subtitle;
        String suffix;
        float[] quick;
    }

    private static Look lookFor(String title, String hint) {
        String t = (title + " " + hint).toLowerCase(Locale.ROOT);
        Look l = new Look();
        if (t.contains("step")) {
            l.icon = R.drawable.ic_walk; l.tint = R.color.leaf_dark; l.bg = R.color.green_light;
            l.subtitle = "Every step counts!"; l.suffix = "steps";
            l.quick = new float[]{1000, 2500, 5000, 10000};
        } else if (t.contains("weight")) {
            l.icon = R.drawable.ic_scale; l.tint = R.color.purple; l.bg = R.color.lavender;
            l.subtitle = "Track it to see your progress"; l.suffix = "kg";
        } else if (t.contains("water") || t.contains("cup")) {
            l.icon = R.drawable.ic_drop; l.tint = R.color.blue_water; l.bg = R.color.blue_light;
            l.subtitle = "Stay hydrated"; l.suffix = "cups";
            l.quick = new float[]{1, 2, 3, 4};
        } else if (t.contains("height")) {
            l.icon = R.drawable.ic_person; l.tint = R.color.purple; l.bg = R.color.lavender;
            l.subtitle = "Used to calculate your BMI"; l.suffix = "cm";
        } else if (t.contains("serving")) {
            l.icon = R.drawable.ic_utensils; l.tint = R.color.orange; l.bg = R.color.orange_light;
            l.subtitle = "How much did you have?"; l.suffix = "servings";
            l.quick = new float[]{0.5f, 1, 1.5f, 2};
        } else if (t.contains("barcode")) {
            l.icon = R.drawable.ic_barcode; l.tint = R.color.text_dark; l.bg = R.color.pink_light;
            l.subtitle = "Type the numbers under the barcode";
        } else if (t.contains("pet") || t.contains("name")) {
            l.icon = R.drawable.ic_heart; l.tint = R.color.pink_primary; l.bg = R.color.pink_light;
            l.subtitle = "Give your buddy a cute name";
        } else if (t.contains("note")) {
            l.icon = R.drawable.ic_note; l.tint = R.color.pink_primary; l.bg = R.color.pink_light;
        }
        return l;
    }

    public static void number(Activity a, String title, String hint, boolean decimal,
                              float min, float max, NumberCallback cb) {
        Look look = lookFor(title, hint);
        Parts p = build(a, title, hint, look);
        p.input.setInputType(InputType.TYPE_CLASS_NUMBER | (decimal ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0));
        if (look.quick != null) {
            p.quickScroll.setVisibility(View.VISIBLE);
            for (float q : look.quick) {
                if (q < min || q > max) continue;
                MaterialButton chip = chip(a, fmtThousands(q));
                chip.setOnClickListener(v -> {
                    p.input.setText(fmt(q));
                    p.input.setSelection(p.input.length());
                    p.layout.setError(null);
                });
                p.quick.addView(chip);
            }
        }
        Runnable save = () -> {
            String s = p.input.getText() == null ? "" : p.input.getText().toString().trim().replace(",", "");
            try {
                float value = Float.parseFloat(s);
                if (value < min || value > max) {
                    p.layout.setError("Enter a value from " + fmt(min) + " to " + fmt(max));
                    return;
                }
                p.dialog.dismiss();
                cb.onNumber(value);
            } catch (NumberFormatException e) {
                p.layout.setError("Please enter a number");
            }
        };
        wire(p, save);
    }

    public static void text(Activity a, String title, String hint, String initial, int maxLen, TextCallback cb) {
        Look look = lookFor(title, hint);
        Parts p = build(a, title, hint, look);
        boolean digits = title.toLowerCase(Locale.ROOT).contains("barcode");
        p.input.setInputType(digits ? InputType.TYPE_CLASS_NUMBER
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        p.input.setTextSize(17);
        p.layout.setCounterEnabled(true);
        p.layout.setCounterMaxLength(maxLen);
        if (initial != null) {
            p.input.setText(initial);
            p.input.setSelection(p.input.length());
        }
        Runnable save = () -> {
            String s = p.input.getText() == null ? "" : p.input.getText().toString().trim();
            if (s.isEmpty()) { p.layout.setError("This can't be empty"); return; }
            if (s.length() > maxLen) { p.layout.setError("Too long"); return; }
            p.dialog.dismiss();
            cb.onText(s);
        };
        wire(p, save);
    }

    // ------------------------------------------------------------------ building blocks

    private static final class Parts {
        AlertDialog dialog;
        TextInputLayout layout;
        TextInputEditText input;
        LinearLayout quick;
        View quickScroll;
        MaterialButton saveButton, cancelButton;
    }

    private static Parts build(Activity a, String title, String hint, Look look) {
        View v = LayoutInflater.from(a).inflate(R.layout.dialog_number, null, false);
        Parts p = new Parts();
        p.layout = v.findViewById(R.id.dn_layout);
        p.input = v.findViewById(R.id.dn_input);
        p.quick = v.findViewById(R.id.dn_quick);
        p.quickScroll = v.findViewById(R.id.dn_quick_scroll);
        p.saveButton = v.findViewById(R.id.dn_save);
        p.cancelButton = v.findViewById(R.id.dn_cancel);

        ((TextView) v.findViewById(R.id.dn_title)).setText(title);
        TextView sub = v.findViewById(R.id.dn_subtitle);
        if (look.subtitle != null) { sub.setText(look.subtitle); sub.setVisibility(View.VISIBLE); }
        ImageView icon = v.findViewById(R.id.dn_icon);
        icon.setImageResource(look.icon);
        icon.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(a, look.tint)));
        v.findViewById(R.id.dn_icon_bg).setBackgroundTintList(
                ColorStateList.valueOf(ContextCompat.getColor(a, look.bg)));
        p.layout.setHint(hint);
        if (look.suffix != null) p.layout.setSuffixText(look.suffix);

        p.dialog = new NpDialogBuilder(a).setView(v).create();
        return p;
    }

    private static void wire(Parts p, Runnable save) {
        p.saveButton.setOnClickListener(v -> save.run());
        p.cancelButton.setOnClickListener(v -> p.dialog.dismiss());
        p.input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        p.input.setOnEditorActionListener((tv, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_DONE) { save.run(); return true; }
            return false;
        });
        p.dialog.setOnShowListener(d -> {
            p.input.requestFocus();
            if (p.dialog.getWindow() != null) {
                p.dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            }
        });
        p.dialog.show();
    }

    private static MaterialButton chip(Activity a, String label) {
        MaterialButton b = new MaterialButton(a, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(ContextCompat.getColor(a, R.color.pink_dark));
        b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(a, R.color.pink_light)));
        b.setStrokeWidth(0);
        b.setCornerRadius(UiUtils.dp(a, 18));
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setMinHeight(UiUtils.dp(a, 36));
        b.setMinimumHeight(UiUtils.dp(a, 36));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        int ph = UiUtils.dp(a, 14);
        b.setPadding(ph, 0, ph, 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, UiUtils.dp(a, 36));
        lp.setMarginEnd(UiUtils.dp(a, 8));
        b.setLayoutParams(lp);
        return b;
    }

    static android.widget.FrameLayout wrap(Activity a, View v) {
        android.widget.FrameLayout f = new android.widget.FrameLayout(a);
        int p = UiUtils.dp(a, 22);
        f.setPadding(p, UiUtils.dp(a, 8), p, 0);
        f.addView(v);
        return f;
    }

    private static String fmt(float f) {
        return f == (long) f ? String.valueOf((long) f) : String.valueOf(f);
    }

    private static String fmtThousands(float f) {
        return f == (long) f ? String.format(Locale.US, "%,d", (long) f) : String.valueOf(f);
    }
}
