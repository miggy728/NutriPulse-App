package com.nutripulse.app.utils;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;

import androidx.core.content.ContextCompat;

/**
 * Reads the phone's built-in step counter (TYPE_STEP_COUNTER).
 *
 * That sensor reports total steps since the phone was last restarted, so we remember a
 * baseline for each day and work out today's steps from it (handling restarts too).
 * Steps taken while the app is closed are still counted the next time it opens.
 */
public class StepSensor implements SensorEventListener {

    public interface Listener { void onTodaySteps(long steps); }

    private static final String PREFS = "nutripulse_steps";
    public static final String KEY_ENABLED = "auto_steps_enabled";

    private final Context app;
    private final SharedPreferences prefs;
    private final SensorManager sm;
    private final Sensor sensor;
    private Listener listener;

    public StepSensor(Context context) {
        app = context.getApplicationContext();
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sm = (SensorManager) app.getSystemService(Context.SENSOR_SERVICE);
        sensor = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
    }

    public boolean isAvailable() { return sensor != null; }

    public static boolean hasPermission(Context c) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                || ContextCompat.checkSelfPermission(c, Manifest.permission.ACTIVITY_RECOGNITION)
                == PackageManager.PERMISSION_GRANTED;
    }

    public boolean isEnabled() { return prefs.getBoolean(KEY_ENABLED, false); }

    public void setEnabled(boolean on) { prefs.edit().putBoolean(KEY_ENABLED, on).apply(); }

    public boolean canRun() { return isAvailable() && isEnabled() && hasPermission(app); }

    public void start(Listener l) {
        if (!canRun()) return;
        listener = l;
        sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
    }

    public void stop() {
        if (sm != null) sm.unregisterListener(this);
        listener = null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        record((long) event.values[0]);
        if (listener != null) listener.onTodaySteps(todaySteps());
    }

    @Override public void onAccuracyChanged(Sensor s, int accuracy) { }

    /** Updates the stored baseline with a new raw "steps since restart" reading. */
    private void record(long raw) {
        String today = DateUtils.todayKey();
        String yesterday = DateUtils.daysAgoKey(1);
        String date = prefs.getString("date", "");
        long base = prefs.getLong("base", -1);
        long last = prefs.getLong("last", -1);
        long acc = prefs.getLong("acc", 0);

        if (!today.equals(date)) {
            // New day: if we saw the counter yesterday, steps since then belong to today.
            base = (yesterday.equals(date) && last >= 0 && last <= raw) ? last : raw;
            acc = 0;
            date = today;
        } else if (raw < last) {
            // Phone restarted: keep what we had and start counting from zero again.
            acc += Math.max(0, last - base);
            base = 0;
        }
        prefs.edit().putString("date", date).putLong("base", base)
                .putLong("last", raw).putLong("acc", acc).apply();
    }

    public long todaySteps() {
        if (!DateUtils.todayKey().equals(prefs.getString("date", ""))) return 0;
        long base = prefs.getLong("base", 0), last = prefs.getLong("last", 0);
        return prefs.getLong("acc", 0) + Math.max(0, last - base);
    }

    /** Steps the sensor counted today that have not been saved for this user yet. */
    public int unsavedSteps(long userId) {
        long saved = prefs.getLong(savedKey(userId), 0);
        return (int) Math.max(0, todaySteps() - saved);
    }

    public void markSaved(long userId) {
        prefs.edit().putLong(savedKey(userId), todaySteps()).apply();
    }

    private static String savedKey(long userId) { return "saved_" + userId + "_" + DateUtils.todayKey(); }
}
