package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "meal_records",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "dateKey"})})
public class MealRecord {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String foodName = "";
    public String emoji;
    @NonNull public String category = "Meal"; // Meal, Snack, Drink
    public float servings = 1f;
    public int calories;
    public float protein;
    public float carbs;
    public float fat;
    public boolean healthy;
    @NonNull public String dateKey = "";       // yyyy-MM-dd
    public long timestamp;
}
