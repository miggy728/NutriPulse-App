package com.nutripulse.app.reminders;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.nutripulse.app.R;
import com.nutripulse.app.auth.SplashScreenActivity;
import com.nutripulse.app.database.AppDatabase;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.User;
import com.nutripulse.app.utils.AppExecutors;
import com.nutripulse.app.utils.DateUtils;
import com.nutripulse.app.utils.SessionManager;

import java.util.List;

/**
 * Shows one reminder. It checks the logged-in user's data first, so Berry stays quiet
 * when the reminder isn't needed (e.g. water goal already reached).
 */
public class ReminderReceiver extends BroadcastReceiver {
    static final String EXTRA_TYPE = "type";

    @Override
    public void onReceive(Context context, Intent intent) {
        final String type = intent.getStringExtra(EXTRA_TYPE);
        final Context app = context.getApplicationContext();
        final PendingResult pending = goAsync();
        AppExecutors.io(() -> {
            try {
                String[] msg = buildMessage(app, type);
                if (msg != null) show(app, type, msg[0], msg[1]);
            } catch (Exception ignored) {
            } finally {
                pending.finish();
            }
        });
    }

    /** Returns {title, text} or null to skip. */
    private static String[] buildMessage(Context c, String type) {
        long uid = new SessionManager(c).getUserId();
        if (uid <= 0 || type == null) return null;                 // nobody logged in: stay quiet
        AppDatabase db = AppDatabase.get(c);
        User u = db.userDao().findById(uid);
        if (u == null) return null;
        String today = DateUtils.todayKey();
        List<MealRecord> meals = db.mealDao().getMealsForDay(uid, today);
        String name = u.getFirstName();

        switch (type) {
            case "water": {
                int cups = db.trackingDao().waterForDay(uid, today);
                if (cups >= u.hydrationGoal) return null;
                return new String[]{"💧 Water break, " + name + "!",
                        "You've had " + cups + " of " + u.hydrationGoal + " cups. Berry is thirsty too!"};
            }
            case "streak": {
                if (!meals.isEmpty()) return null;
                List<String> days = db.mealDao().loggedDays(uid);
                boolean hadYesterday = !days.isEmpty() && days.get(0).equals(DateUtils.daysAgoKey(1));
                return new String[]{hadYesterday ? "🔥 Don't break your streak!" : "🍓 Berry misses you!",
                        "You haven't logged any food today. Tap to log a meal before bed."};
            }
            default: {
                // Skip if something was logged in the last 2 hours
                if (!meals.isEmpty() && System.currentTimeMillis() - meals.get(0).timestamp < 2 * 60 * 60 * 1000L) {
                    return null;
                }
                String meal = type.substring(0, 1).toUpperCase() + type.substring(1);
                return new String[]{"🍽️ " + meal + " time, " + name + "!",
                        "Don't forget to log your " + type + ". Berry is hungry for healthy food! 💗"};
            }
        }
    }

    private static void show(Context c, String type, String title, String text) {
        if (!ReminderScheduler.hasPermission(c)) return;
        ReminderScheduler.createChannel(c);
        Intent open = new Intent(c, SplashScreenActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent tap = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, ReminderScheduler.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_heart)
                .setColor(0xFFFF4F8B)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try {
            NotificationManagerCompat.from(c).notify(type.hashCode(), b.build());
        } catch (SecurityException ignored) { }
    }
}
