package com.nutripulse.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.material.button.MaterialButton;
import com.nutripulse.app.R;
import com.nutripulse.app.utils.UiUtils;

/** A short "Meet Berry" tour shown the first time each user opens the app. Swipe or tap Next. */
public class OnboardingActivity extends BaseAuthActivity {

    private static final String PREFS = "nutripulse_onboarding";

    private static final int[][] PAGES = {
            // icon, icon colour, title, text
            {R.drawable.ic_wave, R.color.pink_primary, R.string.onb_title_1, R.string.onb_text_1},
            {R.drawable.ic_add, R.color.pink_primary, R.string.onb_title_2, R.string.onb_text_2},
            {R.drawable.ic_drop, R.color.blue_water, R.string.onb_title_3, R.string.onb_text_3},
            {R.drawable.ic_note, R.color.orange, R.string.onb_title_4, R.string.onb_text_4},
            {R.drawable.ic_bag, R.color.purple, R.string.onb_title_5, R.string.onb_text_5},
            {R.drawable.ic_chat, R.color.pink_primary, R.string.onb_title_6, R.string.onb_text_6},
    };
    private static final int[] FACES = {R.drawable.mascot_berry, R.drawable.mascot_berry_happy,
            R.drawable.mascot_berry, R.drawable.mascot_berry_happy, R.drawable.mascot_berry, R.drawable.mascot_berry_happy};

    private int page = 0;
    private GestureDetector swipe;

    public static boolean isDone(Context c, long userId) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("done_" + userId, false);
    }

    public static void reset(Context c, long userId) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("done_" + userId).apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (noSession()) return;
        setContentView(R.layout.activity_onboarding);
        findViewById(R.id.onb_skip).setOnClickListener(v -> finishTour());
        findViewById(R.id.onb_next).setOnClickListener(v -> {
            if (page < PAGES.length - 1) go(page + 1); else finishTour();
        });
        findViewById(R.id.onb_berry).setOnClickListener(UiUtils::bounce);

        swipe = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(@NonNull MotionEvent e) { return true; }
            @Override
            public boolean onFling(MotionEvent e1, @NonNull MotionEvent e2, float vx, float vy) {
                if (e1 == null || Math.abs(vx) < Math.abs(vy)) return false;
                if (vx < 0 && page < PAGES.length - 1) go(page + 1);
                else if (vx > 0 && page > 0) go(page - 1);
                return true;
            }
        });
        findViewById(R.id.onb_root).setOnTouchListener((v, e) -> swipe.onTouchEvent(e));
        show(0, false);
    }

    @Override
    public void onBackPressed() {
        if (page > 0) go(page - 1); else super.onBackPressed();
    }

    private void go(int target) {
        View content = findViewById(R.id.onb_content);
        float dir = target > page ? -1 : 1;
        content.animate().alpha(0f).translationX(dir * UiUtils.dp(this, 40)).setDuration(150).withEndAction(() -> {
            show(target, true);
            content.setTranslationX(-dir * UiUtils.dp(this, 40));
            content.animate().alpha(1f).translationX(0f).setDuration(200).start();
        }).start();
    }

    private void show(int p, boolean bounce) {
        page = p;
        ImageView onbIcon = findViewById(R.id.onb_icon);
        onbIcon.setImageResource(PAGES[p][0]);
        onbIcon.setImageTintList(android.content.res.ColorStateList.valueOf(
                androidx.core.content.ContextCompat.getColor(this, PAGES[p][1])));
        ((TextView) findViewById(R.id.onb_title)).setText(PAGES[p][2]);
        ((TextView) findViewById(R.id.onb_text)).setText(PAGES[p][3]);
        ((android.widget.ImageView) findViewById(R.id.onb_berry)).setImageResource(FACES[p]);
        ((MaterialButton) findViewById(R.id.onb_next)).setText(
                p == PAGES.length - 1 ? R.string.onb_done : R.string.onb_next);
        LinearLayout dots = findViewById(R.id.onb_dots);
        dots.removeAllViews();
        for (int i = 0; i < PAGES.length; i++) {
            View dot = new View(this);
            int w = UiUtils.dp(this, i == p ? 22 : 8), h = UiUtils.dp(this, 8), m = UiUtils.dp(this, 4);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
            lp.setMargins(m, 0, m, 0);
            dot.setBackgroundResource(i == p ? R.drawable.bg_pill_pink : R.drawable.bg_pill);
            dots.addView(dot, lp);
        }
        if (bounce) UiUtils.bounce(findViewById(R.id.onb_berry));
    }

    private void finishTour() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("done_" + session.getUserId(), true).apply();
        finish();
    }
}
