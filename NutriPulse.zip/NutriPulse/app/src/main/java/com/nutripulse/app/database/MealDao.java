package com.nutripulse.app.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MealRecord;

import java.util.List;

/** Every query is filtered by userId so one account can never read another's meals. */
@Dao
public interface MealDao {
    @Insert
    long insertMeal(MealRecord record);

    @Query("SELECT * FROM meal_records WHERE userId = :userId AND dateKey = :dateKey ORDER BY timestamp DESC")
    List<MealRecord> getMealsForDay(long userId, String dateKey);

    @Query("SELECT COALESCE(SUM(calories),0) FROM meal_records WHERE userId = :userId AND dateKey = :dateKey")
    int caloriesForDay(long userId, String dateKey);

    @Query("SELECT COALESCE(SUM(calories),0) FROM meal_records WHERE userId = :userId AND dateKey >= :fromKey")
    int caloriesSince(long userId, String fromKey);

    @Query("SELECT COUNT(*) FROM meal_records WHERE userId = :userId")
    int countMeals(long userId);

    @Query("SELECT COUNT(*) FROM meal_records WHERE userId = :userId AND healthy = 1 AND dateKey >= :fromKey")
    int countHealthySince(long userId, String fromKey);

    @Query("SELECT foodName FROM meal_records WHERE userId = :userId AND dateKey >= :fromKey")
    List<String> namesSince(long userId, String fromKey);

    /** Days with at least one logged food, newest first (used for streaks). */
    @Query("SELECT DISTINCT dateKey FROM meal_records WHERE userId = :userId ORDER BY dateKey DESC")
    List<String> loggedDays(long userId);

    @Query("SELECT COUNT(*) FROM meal_records WHERE userId = :userId AND healthy = 1")
    int countHealthyMeals(long userId);

    @Query("SELECT COUNT(*) FROM meal_records WHERE userId = :userId AND dateKey = :dateKey AND healthy = 1")
    int countHealthyMealsForDay(long userId, String dateKey);

    @Query("SELECT dateKey AS dateKey, SUM(calories) AS total FROM meal_records WHERE userId = :userId AND dateKey >= :fromKey GROUP BY dateKey")
    List<DayTotal> dailyCalories(long userId, String fromKey);

    // ---- Meal plans ----
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insertPlan(MealPlan plan);

    @Update
    void updatePlan(MealPlan plan);

    @Query("SELECT * FROM meal_plans WHERE userId = :userId AND dateKey = :dateKey ORDER BY CASE slot WHEN 'Breakfast' THEN 0 WHEN 'Lunch' THEN 1 ELSE 2 END")
    List<MealPlan> getPlansForDay(long userId, String dateKey);

    @Query("SELECT * FROM meal_plans WHERE id = :planId AND userId = :userId LIMIT 1")
    MealPlan getPlan(long userId, long planId);

    // ---- Meal notes (always filtered by userId) ----
    @Insert
    long insertNote(MealNote note);

    @Query("SELECT * FROM meal_notes WHERE userId = :userId AND dateKey = :dateKey ORDER BY createdAt ASC, id ASC")
    List<MealNote> notesForDay(long userId, String dateKey);

    @Query("UPDATE meal_notes SET done = :done WHERE id = :noteId AND userId = :userId")
    void setNoteDone(long userId, long noteId, boolean done);

    @Query("UPDATE meal_notes SET text = :text WHERE id = :noteId AND userId = :userId")
    void setNoteText(long userId, long noteId, String text);

    @Query("DELETE FROM meal_notes WHERE id = :noteId AND userId = :userId")
    void deleteNote(long userId, long noteId);

    @Query("DELETE FROM meal_notes WHERE userId = :userId AND dateKey = :dateKey AND done = 1")
    void clearDoneNotes(long userId, String dateKey);
}
