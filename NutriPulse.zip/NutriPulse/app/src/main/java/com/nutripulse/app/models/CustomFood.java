package com.nutripulse.app.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** A food the user created themselves (e.g. "Luto ni Nanay"). Values are per serving. */
@Entity(tableName = "custom_foods",
        foreignKeys = @ForeignKey(entity = User.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.CASCADE),
        indices = {@Index(value = {"userId", "name"}, unique = true)})
public class CustomFood {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long userId;
    @NonNull public String name = "";
    public String emoji;
    @NonNull public String category = "Meal";
    @NonNull public String serving = "1 serving";
    public int calories;
    public float protein;
    public float carbs;
    public float fat;
    public boolean healthy = true;
    public long createdAt;
}
