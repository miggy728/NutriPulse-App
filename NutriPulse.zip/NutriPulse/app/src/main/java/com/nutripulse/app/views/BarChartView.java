package com.nutripulse.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/** Simple rounded bar chart with an optional dashed goal line. */
public class BarChartView extends View {
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barMet = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private List<String> labels = new ArrayList<>();
    private List<Float> values = new ArrayList<>();
    private float goal;

    public BarChartView(Context c, @Nullable AttributeSet attrs) {
        super(c, attrs);
        d = getResources().getDisplayMetrics().density;
        bar.setColor(Color.parseColor("#FFB3CC"));
        barMet.setColor(Color.parseColor("#FF4F8B"));
        text.setColor(androidx.core.content.ContextCompat.getColor(c, com.nutripulse.app.R.color.text_muted));
        text.setTextSize(10 * d);
        text.setTextAlign(Paint.Align.CENTER);
        goalPaint.setColor(Color.parseColor("#A57CF0"));
        goalPaint.setStyle(Paint.Style.STROKE);
        goalPaint.setStrokeWidth(1.5f * d);
        goalPaint.setPathEffect(new DashPathEffect(new float[]{6 * d, 5 * d}, 0));
    }

    /** Bars that reach the goal are drawn in a stronger pink. */
    public void setData(List<String> labels, List<Float> values, float goal, int metColor) {
        this.labels = labels;
        this.values = values;
        this.goal = goal;
        barMet.setColor(metColor);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int n = values.size();
        if (n == 0) return;
        float left = 6 * d, right = getWidth() - 6 * d, top = 8 * d, bottom = getHeight() - 18 * d;
        float max = goal;
        for (float v : values) max = Math.max(max, v);
        if (max <= 0) max = 1;
        max *= 1.1f;
        float slot = (right - left) / n, bw = Math.min(26 * d, slot * 0.62f);
        int labelStep = n <= 7 ? 1 : (int) Math.ceil(n / 6f);
        for (int i = 0; i < n; i++) {
            float v = values.get(i);
            float cx = left + slot * (i + 0.5f);
            float h = (bottom - top) * (v / max);
            if (v > 0) {
                RectF r = new RectF(cx - bw / 2, bottom - Math.max(h, 4 * d), cx + bw / 2, bottom);
                canvas.drawRoundRect(r, 6 * d, 6 * d, goal > 0 && v >= goal ? barMet : bar);
            }
            if (i % labelStep == 0) canvas.drawText(labels.get(i), cx, getHeight() - 4 * d, text);
        }
        if (goal > 0) {
            float gy = bottom - (bottom - top) * (goal / max);
            Path p = new Path();
            p.moveTo(left, gy);
            p.lineTo(right, gy);
            canvas.drawPath(p, goalPaint);
        }
    }
}
