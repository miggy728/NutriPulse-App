package com.nutripulse.app.auth;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.nutripulse.app.R;
import com.nutripulse.app.utils.UiUtils;
import com.nutripulse.app.utils.ValidationUtils;

/**
 * Offline password reset. The user verifies ownership with their registered
 * email + username, then sets a new password. Old passwords are never revealed
 * (they can't be: only hashes are stored).
 */
public class ForgotPasswordActivity extends AppCompatActivity {

    private TextInputLayout emailL, usernameL, passwordL, confirmL;
    private MaterialButton resetButton;
    private ProgressBar progress;
    private TextView errorBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailL = findViewById(R.id.forgot_email_layout);
        usernameL = findViewById(R.id.forgot_username_layout);
        passwordL = findViewById(R.id.forgot_password_layout);
        confirmL = findViewById(R.id.forgot_confirm_layout);
        resetButton = findViewById(R.id.forgot_button);
        progress = findViewById(R.id.forgot_progress);
        errorBox = findViewById(R.id.forgot_error);

        findViewById(R.id.forgot_back).setOnClickListener(v -> finish());
        findViewById(R.id.forgot_done).setOnClickListener(v -> finish());
        resetButton.setOnClickListener(v -> attemptReset());

        if (AuthManager.get(this).isCloud()) {
            // Cloud mode: Firebase emails a secure reset link, so only the email is needed.
            usernameL.setVisibility(View.GONE);
            passwordL.setVisibility(View.GONE);
            confirmL.setVisibility(View.GONE);
            ((TextView) findViewById(R.id.forgot_subtitle)).setText(R.string.forgot_subtitle_cloud);
            resetButton.setText(R.string.send_reset_link);
        }
    }

    private void sendResetLink() {
        UiUtils.clearErrors(emailL);
        errorBox.setVisibility(View.GONE);
        String email = UiUtils.text(emailL).trim();
        if (email.isEmpty()) { emailL.setError("Email is required"); return; }
        if (!ValidationUtils.isValidEmail(email)) { emailL.setError("Enter a valid email address"); return; }
        UiUtils.hideKeyboard(this);
        setLoading(true);
        AuthManager.get(this).sendResetEmail(email, new AuthManager.Callback<Void>() {
            @Override public void onSuccess(Void r) {
                setLoading(false);
                ((TextView) findViewById(R.id.forgot_success_text)).setText(getString(R.string.reset_link_sent, email));
                findViewById(R.id.forgot_form).setVisibility(View.GONE);
                findViewById(R.id.forgot_success).setVisibility(View.VISIBLE);
            }
            @Override public void onError(String message) {
                setLoading(false);
                errorBox.setText(message);
                errorBox.setVisibility(View.VISIBLE);
            }
        });
    }

    private void attemptReset() {
        if (AuthManager.get(this).isCloud()) { sendResetLink(); return; }
        UiUtils.clearErrors(emailL, usernameL, passwordL, confirmL);
        errorBox.setVisibility(View.GONE);
        String email = UiUtils.text(emailL).trim();
        String username = UiUtils.text(usernameL).trim();
        String password = UiUtils.text(passwordL);
        String confirm = UiUtils.text(confirmL);

        boolean ok = true;
        if (email.isEmpty()) { emailL.setError("Email is required"); ok = false; }
        else if (!ValidationUtils.isValidEmail(email)) { emailL.setError("Enter a valid email address"); ok = false; }
        if (username.isEmpty()) { usernameL.setError("Username is required"); ok = false; }
        String problem = ValidationUtils.passwordProblem(password);
        if (problem != null) { passwordL.setError(problem); ok = false; }
        if (!confirm.equals(password)) { confirmL.setError("Passwords do not match"); ok = false; }
        if (!ok) return;

        UiUtils.hideKeyboard(this);
        setLoading(true);
        AuthManager.get(this).resetPassword(email, username, password, new AuthManager.Callback<Void>() {
            @Override
            public void onSuccess(Void result) {
                setLoading(false);
                findViewById(R.id.forgot_form).setVisibility(View.GONE);
                findViewById(R.id.forgot_success).setVisibility(View.VISIBLE);
            }

            @Override
            public void onError(String message) {
                setLoading(false);
                errorBox.setText(message);
                errorBox.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setLoading(boolean loading) {
        resetButton.setEnabled(!loading);
        resetButton.setText(loading ? "" : getString(AuthManager.get(this).isCloud()
                ? R.string.send_reset_link : R.string.reset_password));
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
    }
}
