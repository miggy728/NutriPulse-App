package com.nutripulse.app.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import androidx.annotation.NonNull;

import com.nutripulse.app.models.Achievement;
import com.nutripulse.app.models.CustomFood;
import com.nutripulse.app.models.FavoriteFood;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.DietaryPreference;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealPlan;
import com.nutripulse.app.models.MoodRecord;
import com.nutripulse.app.models.MealRecord;
import com.nutripulse.app.models.Pet;
import com.nutripulse.app.models.StepRecord;
import com.nutripulse.app.models.User;
import com.nutripulse.app.models.WaterRecord;
import com.nutripulse.app.models.WeightRecord;

@Database(entities = {
        User.class, Pet.class, MealRecord.class, MealPlan.class,
        WeightRecord.class, WaterRecord.class, StepRecord.class,
        DailyGoal.class, Achievement.class, DietaryPreference.class, MealNote.class,
        CustomFood.class, FavoriteFood.class, MoodRecord.class
}, version = AppDatabase.SCHEMA_VERSION, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    /** Bump this together with a new Migration when the tables change. */
    public static final int SCHEMA_VERSION = 5;

    private static volatile AppDatabase instance;

    public abstract UserDao userDao();
    public abstract PetDao petDao();
    public abstract MealDao mealDao();
    public abstract TrackingDao trackingDao();
    public abstract GoalDao goalDao();
    public abstract FoodDao foodDao();
    public abstract MoodDao moodDao();
    public abstract BackupDao backupDao();

    /** v1 -> v2: adds the meal_notes table. Existing accounts and data are kept. */
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `meal_notes` ("
                    + "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "`userId` INTEGER NOT NULL, "
                    + "`dateKey` TEXT NOT NULL, "
                    + "`text` TEXT NOT NULL, "
                    + "`done` INTEGER NOT NULL, "
                    + "`createdAt` INTEGER NOT NULL, "
                    + "FOREIGN KEY(`userId`) REFERENCES `users`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_meal_notes_userId_dateKey` "
                    + "ON `meal_notes` (`userId`, `dateKey`)");
        }
    };

    /** v2 -> v3: adds custom_foods and favorite_foods. Existing data is kept. */
    static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `custom_foods` ("
                    + "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "`userId` INTEGER NOT NULL, "
                    + "`name` TEXT NOT NULL, "
                    + "`emoji` TEXT, "
                    + "`category` TEXT NOT NULL, "
                    + "`serving` TEXT NOT NULL, "
                    + "`calories` INTEGER NOT NULL, "
                    + "`protein` REAL NOT NULL, "
                    + "`carbs` REAL NOT NULL, "
                    + "`fat` REAL NOT NULL, "
                    + "`healthy` INTEGER NOT NULL, "
                    + "`createdAt` INTEGER NOT NULL, "
                    + "FOREIGN KEY(`userId`) REFERENCES `users`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_custom_foods_userId_name` "
                    + "ON `custom_foods` (`userId`, `name`)");
            db.execSQL("CREATE TABLE IF NOT EXISTS `favorite_foods` ("
                    + "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "`userId` INTEGER NOT NULL, "
                    + "`foodName` TEXT NOT NULL, "
                    + "`createdAt` INTEGER NOT NULL, "
                    + "FOREIGN KEY(`userId`) REFERENCES `users`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_favorite_foods_userId_foodName` "
                    + "ON `favorite_foods` (`userId`, `foodName`)");
        }
    };

    /** v3 -> v4: Berry Shop columns on pets. Existing users get coins for the EXP they already earned. */
    static final Migration MIGRATION_3_4 = new Migration(3, 4) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE `pets` ADD COLUMN `coins` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE `pets` ADD COLUMN `ownedItems` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE `pets` ADD COLUMN `hat` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE `pets` ADD COLUMN `face` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE `pets` ADD COLUMN `room` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("UPDATE `pets` SET `coins` = (`level` - 1) * 100 + `exp`");
        }
    };

    /** v4 -> v5: mood tracker table and height for BMI. Existing data is kept. */
    static final Migration MIGRATION_4_5 = new Migration(4, 5) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `mood_records` ("
                    + "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "`userId` INTEGER NOT NULL, "
                    + "`dateKey` TEXT NOT NULL, "
                    + "`mood` INTEGER NOT NULL, "
                    + "`note` TEXT, "
                    + "`timestamp` INTEGER NOT NULL, "
                    + "FOREIGN KEY(`userId`) REFERENCES `users`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_mood_records_userId_dateKey` "
                    + "ON `mood_records` (`userId`, `dateKey`)");
            db.execSQL("ALTER TABLE `users` ADD COLUMN `heightCm` REAL NOT NULL DEFAULT 0");
        }
    };

    public static AppDatabase get(Context context) {
        if (instance == null) {
            synchronized (AppDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "nutripulse.db")
                            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                            .build();
                }
            }
        }
        return instance;
    }
}
