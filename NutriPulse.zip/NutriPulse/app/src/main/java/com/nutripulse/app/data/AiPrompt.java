package com.nutripulse.app.data;

import com.nutripulse.app.models.ChatMessage;
import com.nutripulse.app.models.DailyGoal;
import com.nutripulse.app.models.MealNote;
import com.nutripulse.app.models.MealRecord;

import java.util.List;
import java.util.Locale;

/**
 * Builds the text sent to Gemini: Berry's personality and safety rules, a short summary of
 * today's data, the recent conversation, and the new message. Pure Java, so it can be tested.
 * Only the first name and today's numbers are shared — never email, passwords or ids.
 */
public final class AiPrompt {
    private AiPrompt() {}

    static final String RULES =
            "You are Berry, a cute pink berry mascot and friendly wellness buddy inside the NutriPulse app.\n"
            + "Style: warm, encouraging, simple words, short answers (max about 120 words), a few emojis.\n"
            + "If the user writes in Filipino or Taglish, answer in natural Taglish.\n"
            + "Help with healthy eating, hydration, sleep, activity, meal ideas (Filipino food welcome) and using the app.\n"
            + "Safety rules (always follow):\n"
            + "- You are not a doctor. Do not diagnose, prescribe or give medication doses. Suggest a doctor or registered dietitian for medical questions.\n"
            + "- Never recommend extreme diets, fasting to lose weight, very low calories, purging or over-exercising.\n"
            + "- If the user mentions self-harm, suicide, an eating disorder or feeling unsafe, respond with care and "
            + "encourage them to reach out now to a trusted person and the NCMH Crisis Hotline 1553 (Philippines) or 911 in an emergency.\n"
            + "- Stay on wellness topics; politely steer back if asked about unrelated things.\n"
            + "- Use the user's data below only to personalize; do not invent numbers.\n";

    public static String build(ChatBot.ChatContext c, List<ChatMessage> history, String message) {
        StringBuilder sb = new StringBuilder(RULES);
        sb.append("\nUSER DATA FOR TODAY\n");
        if (c != null && c.user != null) {
            sb.append("Name: ").append(c.user.getFirstName()).append('\n');
            sb.append(String.format(Locale.US, "Calories: %d of %d kcal goal (protein %.0fg, carbs %.0fg, fat %.0fg)%n",
                    c.calories, c.user.calorieGoal, c.protein, c.carbs, c.fat));
            sb.append("Water: ").append(c.water).append(" of ").append(c.user.hydrationGoal).append(" cups\n");
            sb.append("Steps: ").append(c.steps).append(" of ").append(c.user.stepGoal).append('\n');
            sb.append("Logging streak: ").append(c.streak).append(" day(s)\n");
            if (c.pet != null) sb.append("Pet: ").append(c.pet.name).append(", level ").append(c.pet.level).append('\n');
            if (c.preference != null && c.preference.dietType != null)
                sb.append("Diet preference: ").append(c.preference.dietType)
                        .append(c.preference.avoidFoods == null || c.preference.avoidFoods.isEmpty() ? "" : "; avoids " + c.preference.avoidFoods)
                        .append('\n');
            if (!c.meals.isEmpty()) {
                sb.append("Eaten today: ");
                for (int i = 0; i < Math.min(8, c.meals.size()); i++) {
                    MealRecord m = c.meals.get(i);
                    sb.append(i == 0 ? "" : ", ").append(m.foodName).append(" (").append(m.calories).append(" kcal)");
                }
                sb.append('\n');
            }
            if (!c.goals.isEmpty()) {
                sb.append("Goals: ");
                for (int i = 0; i < c.goals.size(); i++) {
                    DailyGoal g = c.goals.get(i);
                    sb.append(i == 0 ? "" : "; ").append(g.title).append(g.completed ? " (done)" : " (not yet)");
                }
                sb.append('\n');
            }
            if (!c.notes.isEmpty()) {
                sb.append("Meal plan notes: ");
                for (int i = 0; i < Math.min(6, c.notes.size()); i++) {
                    MealNote n = c.notes.get(i);
                    sb.append(i == 0 ? "" : "; ").append(n.text);
                }
                sb.append('\n');
            }
        }
        sb.append("\nCONVERSATION SO FAR\n");
        if (history != null) {
            int start = Math.max(0, history.size() - 10);              // keep the prompt small
            for (int i = start; i < history.size(); i++) {
                ChatMessage m = history.get(i);
                if (m.sender == ChatMessage.TYPING) continue;
                sb.append(m.sender == ChatMessage.FROM_USER ? "User: " : "Berry: ").append(trim(m.text)).append('\n');
            }
        }
        sb.append("User: ").append(trim(message)).append("\nBerry:");
        return sb.toString();
    }

    private static String trim(String s) {
        String t = s.replace('\n', ' ').trim();
        return t.length() > 500 ? t.substring(0, 500) + "…" : t;
    }
}
