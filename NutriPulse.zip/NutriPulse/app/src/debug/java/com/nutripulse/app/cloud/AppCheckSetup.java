package com.nutripulse.app.cloud;

/**
 * DEBUG / test builds: App Check is intentionally OFF (the App Check library isn't even included),
 * so a debug APK works on any phone for testing and presentations.
 *
 * Requirement: Firebase console > Security > App Check > APIs > Firebase AI Logic = "Unenforced".
 * Before publishing, build a RELEASE APK/AAB (uses Play Integrity) and set it back to "Enforced".
 */
public final class AppCheckSetup {
    private AppCheckSetup() {}

    public static void install() {
        // no-op in debug
    }
}
