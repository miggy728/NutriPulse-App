# Firebase Setup for NutriPulse (Cloud login, backup, AI chat)

NutriPulse works **fully offline without Firebase**. Follow these steps when you want:

- ☁️ **Cloud accounts** (Firebase Authentication) with **real password-reset emails**
- 💾 **Automatic cloud backup** that restores when you log in on another phone (Cloud Firestore)
- 🤖 **AI mode for Berry** (Google Gemini through Firebase AI Logic, no API key in the app)

Everything below is free on the **Spark (no-cost) plan**. No credit card needed.

---

## 1. Create the Firebase project
1. Go to https://console.firebase.google.com and click **Create a project**. Name it e.g. `NutriPulse`.
2. Google Analytics is optional (you can turn it off).

## 2. Add the Android app
1. On the project page click the **Android** icon.
2. **Android package name:** `com.nutripulse.app` (must match exactly).
3. App nickname: `NutriPulse`. You can skip the SHA-1 for now.
4. Click **Register app**, then **Download google-services.json**.
5. Put the file here: `NutriPulse/app/google-services.json` (same folder as `app/build.gradle`).
6. Skip the remaining "add SDK" steps; the project already has them.
7. In Android Studio: **File › Sync Project with Gradle Files**.

> The app detects the file automatically. Without it, the app stays in offline mode.

## 3. Turn on Email/Password login
1. Firebase console › **Build › Authentication › Get started**.
2. **Sign-in method › Email/Password › Enable › Save.**

Password reset emails now work from the app's **Forgot Password** screen.

## 4. Create the Firestore database (for backup)
1. **Build › Firestore Database › Create database.**
2. Choose a location near you (e.g. `asia-southeast1`), then **Start in production mode**.
3. Open the **Rules** tab, delete everything, paste the contents of `firestore.rules`
   from this project, and click **Publish**.
   These rules make sure **each user can only read and write their own data**.

## 5. Turn on AI for Berry (Firebase AI Logic)
1. **Build › AI Logic › Get started.**
2. Choose **Gemini Developer API** (free tier). Firebase creates and keeps the Gemini key for you.
   **Never put that key in the app code.**
3. Follow the guided setup. It turns on **App Check** to protect the AI from abuse (next step).

The model name is in `app/src/main/java/com/nutripulse/app/cloud/GeminiChat.java`
(`MODEL = "gemini-3.8-flash"`). If Google retires it, update it to the current model on the
Firebase AI Logic "supported models" page.

## 6. App Check (testing vs. publishing)
**Debug / test APKs (testing, presentations):** App Check is turned OFF in debug builds, so the AI
works on any phone. In Firebase console › **Security › App Check › APIs** tab › **Firebase AI Logic**,
set it to **Unenforced**. No debug tokens needed.

**Before publishing to Google Play:** build a **release** AAB (uses Play Integrity). In App Check ›
**Apps**, register Play Integrity with the **App signing key SHA-256** from Play Console › Setup ›
App signing, then set Firebase AI Logic back to **Enforced**.

## 7. Try it
1. Run the app. **Register a new account** (or log in with an existing one; it gets linked to the cloud).
2. Settings › **Cloud Account & Backup** › **Back up now**.
3. Chat with Berry › ⚙️ › **Turn AI mode on**.
4. On another phone or emulator, log in with the same email: your data, Berry, coins and items come back.

---

## How it works (for your documentation / defense)

| Feature | How |
|---|---|
| Login & register | Firebase Authentication (email/password). A hashed copy (PBKDF2) is kept on the phone so you can still log in **offline**. |
| Password reset | Firebase sends a secure reset link by email. The app shows the same message whether or not the email exists. |
| Backup | Firestore `users/{uid}` (profile, goals) + `users/{uid}/backup/*` (your records). Passwords are **never** uploaded. Automatic every 6 hours when you leave the Home screen, and before logout. |
| Restore | Logging in on a phone that doesn't have your account yet downloads your backup. |
| Data privacy | `firestore.rules` only lets the signed-in owner read/write their own `users/{uid}` data. |
| AI chat | Firebase AI Logic → Gemini. The API key stays in Firebase; App Check blocks other apps. Safety topics (self-harm, eating disorders) are always answered by offline Berry with hotline info. Only your first name and today's numbers are sent, never email or password. |
| Offline | No internet? Login, logging, charts, chat (offline Berry), everything still works. Backup runs next time you're online. |

## Troubleshooting
- **"AI is unavailable right now"** → App Check for AI Logic still "Enforced" while using a debug APK, AI Logic not enabled, or model name retired. Check Logcat for the exact error.
- **Login says incorrect password after a reset email** → use the *new* password; the cloud password always wins.
- **PERMISSION_DENIED in Logcat for Firestore** → you didn't publish `firestore.rules` (step 4.3).
- **Build error about google-services** → the `package_name` in `google-services.json` must be `com.nutripulse.app`.
- **Weekly auto-email of the PDF** is not included: that needs a server (Cloud Functions on the paid Blaze plan). The app's **"Email the PDF to me"** button opens your email app with everything filled in.
